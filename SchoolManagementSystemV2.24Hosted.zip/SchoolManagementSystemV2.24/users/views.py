# SchoolManagementSystem/users/views.py
import csv
import io
import json
import random
import string
import uuid
from datetime import date, timedelta, datetime

# NEW IMPORTS for bulk upload
import openpyxl
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction
from django.db.models import Q, Sum
from django.http import JsonResponse, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_POST

# Import models from academic, marks, and exams apps (restored all necessary imports)
from academic.models import (
    AcademicSession,
    Class,
    ClassSubjectAssignment,
    Fee,
    FeePayment,
    AttendanceRecord,
    Assignment,
    AssignmentSubmission,
    Subject,
    Notice,
    StudentFeeCategory,
    Section,
    Division
)
from exams.models import ExamSchedule
from marks.models import StudentExamMark, ClassTestMark, ExamStructure, ExamType # Import ExamType
# Import forms from current app
from .forms import (
    CustomUserCreationForm, CustomAuthenticationForm, CustomUserChangeForm,
    TeacherProfileForm, StudentForm, ParentProfileForm, AuthPasswordChangeForm,
    BulkUserUploadForm
)
# Import models from current app
from .models import (
    CustomUser,
    Student,
    TeacherProfile,
    ParentProfile,
)


# --- Helper functions for role-based access ---
def is_admin(user):
    return user.is_authenticated and user.role == 'admin'


def is_teacher(user):
    return user.is_authenticated and user.role == 'teacher'


def is_student(user):
    return user.is_authenticated and user.role == 'student'


def is_parent(user):
    return user.is_authenticated and user.role == 'parent'


# Additional helper functions (restored from previous memory)
def is_admin_or_teacher(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher')


def is_admin_or_student(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'student')


def is_admin_or_parent(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'parent')


def is_admin_or_teacher_or_student(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher' or user.role == 'student')


def is_admin_or_teacher_or_parent(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher' or user.role == 'parent')


def is_admin_or_teacher_or_student_or_parent(user):
    return user.is_authenticated and (
            user.role == 'admin' or user.role == 'teacher' or user.role == 'student' or user.role == 'parent')


# --- Authentication Views ---
def register_view(request):
    # Temporarily disable public registration as per previous instruction
    messages.info(request,
                  "Public registration is currently disabled. Please contact an administrator to create an account.")
    return redirect('users:login')


def login_view(request):
    if request.user.is_authenticated:
        return redirect('users:dashboard')

    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, email=email, password=password)  # Authenticate with email
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {user.get_full_name()}!")
                # Check if force_password_change is true, redirect to password change
                if user.force_password_change:
                    messages.warning(request, "Please change your password to continue.")
                    return redirect('users:password_change')
                return redirect('users:dashboard')
            else:
                messages.error(request, 'Invalid email or password.')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = CustomAuthenticationForm()

    context = {
        'page_title': 'Login',
        'form': form,
    }
    return render(request, 'users/login.html', context)


@login_required
def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('users:login')


# --- Dashboard View (Consolidated) ---
@login_required
def dashboard(request):
    page_title = 'Dashboard'
    user = request.user
    context = {
        'page_title': page_title,
        'user_role': user.get_role_display(),
    }

    # Define current_academic_session for this view
    current_academic_session = AcademicSession.objects.filter(is_current=True).first()
    context['current_academic_session'] = current_academic_session

    # Common counts
    context['total_users'] = CustomUser.objects.count()
    context['total_students'] = Student.objects.count()
    context['total_teachers'] = TeacherProfile.objects.count()
    context['total_classes'] = Class.objects.count()
    context['total_subjects'] = Subject.objects.count()
    context['active_sessions'] = AcademicSession.objects.filter(is_current=True).count()

    if is_admin(user):
        context['recent_notices'] = Notice.objects.filter(is_active=True, target_roles__in=['all', 'admin']).order_by(
            '-published_date')[:5]
        context['upcoming_exams'] = ExamSchedule.objects.filter(
            exam__academic_session=current_academic_session,
            exam_date__gte=timezone.now().date()
        ).order_by('exam_date', 'start_time')[:5]

    elif is_teacher(user):
        teacher_profile = request.user.teacher_profile
        context['teacher_profile'] = teacher_profile

        assigned_classes_subjects = ClassSubjectAssignment.objects.filter(teacher=teacher_profile,
                                                                          academic_session=current_academic_session)
        context['assigned_classes_subjects'] = assigned_classes_subjects

        taught_classes_ids = assigned_classes_subjects.values_list('class_obj__id', flat=True).distinct()
        taught_subjects_ids = assigned_classes_subjects.values_list('subject__id', flat=True).distinct()

        context['taught_classes'] = Class.objects.filter(id__in=taught_classes_ids)
        context['taught_subjects'] = Subject.objects.filter(id__in=taught_subjects_ids)

        q_assignments = Q(assigned_by=teacher_profile)
        for cs_assignment in assigned_classes_subjects:
            q_assignments |= Q(class_obj=cs_assignment.class_obj, subject=cs_assignment.subject)

        context['upcoming_assignments'] = Assignment.objects.filter(
            q_assignments,
            due_date__gte=timezone.now().date(),
            academic_session=current_academic_session
        ).distinct().order_by('due_date')[:5]

        recent_marks_recorded_queryset = StudentExamMark.objects.filter(
            recorded_by=user,
            academic_session=current_academic_session
        ).select_related('student__user', 'subject', 'exam_type').order_by('-recorded_at')[:5]

        recent_marks_recorded_for_template = []
        for mark in recent_marks_recorded_queryset:
            total_max_marks = 'N/A'
            exam_structure = ExamStructure.objects.filter(
                exam_type=mark.exam_type,
                subject=mark.subject,
                exam_type__academic_session=mark.academic_session # Corrected filter
            ).first()
            if exam_structure:
                total_max_marks = exam_structure.total_max_marks
            recent_marks_recorded_for_template.append({
                'mark_obj': mark,
                'student_full_name': mark.student.user.get_full_name(),
                'subject_name': mark.subject.name,
                'exam_type_name': mark.exam_type.name,
                'total_marks_obtained': mark.total_marks_obtained,
                'total_max_marks': total_max_marks,
                'pass_status': mark.pass_status,
                'recorded_at': mark.recorded_at,
            })
        context['recent_marks_recorded'] = recent_marks_recorded_for_template

        recent_ct_marks_recorded = ClassTestMark.objects.filter(
            recorded_by=user,
            class_test__academic_session=current_academic_session
        ).select_related('class_test__subject').order_by('-recorded_at')[:5]
        context['recent_marks_recorded_ct'] = recent_ct_marks_recorded

        context['recent_notices'] = Notice.objects.filter(
            Q(target_roles='all') | Q(target_roles='teacher') | Q(target_classes__in=taught_classes_ids)
        ).filter(is_active=True).distinct().order_by('-published_date')[:5]

    elif is_student(user):
        student_profile = request.user.student_profile
        if not student_profile:
            messages.error(request, "Your student profile is incomplete. Please contact an administrator.")
            return render(request, 'dashboard.html', context)

        context['student_profile'] = student_profile
        current_class = student_profile.current_class
        academic_session = student_profile.academic_session

        context['current_class'] = current_class
        context['academic_session'] = academic_session

        # Define current_academic_session for this view
        current_academic_session = AcademicSession.objects.filter(is_current=True).first()

        recent_marks_queryset = StudentExamMark.objects.filter(
            student=student_profile,
            academic_session=current_academic_session
        ).select_related('subject', 'exam_type').order_by('-recorded_at')[:5]

        recent_exam_marks_for_template = []
        for mark in recent_marks_queryset:
            total_max_marks = 'N/A'
            exam_structure = ExamStructure.objects.filter(
                exam_type=mark.exam_type,
                subject=mark.subject,
                exam_type__academic_session=mark.academic_session # Corrected filter
            ).first()
            if exam_structure:
                total_max_marks = exam_structure.total_max_marks
            recent_exam_marks_for_template.append({
                'exam_type_name': mark.exam_type.name,
                'subject_name': mark.subject.name,
                'total_marks_obtained': mark.total_marks_obtained,
                'total_max_marks': total_max_marks,
                'pass_status': mark.pass_status,
                'recorded_at': mark.recorded_at,
            })
        context['recent_exam_marks'] = recent_exam_marks_for_template

        recent_ct_marks = ClassTestMark.objects.filter(
            student=student_profile,
            class_test__academic_session=current_academic_session
        ).select_related('class_test__subject').order_by('-recorded_at')[:5]
        context['recent_ct_marks'] = recent_ct_marks

        gpa_trend = [
            {'semester': 'Sem 1', 'gpa': 3.5},
            {'semester': 'Sem 2', 'gpa': 3.7},
            {'semester': 'Sem 3', 'gpa': 3.6},
        ]
        context['gpa_trend'] = gpa_trend

        my_attendance_records = AttendanceRecord.objects.filter(
            student=student_profile,
            date__gte=timezone.now().date() - timedelta(days=30),
            academic_session=current_academic_session
        ).order_by('date')
        context['my_attendance_records'] = my_attendance_records

        attendance_data = {}
        for record in my_attendance_records:
            attendance_data[str(record.date)] = "Present" if record.is_present else "Absent"
        attendance_data_json = json.dumps(attendance_data)
        context['attendance_data_json'] = attendance_data_json

        # Calculate attendance summary for the last 30 days
        total_days = my_attendance_records.count()
        present_days = my_attendance_records.filter(is_present=True).count()
        absent_days = my_attendance_records.filter(is_present=False).count()
        attendance_percentage = (present_days / total_days * 100) if total_days > 0 else 0

        attendance_summary = {
            'total_days': total_days,
            'present_days': present_days,
            'absent_days': absent_days,
            'percentage': round(attendance_percentage, 2)
        }
        context['attendance_summary'] = attendance_summary

        # Fetch recent assignment submissions
        recent_submissions = AssignmentSubmission.objects.filter(
            student=student_profile,
            assignment__academic_session=student_profile.academic_session
        ).select_related('assignment__subject').order_by('-submission_date')[:5]
        context['recent_submissions'] = recent_submissions

        # Fees and Payments
        fees_and_payments = []
        if student_profile.academic_session:
            applicable_fees = Fee.objects.filter(academic_session=student_profile.academic_session)
            for fee in applicable_fees:
                total_paid = FeePayment.objects.filter(student=student_profile, fee=fee).aggregate(Sum('amount_paid'))[
                                 'amount_paid__sum'] or 0
                balance = fee.amount - total_paid
                payments_for_fee = FeePayment.objects.filter(student=student_profile, fee=fee).order_by('-payment_date')
                fees_and_payments.append({
                    'fee': fee,
                    'total_paid': total_paid,
                    'balance': balance,
                    'payments': payments_for_fee
                })
        context['fees_and_payments'] = fees_and_payments

        # Upcoming Exams
        upcoming_exams = ExamSchedule.objects.filter(
            class_obj=current_class,
            exam__academic_session=student_profile.academic_session,
            exam_date__gte=date.today()
        ).order_by('exam_date', 'start_time').select_related('exam', 'class_obj', 'subject')[:5]
        context['upcoming_exams'] = upcoming_exams

        homeroom_teacher = None
        if current_class and current_class.class_teacher:
            homeroom_teacher = current_class.class_teacher
        context['homeroom_teacher'] = homeroom_teacher


    elif is_parent(user):
        # Use try-except to gracefully handle cases where ParentProfile might not exist
        try:
            parent_profile = ParentProfile.objects.get(user=request.user)
            context['parent_profile'] = parent_profile

            children = Student.objects.filter(parent=parent_profile).select_related('user',
                                                                                    'current_class__academic_session')
            context['children'] = children

            # If no children are linked, show a message and still render the parent_child_list template
            if not children.exists():
                messages.info(request,
                              "No children are currently linked to your account. Please contact the administrator if this is incorrect.")
                # We will render parent_child_list.html directly, not redirect to dashboard
                return render(request, 'users/parent_child_list.html', context)

            # Define current_academic_session for this view (if needed for dashboard widgets)
            current_academic_session = AcademicSession.objects.filter(is_current=True).first()
            context['current_academic_session'] = current_academic_session

            all_children_upcoming_exams = []
            all_children_upcoming_assignments = []
            all_children_attendance = []
            all_children_recent_marks = []
            all_children_recent_ct_marks = []

            for child in context['children']:
                child_current_class = child.current_class
                child_academic_session = child.academic_session

                if child_current_class and child_academic_session:
                    child_exams = ExamSchedule.objects.filter(
                        class_obj=child_current_class,
                        exam__academic_session=child_academic_session,
                        exam_date__gte=timezone.now().date()
                    ).order_by('exam_date', 'start_time')[:3]
                    all_children_upcoming_exams.extend(list(child_exams))

                    child_assignments = Assignment.objects.filter(
                        class_obj=child_current_class,
                        academic_session=child_academic_session,
                        due_date__gte=timezone.now().date()
                    ).order_by('due_date')[:3]
                    all_children_upcoming_assignments.extend(list(child_assignments))

                    child_attendance = AttendanceRecord.objects.filter(
                        student=child,
                        academic_session=child_academic_session,
                        date__gte=timezone.now().date() - timedelta(days=7)
                    ).order_by('-date')[:5]
                    all_children_attendance.extend(list(child_attendance))

                    child_recent_exam_marks_queryset = StudentExamMark.objects.filter(
                        student=child,
                        academic_session=child_academic_session
                    ).select_related('subject', 'exam_type').order_by('-recorded_at')[:3]

                    child_recent_exam_marks_for_template = []
                    for mark in child_recent_exam_marks_queryset:
                        total_max_marks = 'N/A'
                        exam_structure = ExamStructure.objects.filter(
                            exam_type=mark.exam_type,
                            subject=mark.subject,
                            exam_type__academic_session=mark.academic_session # Corrected filter
                        ).first()
                        if exam_structure:
                            total_max_marks = exam_structure.total_max_marks
                        child_recent_exam_marks_for_template.append({
                            'mark_obj': mark,
                            'student_full_name': mark.student.user.get_full_name(),
                            'exam_type_name': mark.exam_type.name,
                            'subject_name': mark.subject.name,
                            'total_marks_obtained': mark.total_marks_obtained,
                            'total_max_marks': total_max_marks,
                            'pass_status': mark.pass_status,
                            'recorded_at': mark.recorded_at,
                        })
                    all_children_recent_marks.extend(list(child_recent_exam_marks_for_template))

                    child_recent_ct_marks = ClassTestMark.objects.filter(
                        student=child,
                        class_test__academic_session=child_academic_session
                    ).select_related('class_test__subject').order_by('-recorded_at')[:3]
                    all_children_recent_ct_marks.extend(list(child_recent_ct_marks))

            context['upcoming_exams'] = sorted(all_children_upcoming_exams, key=lambda x: (x.exam_date, x.start_time))[
                                        :5]
            context['upcoming_assignments'] = sorted(all_children_upcoming_assignments, key=lambda x: x.due_date)[:5]
            context['children_attendance'] = sorted(all_children_attendance, key=lambda x: x.date, reverse=True)[:5]
            context['children_recent_exam_marks'] = sorted(all_children_recent_marks, key=lambda x: x['recorded_at'],
                                                           reverse=True)[:5]
            context['children_recent_ct_marks'] = sorted(all_children_recent_ct_marks, key=lambda x: x.recorded_at,
                                                         reverse=True)[:5]

            context['recent_notices'] = Notice.objects.filter(
                Q(target_roles='all') | Q(target_roles='parent') | Q(
                    target_classes__in=[child.current_class for child in children if child.current_class])
            ).filter(is_active=True).distinct().order_by('-published_date')[:5]

        except ParentProfile.DoesNotExist:
            messages.error(request, "Your parent profile is incomplete. Please contact an administrator.")
            return redirect('users:dashboard')

    return render(request, 'dashboard.html', context)


# --- User Management Views (Admin Only) ---
@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def user_list(request):
    users = CustomUser.objects.all().order_by('email')

    query = request.GET.get('q')
    if query:
        users = users.filter(Q(email__icontains=query) | Q(first_name__icontains=query) | Q(last_name__icontains=query))

    role_filter = request.GET.get('role')
    if role_filter:
        users = users.filter(role=role_filter)

    page_size = request.GET.get('page_size', 10)  # Default to 10 if not provided
    try:
        page_size = int(page_size)
    except ValueError:
        page_size = 10  # Fallback if invalid value

    paginator = Paginator(users, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'User List',
        'page_obj': page_obj,
        'roles': CustomUser.UserRole.choices,  # Pass available roles to the template
    }
    return render(request, 'users/user_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def user_create(request):
    if request.method == 'POST':
        user_form = CustomUserCreationForm(request.POST)
        profile_form = None

        if user_form.is_valid():
            user = user_form.save(commit=False)
            user.is_active = True
            user.save()

            if user.role == 'student':
                profile_form = StudentForm(request.POST, instance=Student(user=user))
            elif user.role == 'teacher':
                profile_form = TeacherProfileForm(request.POST, instance=TeacherProfile(user=user))
            elif user.role == 'parent':
                profile_form = ParentProfileForm(request.POST, instance=ParentProfile(user=user))

            if profile_form:
                if profile_form.is_valid():
                    profile_form.save()
                    messages.success(request, f"User {user.email} and their profile created successfully!")
                    return redirect('users:user_list')
                else:
                    user.delete()
                    for field, errors in profile_form.errors.items():
                        for error in errors:
                            messages.error(request, f"Profile - {field.replace('_', ' ').title()}: {error}")
            else:
                messages.success(request, f"User {user.email} created successfully (no specific profile needed).")
                return redirect('users:user_list')
        else:
            for field, errors in user_form.errors.items():
                for error in errors:
                    messages.error(request, f"User - {field.replace('_', ' ').title()}: {error}")
            if user_form.non_field_errors():
                for error in user_form.non_field_errors():
                    messages.error(request, f"User - {error}")
    else:
        user_form = CustomUserCreationForm()
        profile_form = None

    context = {
        'page_title': 'Create New User',
        'user_form': user_form,
        'profile_form': profile_form,
        'action': 'create',
    }
    return render(request, 'users/user_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def user_update(request, pk):
    user_obj = get_object_or_404(CustomUser, pk=pk)
    profile_instance = None

    if user_obj.role == 'student':
        profile_instance, created = Student.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A student profile was automatically created for this user as it was missing.")
    elif user_obj.role == 'teacher':
        profile_instance, created = TeacherProfile.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A teacher profile was automatically created for this user as it was missing.")
    elif user_obj.role == 'parent':
        profile_instance, created = ParentProfile.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A parent profile was automatically created for this user as it was missing.")

    if request.method == 'POST':
        user_form = CustomUserChangeForm(request.POST, instance=user_obj, request=request)

        if user_obj.role == 'student':
            profile_form = StudentForm(request.POST, instance=profile_instance)
        elif user_obj.role == 'teacher':
            profile_form = TeacherProfileForm(request.POST, instance=profile_instance)
        elif user_obj.role == 'parent':
            profile_form = ParentProfileForm(request.POST, instance=profile_instance)
        else:
            profile_form = None

        if user_form.is_valid() and (profile_form is None or profile_form.is_valid()):
            user = user_form.save()
            if profile_form:
                profile_form.save()
            messages.success(request, f"User {user_obj.email} updated successfully!")
            return redirect('users:user_list')
        else:
            if not user_form.is_valid():
                for field, errors in user_form.errors.items():
                    for error in errors:
                        messages.error(request, f"User - {field.replace('_', ' ').title()}: {error}")
                if user_form.non_field_errors():
                    for error in user_form.non_field_errors():
                        messages.error(request, f"User - {error}")
            if profile_form and not profile_form.is_valid():
                for field, errors in profile_form.errors.items():
                    for error in errors:
                        messages.error(request, f"Profile - {field.replace('_', ' ').title()}: {error}")

    else:
        user_form = CustomUserChangeForm(instance=user_obj, request=request)

        if user_obj.role == 'student':
            profile_form = StudentForm(instance=profile_instance)
        elif user_obj.role == 'teacher':
            profile_form = TeacherProfileForm(instance=profile_instance)
        elif user_obj.role == 'parent':
            profile_form = ParentProfileForm(instance=profile_instance)
        else:
            profile_form = None

    context = {
        'page_title': f'Update User: {user_obj.get_full_name()}',
        'user_form': user_form,
        'profile_form': profile_form,
        'user_obj': user_obj,
        'action': 'update',
    }
    return render(request, 'users/user_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def user_delete(request, pk):
    user_to_delete = get_object_or_404(CustomUser, pk=pk)

    if user_to_delete == request.user:
        messages.error(request, "You cannot delete your own account.")
        return redirect('users:dashboard')

    if request.method == 'POST':
        try:
            user_to_delete.delete()
            messages.success(request, f"User '{user_to_delete.email}' and associated profile deleted successfully.")
            return redirect('users:user_list')
        except Exception as e:
            messages.error(request, f"Error deleting user: {e}")
            return redirect('users:user_list')

    context = {
        'page_title': 'Confirm Delete User',
        'object': user_to_delete,
        'confirm_message': f"Are you sure you want to delete the account for {user_to_delete.get_full_name()} ({user_to_delete.role})? This action cannot be undone."
    }
    return render(request, 'users/confirm_delete.html', context)


# --- Student Profile Views (Admin & Teacher) ---

from django.db.models import Q
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test


@login_required
@user_passes_test(is_admin_or_teacher, login_url="users:dashboard")
def student_list(request):
    # Base queryset
    students = Student.objects.select_related(
        "user",
        "current_class",
        "division",
        "section",
        "fee_category",
        "academic_session",
    ).order_by("user__last_name", "user__first_name")

    # Search filter
    query = request.GET.get("q")
    if query:
        students = students.filter(
            Q(user__first_name__icontains=query)
            | Q(user__last_name__icontains=query)
            | Q(admission_number__icontains=query)
            | Q(roll_number__icontains=query)
        )

    # Class filter
    class_obj_id = request.GET.get("class_obj")
    if class_obj_id:
        students = students.filter(current_class_id=class_obj_id)

    # Division filter (direct on Student model)
    division_id = request.GET.get("division")
    if division_id:
        students = students.filter(division_id=division_id)

    # Section filter
    section_id = request.GET.get("section")
    if section_id:
        students = students.filter(section_id=section_id)

    # Fee Category filter
    category_id = request.GET.get("fee_category")
    if category_id:
        students = students.filter(fee_category_id=category_id)
    fee_categories = StudentFeeCategory.objects.all()
    # Academic session filter (default to current)
    academic_session_id = request.GET.get("academic_session")
    if academic_session_id:
        students = students.filter(academic_session_id=academic_session_id)
    else:
        current_session = AcademicSession.objects.filter(is_current=True).first()
        if current_session:
            students = students.filter(academic_session=current_session)

    # Restrict teachers to assigned classes
    if is_teacher(request.user):
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        assigned_class_ids = (
            ClassSubjectAssignment.objects.filter(
                teacher=teacher_profile, academic_session__is_current=True
            )
            .values_list("class_obj__id", flat=True)
            .distinct()
        )
        students = students.filter(current_class_id__in=assigned_class_ids)

    # Pagination
    page_size = request.GET.get("page_size", 10)
    try:
        page_size = int(page_size)
    except ValueError:
        page_size = 10

    paginator = Paginator(students, page_size)
    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    # Context for template filters
    context = {
        "page_title": "Student List",
        "page_obj": page_obj,
        "classes": Class.objects.all().order_by("name"),
        "divisions": Division.objects.all().order_by("name"),
        "sections": Section.objects.all().order_by("name"),
        "fee_categories": StudentFeeCategory.objects.all().order_by("name"),
        "academic_sessions": AcademicSession.objects.all().order_by("-start_date"),
        "query": query,
    }

    return render(request, "users/student_list.html", context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def student_create_profile(request, user_pk):
    user = get_object_or_404(CustomUser, pk=user_pk, role='student')
    if Student.objects.filter(user=user).exists():
        messages.warning(request, 'A profile for this student already exists.')
        return redirect('users:student_list')

    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            student_profile = form.save(commit=False)
            student_profile.user = user
            student_profile.save()
            messages.success(request, f'Student profile for {user.get_full_name()} created successfully!')
            return redirect('users:student_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"Student Profile - {field.replace('_', ' ').title()}: {error}")
            messages.error(request, "Please correct the errors below.")
    else:
        form = StudentForm()
    context = {
        'page_title': f'Create Student Profile for {user.get_full_name()}',
        'form': form,
        'target_user': user,
    }
    return render(request, 'users/student_profile_form.html', context)


@login_required
@user_passes_test(lambda u: is_admin(u) or is_student(u) or is_teacher(u) or is_parent(u),
                  login_url='users:dashboard')
def student_profile_detail_view(request, pk):
    student_profile = get_object_or_404(Student.objects.select_related(
        'user', 'current_class__class_teacher__user', 'academic_session', 'parent__user'
    ), pk=pk)

    if is_student(request.user) and student_profile.user != request.user:
        messages.error(request, "You are not authorized to view this student's profile.")
        return redirect('users:my_profile')
    elif is_parent(
            request.user) and student_profile.parent and request.user.parent_profile != student_profile.parent:
        messages.error(request, "You are not authorized to view this child's profile.")
        return redirect('users:dashboard')
    elif is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        if student_profile.current_class and not ClassSubjectAssignment.objects.filter(
                class_obj=student_profile.current_class,
                teacher=teacher_profile,
                academic_session=student_profile.academic_session
        ).exists():
            messages.error(request, "You are not authorized to view this student's profile.")
            return redirect('users:dashboard')
    # Removed the generic "You are not authorized" message to avoid double messages
    # if none of the above conditions are met, the user is authorized (e.g., admin)

    current_class = student_profile.current_class
    homeroom_teacher = None
    if current_class and current_class.class_teacher:
        homeroom_teacher = current_class.class_teacher

    # Define current_academic_session for this view
    current_academic_session = AcademicSession.objects.filter(is_current=True).first()

    recent_marks_queryset = StudentExamMark.objects.filter(
        student=student_profile,
        academic_session=student_profile.academic_session
    ).select_related('subject', 'exam_type').order_by('-recorded_at')[:5]

    recent_exam_marks_for_template = []
    for mark in recent_marks_queryset:
        total_max_marks = 'N/A'
        exam_structure = ExamStructure.objects.filter(
            exam_type=mark.exam_type,
            subject=mark.subject,
            exam_type__academic_session=mark.academic_session # Corrected filter
        ).first()
        if exam_structure:
            total_max_marks = exam_structure.total_max_marks
        recent_exam_marks_for_template.append({
            'exam_type_name': mark.exam_type.name,
            'subject_name': mark.subject.name,
            'total_marks_obtained': mark.total_marks_obtained,
            'total_max_marks': total_max_marks,
            'pass_status': mark.pass_status,
            'recorded_at': mark.recorded_at,
        })
    context = {
        'page_title': f'{student_profile.user.get_full_name()}\'s Profile',
        'student_profile': student_profile,
        'current_class': current_class,
        'homeroom_teacher': homeroom_teacher,
        'recent_exam_marks': recent_exam_marks_for_template,
        'recent_class_test_marks': ClassTestMark.objects.filter(
            student=student_profile,
            class_test__academic_session=student_profile.academic_session
        ).select_related('class_test__subject').order_by('-recorded_at')[:5],
        'gpa_trend': [
            {'semester': 'Sem 1', 'gpa': 3.5},
            {'semester': 'Sem 2', 'gpa': 3.7},
            {'semester': 'Sem 3', 'gpa': 3.6},
        ],
        'my_attendance_records': AttendanceRecord.objects.filter(
            student=student_profile,
            date__gte=timezone.now().date() - timedelta(days=30),
            academic_session=current_academic_session
        ).order_by('date'),
        'attendance_data_json': json.dumps({
            str(record.date): "Present" if record.is_present else "Absent"
            for record in AttendanceRecord.objects.filter(
                student=student_profile,
                date__gte=timezone.now().date() - timedelta(days=30),
                academic_session=current_academic_session
            ).order_by('date')
        }),
        'attendance_summary': (lambda records: {
            'total_days': records.count(),
            'present_days': records.filter(is_present=True).count(),
            'absent_days': records.filter(is_present=False).count(),
            'percentage': round(
                (records.filter(is_present=True).count() / records.count() * 100) if records.count() > 0 else 0, 2)
        })(AttendanceRecord.objects.filter(
            student=student_profile,
            date__gte=timezone.now().date() - timedelta(days=30),
            academic_session=current_academic_session
        )),
        'recent_submissions': AssignmentSubmission.objects.filter(
            student=student_profile,
            assignment__academic_session=student_profile.academic_session
        ).select_related('assignment__subject').order_by('-submission_date')[:5],
        'fees_and_payments': (lambda student_profile_obj: [
            {
                'fee': fee,
                'total_paid':
                    FeePayment.objects.filter(student=student_profile_obj, fee=fee).aggregate(Sum('amount_paid'))[
                        'amount_paid__sum'] or 0,
                'balance': fee.amount - (FeePayment.objects.filter(student=student_profile_obj, fee=fee).aggregate(
                    Sum('amount_paid'))['amount_paid__sum'] or 0),
                'payments': FeePayment.objects.filter(student=student_profile_obj, fee=fee).order_by('-payment_date')
            } for fee in Fee.objects.filter(academic_session=student_profile_obj.academic_session)
        ])(student_profile) if student_profile.academic_session else [],
        'upcoming_exams': ExamSchedule.objects.filter(
            class_obj=current_class,
            exam__academic_session=student_profile.academic_session,
            exam_date__gte=date.today()
        ).order_by('exam_date', 'start_time').select_related('exam', 'class_obj', 'subject')[:5],
    }
    return render(request, 'users/student_profile_detail_view.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def student_profile_update(request, pk):
    student = get_object_or_404(Student, pk=pk)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'Student profile for {student.user.email} updated successfully!')
            return redirect('users:student_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = StudentForm(instance=student)
    context = {
        'page_title': f'Update Student Profile for {student.user.get_full_name()}',
        'form': form,
        'action': 'update',
        'target_user': student.user
    }
    return render(request, 'users/student_profile_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def student_profile_delete(request, pk):
    student_profile = get_object_or_404(Student, pk=pk)
    user_obj = student_profile.user
    if request.method == 'POST':
        try:
            user_obj.delete()
            messages.success(request, 'Student profile deleted successfully!')
            return redirect('users:user_list')
        except Exception as e:
            messages.error(request, f"Error deleting user: {e}")
            return redirect('users:user_list')

    context = {
        'page_title': 'Confirm Delete User',
        'object': user_obj,
        'confirm_message': f"Are you sure you want to delete the account for {user_obj.get_full_name()} ({user_obj.role})? This action cannot be undone."
    }
    return render(request, 'users/confirm_delete.html', context)


# --- Teacher Profile Views (Admin) ---

@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def teacher_list(request):
    teachers = TeacherProfile.objects.all().order_by('user__last_name', 'user__first_name')
    paginator = Paginator(teachers, 10)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    context = {
        'page_title': 'Teacher List',
        'page_obj': page_obj,
    }
    return render(request, 'users/teacher_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def teacher_profile_create(request):
    messages.info(request, "Please create a new user and select 'Teacher' role to add a new teacher profile.")
    return redirect('users:user_create')


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def teacher_profile_delete(request, pk):
    teacher_profile = get_object_or_404(TeacherProfile, pk=pk)
    user_obj = teacher_profile.user
    if request.method == 'POST':
        user_obj.delete()
        messages.success(request, 'Teacher profile deleted successfully!')
        return redirect('users:user_list')
    return render(request, 'users/confirm_delete.html',
                  {'object': user_obj,
                   'page_title': 'Delete Teacher Profile'})


# --- Parent Profile Views (Admin) ---

@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def parent_list(request):
    parents = ParentProfile.objects.all().order_by('user__last_name', 'user__first_name')
    paginator = Paginator(parents, 10)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    context = {
        'page_title': 'Parent List',
        'page_obj': page_obj,
    }
    return render(request, 'users/parent_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def parent_profile_create(request):
    messages.info(request, "Please create a new user and select 'Parent' role to add a new parent profile.")
    return redirect('users:user_create')


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def parent_profile_delete(request, pk):
    parent_profile = get_object_or_404(ParentProfile, pk=pk)
    user_obj = parent_profile.user
    if request.method == 'POST':
        user_obj.delete()
        messages.success(request, 'Parent profile deleted successfully!')
        return redirect('users:user_list')
    return render(request, 'users/confirm_delete.html',
                  {'object': user_obj,
                   'page_title': 'Delete Parent Profile'})


@login_required
@user_passes_test(is_parent, login_url='users:dashboard')
def parent_child_list(request):
    # Use try-except to gracefully handle cases where ParentProfile might not exist
    try:
        parent_profile = ParentProfile.objects.get(user=request.user)
    except ParentProfile.DoesNotExist:
        messages.error(request, "Your parent profile is incomplete. Please contact an administrator.")
        return redirect('users:dashboard')  # Redirect to dashboard if parent profile is missing

    children = Student.objects.filter(parent=parent_profile).select_related('user', 'current_class__academic_session')
    context = {
        'parent_profile': parent_profile,
        'children': children,
        'page_title': 'My Children'
    }

    # If no children are linked, show a message and still render the parent_child_list template
    if not children.exists():
        messages.info(request,
                      "No children are currently linked to your account. Please contact the administrator if this is incorrect.")
        # Render the parent_child_list.html template directly, instead of redirecting
        # This allows the message to be displayed on the 'My Children' page itself.
        return render(request, 'users/parent_child_list.html', context)

    # The rest of the logic for populating dashboard widgets for parent_child_list
    # This part was copied from the dashboard view for parents.
    # Define current_academic_session for this view (if needed for dashboard widgets)
    current_academic_session = AcademicSession.objects.filter(is_current=True).first()
    context['current_academic_session'] = current_academic_session

    all_children_upcoming_exams = []
    all_children_upcoming_assignments = []
    all_children_attendance = []
    all_children_recent_marks = []
    all_children_recent_ct_marks = []

    for child in context['children']:
        child_current_class = child.current_class
        child_academic_session = child.academic_session

        if child_current_class and child_academic_session:
            child_exams = ExamSchedule.objects.filter(
                class_obj=child_current_class,
                exam__academic_session=child_academic_session,
                exam_date__gte=timezone.now().date()
            ).order_by('exam_date', 'start_time')[:3]
            all_children_upcoming_exams.extend(list(child_exams))

            child_assignments = Assignment.objects.filter(
                class_obj=child_current_class,
                academic_session=child_academic_session,
                due_date__gte=timezone.now().date()
            ).order_by('due_date')[:3]
            all_children_upcoming_assignments.extend(list(child_assignments))

            child_attendance = AttendanceRecord.objects.filter(
                student=child,
                academic_session=child_academic_session,
                date__gte=timezone.now().date() - timedelta(days=7)
            ).order_by('-date')[:5]
            all_children_attendance.extend(list(child_attendance))

            child_recent_exam_marks_queryset = StudentExamMark.objects.filter(
                student=child,
                academic_session=child_academic_session
            ).select_related('subject', 'exam_type').order_by('-recorded_at')[:3]

            child_recent_exam_marks_for_template = []
            for mark in child_recent_exam_marks_queryset:
                total_max_marks = 'N/A'
                exam_structure = ExamStructure.objects.filter(
                    exam_type=mark.exam_type,
                    subject=mark.subject,
                    exam_type__academic_session=mark.academic_session # Corrected filter
                ).first()
                if exam_structure:
                    total_max_marks = exam_structure.total_max_marks
                child_recent_exam_marks_for_template.append({
                    'mark_obj': mark,
                    'student_full_name': mark.student.user.get_full_name(),
                    'exam_type_name': mark.exam_type.name,
                    'subject_name': mark.subject.name,
                    'total_marks_obtained': mark.total_marks_obtained,
                    'total_max_marks': total_max_marks,
                    'pass_status': mark.pass_status,
                    'recorded_at': mark.recorded_at,
                })
            all_children_recent_marks.extend(list(child_recent_exam_marks_for_template))

            child_recent_ct_marks = ClassTestMark.objects.filter(
                student=child,
                class_test__academic_session=child_academic_session
            ).select_related('class_test__subject').order_by('-recorded_at')[:3]
            all_children_recent_ct_marks.extend(list(child_recent_ct_marks))

    context['upcoming_exams'] = sorted(all_children_upcoming_exams, key=lambda x: (x.exam_date, x.start_time))[:5]
    context['upcoming_assignments'] = sorted(all_children_upcoming_assignments, key=lambda x: x.due_date)[:5]
    context['children_attendance'] = sorted(all_children_attendance, key=lambda x: x.date, reverse=True)[:5]
    context['children_recent_exam_marks'] = sorted(all_children_recent_marks, key=lambda x: x['recorded_at'],
                                                   reverse=True)[:5]
    context['children_recent_ct_marks'] = sorted(all_children_recent_ct_marks, key=lambda x: x.recorded_at,
                                                 reverse=True)[:5]

    context['recent_notices'] = Notice.objects.filter(
        Q(target_roles='all') | Q(target_roles='parent') | Q(
            target_classes__in=[child.current_class for child in children if child.current_class])
    ).filter(is_active=True).distinct().order_by('-published_date')[:5]

    # Render the parent_child_list.html template if children exist
    return render(request, 'users/parent_child_list.html', context)


# --- User's Own Profile and Password Change ---
@login_required
def user_profile_view(request):
    user_obj = request.user
    user_form = None
    profile_form = None
    profile_instance = None

    # Determine the correct profile instance based on user role
    if is_student(user_obj):
        profile_instance, created = Student.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A student profile was automatically created for your user as it was missing.")
    elif is_teacher(user_obj):
        profile_instance, created = TeacherProfile.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A teacher profile was automatically created for your user as it was missing.")
    elif is_parent(user_obj):
        profile_instance, created = ParentProfile.objects.get_or_create(user=user_obj)
        if created:
            messages.info(request, "A parent profile was automatically created for your user as it was missing.")

    if request.method == 'POST':
        # Instantiate user form with POST data and current user instance
        user_form = CustomUserChangeForm(request.POST, instance=user_obj, request=request)

        # Instantiate profile form based on role
        if is_student(user_obj):
            profile_form = StudentForm(request.POST, instance=profile_instance)
        elif is_teacher(user_obj):
            profile_form = TeacherProfileForm(request.POST, instance=profile_instance)
        elif is_parent(user_obj):
            profile_form = ParentProfileForm(request.POST, instance=profile_instance)
        # No profile_form for admin role

        # Validate both forms (if profile_form exists)
        if user_form.is_valid() and (profile_form is None or profile_form.is_valid()):
            user_form.save()  # This also handles password change if provided

            if profile_form:
                profile_form.save()

            messages.success(request, 'Your profile has been updated successfully!')
            return redirect('users:my_profile')  # Redirect to the same page to show updates
        else:
            # Display errors if forms are not valid
            if not user_form.is_valid():
                for field, errors in user_form.errors.items():
                    for error in errors:
                        messages.error(request, f"Account - {field.replace('_', ' ').title()}: {error}")
                if user_form.non_field_errors():
                    for error in user_form.non_field_errors():
                        messages.error(request, f"Account - {error}")

            if profile_form and not profile_form.is_valid():
                for field, errors in profile_form.errors.items():
                    for error in errors:
                        messages.error(request, f"Profile - {field.replace('_', ' ').title()}: {error}")
    else:
        # For GET request, instantiate forms with existing data
        user_form = CustomUserChangeForm(instance=user_obj, request=request)

        if is_student(user_obj):
            profile_form = StudentForm(instance=profile_instance)
        elif is_teacher(user_obj):
            profile_form = TeacherProfileForm(instance=profile_instance)
        elif is_parent(user_obj):
            profile_form = ParentProfileForm(instance=profile_instance)

    context = {
        'page_title': 'My Profile',
        'user_obj': user_obj,
        'user_form': user_form,
        'profile_form': profile_form,
    }
    return render(request, 'users/my_profile.html', context)


@login_required
def password_change_view(request):
    if request.method == 'POST':
        form = AuthPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important! Keeps the user logged in
            messages.success(request, 'Your password was successfully updated!')
            # If force_password_change was true, set it to false after successful change
            if user.force_password_change:
                user.force_password_change = False
                user.save()
            return redirect('users:my_profile')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AuthPasswordChangeForm(user=request.user)
    context = {
        'page_title': 'Change Password',
        'form': form,
    }
    return render(request, 'users/password_change.html', context)


@login_required
@require_POST
def send_message_view(request):
    recipient_id = request.POST.get('recipient_id')
    subject = request.POST.get('subject')
    message_content = request.POST.get('message')

    if not recipient_id or not subject or not message_content:
        messages.error(request, "All fields (recipient, subject, message) are required.")
        return JsonResponse({'status': 'error', 'message': 'All fields are required.'}, status=400)

    try:
        recipient_user = CustomUser.objects.get(pk=recipient_id)
        # In a real application, you would save this message to a Message model
        # For now, we'll just simulate sending and provide feedback.
        print(
            f"Message from {request.user.email} to {recipient_user.email}: Subject='{subject}', Content='{message_content}'")
        messages.success(request, f"Message to {recipient_user.get_full_name()} sent successfully!")
        return JsonResponse({'status': 'success', 'message': 'Message sent successfully.'})
    except CustomUser.DoesNotExist:
        messages.error(request, "Recipient not found.")
        return JsonResponse({'status': 'error', 'message': 'Recipient not found.'}, status=404)
    except Exception as e:
        messages.error(request, f"Error sending message: {e}")
        return JsonResponse({'status': 'error', 'message': f'Error sending message: {e}'}, status=500)


# --- Bulk User Upload Views (Admin Only) ---
@login_required
@user_passes_test(is_admin, login_url="users:dashboard")
def bulk_user_upload_view(request):
    """
    Handles bulk user registration via Excel file upload.
    """
    upload_results = None

    if request.method == "POST":
        form = BulkUserUploadForm(request.POST, request.FILES)
        if form.is_valid():
            excel_file = request.FILES["excel_file"]
            file_content = io.BytesIO(excel_file.read())

            try:
                workbook = openpyxl.load_workbook(file_content)
                sheet = workbook.active

                headers = [
                    cell.value.strip() if cell.value else "" for cell in sheet[1]
                ]

                mandatory_headers = ["Role", "Email", "First Name", "Last Name"]
                missing_mandatory_headers = [
                    h for h in mandatory_headers if h not in headers
                ]
                if missing_mandatory_headers:
                    messages.error(
                        request,
                        f"Missing required columns: {', '.join(missing_mandatory_headers)}",
                    )
                    return render(
                        request,
                        "users/bulk_user_upload.html",
                        {
                            "form": form,
                            "page_title": "Bulk User Registration",
                            "upload_results": None,
                        },
                    )

                success_count = 0
                failure_count = 0
                failed_records = []
                generated_credentials = []
                existing_user_warnings = []
                partial_success_warnings = []

                all_rows_data = []
                for row_idx, row in enumerate(
                    sheet.iter_rows(min_row=2, values_only=True), start=2
                ):
                    row_data = {
                        headers[i]: value
                        for i, value in enumerate(row)
                        if i < len(headers)
                    }
                    all_rows_data.append({"row_number": row_idx, "data": row_data})

                parents_data = [
                    r
                    for r in all_rows_data
                    if r["data"].get("Role", "").lower() == "parent"
                ]
                other_users_data = [
                    r
                    for r in all_rows_data
                    if r["data"].get("Role", "").lower() != "parent"
                ]
                ordered_rows_data = parents_data + other_users_data

                with transaction.atomic():
                    for item in ordered_rows_data:
                        row_idx = item["row_number"]
                        row_data = item["data"]

                        email = str(row_data.get("Email", "")).strip().lower()
                        role = str(row_data.get("Role", "")).strip().lower()
                        first_name = str(row_data.get("First Name", "")).strip()
                        last_name = str(row_data.get("Last Name", "")).strip()
                        phone_number = (
                            str(row_data.get("Phone Number", "")).strip()
                            if row_data.get("Phone Number")
                            else ""
                        )
                        address = str(row_data.get("Address", "")).strip()
                        qualifications = str(row_data.get("Qualifications", "")).strip()
                        admission_number = str(
                            row_data.get("Admission Number", "")
                        ).strip()
                        uid = str(row_data.get("UID", "")).strip()
                        date_of_birth_raw = row_data.get("Date of Birth")
                        gender = str(row_data.get("Gender", "")).strip()
                        current_class_name = str(
                            row_data.get("Current Class Name", "")
                        ).strip()
                        academic_session_name = str(
                            row_data.get("Academic Session Name", "")
                        ).strip()
                        roll_number = str(row_data.get("Roll Number", "")).strip()
                        parent_email = (
                            str(row_data.get("Parent Email", "")).strip().lower()
                        )

                        row_errors = []
                        row_warnings = []

                        if not all([email, role, first_name, last_name]):
                            row_errors.append(
                                "Missing essential data (Email, Role, First Name, Last Name)."
                            )
                            failure_count += 1
                            failed_records.append(
                                {
                                    "row_number": row_idx,
                                    "email": email,
                                    "error": "; ".join(row_errors),
                                }
                            )
                            continue

                        if role not in [r.value for r in CustomUser.UserRole]:
                            row_errors.append(f"Invalid role '{role}'.")
                            failure_count += 1
                            failed_records.append(
                                {
                                    "row_number": row_idx,
                                    "email": email,
                                    "error": "; ".join(row_errors),
                                }
                            )
                            continue

                        try:
                            parsed_date_of_birth = None
                            if date_of_birth_raw:
                                if isinstance(date_of_birth_raw, datetime):
                                    parsed_date_of_birth = date_of_birth_raw.date()
                                elif isinstance(date_of_birth_raw, date):
                                    parsed_date_of_birth = date_of_birth_raw
                                else:
                                    date_str = str(date_of_birth_raw).split(" ")[0]
                                    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d-%m-%Y"):
                                        try:
                                            parsed_date_of_birth = datetime.strptime(
                                                date_str, fmt
                                            ).date()
                                            break
                                        except ValueError:
                                            continue

                            user, created = CustomUser.objects.get_or_create(
                                email=email
                            )
                            if not created:
                                if user.role != role:
                                    row_errors.append(
                                        f"User with email '{email}' already exists with role '{user.role}'."
                                    )
                                    failure_count += 1
                                    failed_records.append(
                                        {
                                            "row_number": row_idx,
                                            "email": email,
                                            "error": "; ".join(row_errors),
                                        }
                                    )
                                    continue
                                else:
                                    user.first_name = first_name
                                    user.last_name = last_name
                                    user.force_password_change = True
                                    user.save()
                                    existing_user_warnings.append(
                                        f"User '{email}' already exists. Updated basic details."
                                    )
                            else:
                                generated_password = "".join(
                                    random.choices(
                                        string.ascii_letters + string.digits, k=12
                                    )
                                )
                                user.first_name = first_name
                                user.last_name = last_name
                                user.role = role
                                user.set_password(generated_password)
                                user.is_active = True
                                user.force_password_change = True
                                user.save()
                                generated_credentials.append(
                                    {"email": email, "password": generated_password}
                                )

                            if role == "student":
                                student_profile, _ = Student.objects.get_or_create(
                                    user=user
                                )
                                student_profile.admission_number = (
                                    admission_number or student_profile.admission_number
                                )
                                student_profile.uid = uid
                                student_profile.date_of_birth = parsed_date_of_birth
                                student_profile.gender = gender

                                if current_class_name:
                                    class_obj = Class.objects.filter(
                                        name__iexact=current_class_name
                                    ).first()
                                    student_profile.current_class = class_obj
                                else:
                                    student_profile.current_class = None

                                if academic_session_name:
                                    academic_session_obj = (
                                        AcademicSession.objects.filter(
                                            name__iexact=academic_session_name
                                        ).first()
                                    )
                                    student_profile.academic_session = (
                                        academic_session_obj
                                    )
                                else:
                                    student_profile.academic_session = (
                                        AcademicSession.objects.filter(
                                            is_current=True
                                        ).first()
                                    )

                                student_profile.roll_number = roll_number

                                # ✅ Section
                                section_name = str(
                                    row_data.get("Section Name", "")
                                ).strip()
                                if section_name:
                                    section_obj = Section.objects.filter(
                                        name__iexact=section_name
                                    ).first()
                                    if section_obj:
                                        student_profile.section = section_obj
                                    else:
                                        row_warnings.append(
                                            f"Section '{section_name}' not found."
                                        )

                                # ✅ Division
                                division_name = str(
                                    row_data.get("Division Name", "")
                                ).strip()
                                if division_name:
                                    division_obj = Division.objects.filter(
                                        name__iexact=division_name
                                    ).first()
                                    if division_obj:
                                        student_profile.division = division_obj
                                    else:
                                        row_warnings.append(
                                            f"Division '{division_name}' not found."
                                        )

                                # ✅ Fee Category
                                fee_category_name = str(
                                    row_data.get("Fee Category Name", "")
                                ).strip()
                                if fee_category_name:
                                    fee_category_obj = (
                                        StudentFeeCategory.objects.filter(
                                            name__iexact=fee_category_name
                                        ).first()
                                    )
                                    if fee_category_obj:
                                        student_profile.fee_category = fee_category_obj
                                    else:
                                        row_warnings.append(
                                            f"Fee Category '{fee_category_name}' not found."
                                        )

                                if parent_email:
                                    try:
                                        parent_user = CustomUser.objects.get(
                                            email__iexact=parent_email, role="parent"
                                        )
                                        parent_profile_obj = ParentProfile.objects.get(
                                            user=parent_user
                                        )
                                        student_profile.parent = parent_profile_obj
                                    except (
                                        CustomUser.DoesNotExist,
                                        ParentProfile.DoesNotExist,
                                    ):
                                        row_warnings.append(
                                            f"Parent with email '{parent_email}' not found."
                                        )
                                        student_profile.parent = None
                                else:
                                    student_profile.parent = None

                                student_profile.save()

                            elif role == "teacher":
                                teacher_profile, _ = (
                                    TeacherProfile.objects.get_or_create(user=user)
                                )
                                teacher_profile.phone_number = phone_number
                                teacher_profile.address = address
                                teacher_profile.qualifications = qualifications
                                teacher_profile.save()

                            elif role == "parent":
                                parent_profile, _ = ParentProfile.objects.get_or_create(
                                    user=user
                                )
                                parent_profile.phone_number = phone_number
                                parent_profile.address = address
                                parent_profile.save()

                            if not row_errors:
                                success_count += 1
                                if row_warnings:
                                    partial_success_warnings.append(
                                        {
                                            "row_number": row_idx,
                                            "email": email,
                                            "warnings": "; ".join(row_warnings),
                                        }
                                    )
                            else:
                                failure_count += 1
                                failed_records.append(
                                    {
                                        "row_number": row_idx,
                                        "email": email,
                                        "error": "; ".join(row_errors),
                                    }
                                )

                        except Exception as e:
                            failure_count += 1
                            failed_records.append(
                                {
                                    "row_number": row_idx,
                                    "email": email,
                                    "error": f"Unhandled error: {str(e)}",
                                }
                            )

                credentials_download_url = None
                if generated_credentials:
                    download_key = str(uuid.uuid4())
                    request.session[f"bulk_credentials_{download_key}"] = (
                        generated_credentials
                    )
                    request.session.set_expiry(300)
                    credentials_download_url = reverse(
                        "users:download_bulk_credentials", args=[download_key]
                    )

                upload_results = {
                    "total_rows": sheet.max_row - 1,
                    "created_users_count": success_count,
                    "failure_count": failure_count,
                    "failed_records": failed_records,
                    "credentials_download_url": credentials_download_url,
                    "existing_user_warnings": existing_user_warnings,
                    "partial_success_warnings": partial_success_warnings,
                }

                if (
                    success_count > 0
                    and failure_count == 0
                    and not existing_user_warnings
                    and not partial_success_warnings
                ):
                    messages.success(
                        request,
                        f"Bulk upload completed successfully! {success_count} users processed.",
                    )
                else:
                    messages.warning(
                        request,
                        f"Bulk upload finished with {success_count} successes, {failure_count} failures, {len(existing_user_warnings)} existing user updates, and {len(partial_success_warnings)} partial successes.",
                    )

            except Exception as e:
                messages.error(request, f"Error processing Excel file: {e}")
                upload_results = {
                    "total_rows": 0,
                    "created_users_count": 0,
                    "failure_count": 0,
                    "failed_records": [
                        {"row_number": "N/A", "email": "N/A", "error": str(e)}
                    ],
                    "credentials_download_url": None,
                    "existing_user_warnings": [],
                    "partial_success_warnings": [],
                }

    else:
        form = BulkUserUploadForm()

    context = {
        "page_title": "Bulk User Registration",
        "form": form,
        "upload_results": upload_results,
    }
    return render(request, "users/bulk_user_upload.html", context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def download_bulk_credentials_view(request, download_key):
    """
    Allows admin to download the generated user credentials CSV.
    """
    credentials = request.session.get(f'bulk_credentials_{download_key}')

    if not credentials:
        # If credentials are not found, return a plain text response to avoid HTML download issue
        error_message = "Credentials download link expired or invalid. Please re-upload the file to generate new credentials."
        messages.error(request, error_message)
        # Return a simple HTTPResponse with plain text and no Content-Disposition
        return HttpResponse(error_message, content_type="text/plain", status=400)

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="new_user_credentials.csv"'

    writer = csv.writer(response)
    writer.writerow(['Email', 'Generated Password'])  # CSV Header
    for cred in credentials:
        writer.writerow([cred['email'], cred['password']])

    # Clear credentials from session after download
    del request.session[f'bulk_credentials_{download_key}']
    # Explicitly save the session after deletion
    request.session.save()

    return response
