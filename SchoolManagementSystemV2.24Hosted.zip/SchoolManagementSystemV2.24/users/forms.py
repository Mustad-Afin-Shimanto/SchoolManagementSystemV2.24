# SchoolManagementSystem/users/forms.py
from django import forms
from django.contrib.auth import get_user_model  # Import get_user_model for robust model access
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, AuthenticationForm, \
    PasswordChangeForm as DjangoAuthPasswordChangeForm  # Renamed to avoid conflict

from academic.models import Class, AcademicSession  # Import Class and AcademicSession model for StudentForm
from .models import TeacherProfile, Student, ParentProfile  # CustomUser is now accessed via get_user_model()

User = get_user_model()  # Get the custom user model

# Define the common Tailwind classes for most input types
# These include classes for basic styling, focus states, and now explicit background/height for visibility.
COMMON_TAILWIND_CLASSES = 'block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm bg-white min-h-10'
CHECKBOX_TAILWIND_CLASSES = 'h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500'


# Helper function to apply Tailwind classes consistently and add placeholders
def add_tailwind_classes(field, field_name=None):
    if hasattr(field.widget, 'attrs'):
        current_classes = field.widget.attrs.get('class', '').split()

        if isinstance(field.widget, forms.CheckboxInput):
            # For checkboxes, apply specific styling
            base_classes_to_add = CHECKBOX_TAILWIND_CLASSES.split()
        else:
            # For other input types, directly use COMMON_TAILWIND_CLASSES
            base_classes_to_add = COMMON_TAILWIND_CLASSES.split()

        # Merge new classes with existing ones, avoiding duplicates
        for cls in base_classes_to_add:
            if cls not in current_classes:
                current_classes.append(cls)

        field.widget.attrs['class'] = ' '.join(current_classes)

        # Add placeholder if not already set and field_name is provided,
        # but avoid adding placeholders to select (dropdown) fields as it can conflict with empty_label.
        if field_name and 'placeholder' not in field.widget.attrs and not isinstance(field.widget, forms.Select):
            placeholder_text = f"Enter {field_name.replace('_', ' ').title()}"
            field.widget.attrs['placeholder'] = placeholder_text

    # For ChoiceField (forms.Select), ensure placeholder is not set as it's typically handled by empty_label.
    if isinstance(field.widget, forms.Select):
        field.widget.attrs.pop('placeholder', None)


# --- User Authentication and Management Forms ---
class CustomAuthenticationForm(AuthenticationForm):
    """
    Custom authentication form to apply Tailwind CSS classes.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Apply Tailwind classes to username (email) and password fields
        self.fields['username'].widget.attrs['class'] = COMMON_TAILWIND_CLASSES
        self.fields['username'].widget.attrs['placeholder'] = 'Enter your email'
        self.fields['password'].widget.attrs['class'] = COMMON_TAILWIND_CLASSES
        self.fields['password'].widget.attrs['placeholder'] = 'Enter your password'


class CustomUserCreationForm(UserCreationForm):
    """
    A form for creating new users. Includes all the required fields, plus a role.
    """

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ('email', 'first_name', 'last_name', 'role')  # Removed 'username'
        field_classes = {'email': forms.EmailField}  # Explicitly define email field type

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


class CustomUserChangeForm(UserChangeForm):
    """
    A form for updating existing users.
    Allows admin to change role, but restricts non-admin from changing their own role.
    Includes fields for admin to change another user's password.
    """
    # Add new password fields for admin to change user's password
    new_password1 = forms.CharField(
        label="New password",
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
        strip=False,
        required=False,  # Make optional for update form
        help_text="Enter new password if you want to change it."
    )
    new_password2 = forms.CharField(
        label="New password confirmation",
        widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}),
        strip=False,
        required=False,  # Make optional for update form
        help_text="Enter the same password as above, for verification."
    )

    class Meta(UserChangeForm.Meta):
        model = User
        # ADDED 'new_password1' and 'new_password2' to fields
        fields = ('email', 'first_name', 'last_name', 'role', 'is_active', 'is_staff', 'is_superuser', 'groups',
                  'user_permissions', 'force_password_change', 'new_password1', 'new_password2')
        # Removed explicit 'field_classes' and 'widgets' to rely on add_tailwind_classes

    def __init__(self, *args, **kwargs):
        # Pop the 'request' argument before calling super().__init__
        self.request = kwargs.pop('request', None)
        super().__init__(*args, **kwargs)

        # Apply Tailwind classes to all fields by default
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)

        # Initially, set password fields to HiddenInput and remove their labels
        # This ensures they are hidden by default unless explicitly enabled.
        self.fields['new_password1'].widget = forms.HiddenInput()
        self.fields['new_password2'].widget = forms.HiddenInput()
        self.fields['new_password1'].required = False
        self.fields['new_password2'].required = False
        self.fields['new_password1'].label = ''
        self.fields['new_password2'].label = ''

        if self.request and self.request.user.is_authenticated:
            # Scenario 1: User is editing THEIR OWN profile (self.instance is the user being edited)
            if self.instance == self.request.user:
                # Always show password fields for the user's own profile
                self.fields['new_password1'].widget = forms.PasswordInput(attrs={
                    'autocomplete': 'new-password',
                    'class': COMMON_TAILWIND_CLASSES,  # Re-apply Tailwind classes
                    'placeholder': 'Enter new password'
                })
                self.fields['new_password2'].widget = forms.PasswordInput(attrs={
                    'autocomplete': 'new-password',
                    'class': COMMON_TAILWIND_CLASSES,  # Re-apply Tailwind classes
                    'placeholder': 'Confirm new password'
                })
                self.fields['new_password1'].label = "New password"
                self.fields['new_password2'].label = "Confirm new password"

                # Disable permission-related fields for non-superusers editing their own profile
                if not self.request.user.is_superuser:
                    self.fields['role'].disabled = True
                    self.fields['is_staff'].disabled = True
                    self.fields['is_superuser'].disabled = True
                    self.fields['groups'].disabled = True
                    self.fields['user_permissions'].disabled = True
                    self.fields['force_password_change'].disabled = True

            # Scenario 2: An admin is editing ANOTHER user's profile (self.instance is NOT request.user)
            else:  # This means self.instance is different from self.request.user
                # If the logged-in user (request.user) has the 'admin' role,
                # they should be able to change the password of the user being edited.
                if self.request.user.role == 'admin':
                    self.fields['new_password1'].widget = forms.PasswordInput(attrs={
                        'autocomplete': 'new-password',
                        'class': COMMON_TAILWIND_CLASSES,  # Re-apply Tailwind classes
                        'placeholder': 'Enter new password'
                    })
                    self.fields['new_password2'].widget = forms.PasswordInput(attrs={
                        'autocomplete': 'new-password',
                        'class': COMMON_TAILWIND_CLASSES,  # Re-apply Tailwind classes
                        'placeholder': 'Confirm new password'
                    })
                    self.fields['new_password1'].label = "New password"
                    self.fields['new_password2'].label = "Confirm new password"

                    # Ensure permission fields are editable by admin when editing others
                    self.fields['role'].disabled = False
                    self.fields['is_active'].disabled = False  # Ensure this is also editable by admin
                    self.fields['is_staff'].disabled = False
                    self.fields['is_superuser'].disabled = False
                    self.fields['groups'].disabled = False
                    self.fields['user_permissions'].disabled = False
                    self.fields['force_password_change'].disabled = False
                else:
                    # If a non-admin user (e.g., a teacher or student) somehow accesses this,
                    # ensure all fields are disabled for them. This is a fallback/safety.
                    for field_name, field in self.fields.items():
                        field.disabled = True

    def clean_new_password2(self):
        """
        Validate that the two new password entries match.
        Only perform this validation if both new password fields are provided.
        """
        new_password1 = self.cleaned_data.get('new_password1')
        new_password2 = self.cleaned_data.get('new_password2')

        if new_password1 and new_password2 and new_password1 != new_password2:
            raise forms.ValidationError("The two new password fields didn't match.")
        return new_password2

    def save(self, commit=True):
        user = super().save(commit=False)
        # Handle password change if new passwords are provided
        if self.cleaned_data.get('new_password1'):
            user.set_password(self.cleaned_data['new_password1'])
            user.force_password_change = False  # Reset force_password_change after manual update
        if commit:
            user.save()
        return user


# --- Profile Forms (Teacher, Student, Parent) ---
class TeacherProfileForm(forms.ModelForm):
    class Meta:
        model = TeacherProfile
        fields = ['phone_number', 'address', 'qualifications']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


class ParentProfileForm(forms.ModelForm):
    class Meta:
        model = ParentProfile
        fields = ['phone_number', 'address']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


class StudentForm(forms.ModelForm):
    # Add a field for parent email to link existing parents
    parent_email = forms.EmailField(
        label="Parent Email (optional, to link existing parent)",
        required=False,
        help_text="Enter the email of an existing parent user to link this student. Parent must exist in the system."
    )

    class Meta:
        model = Student
        # Ensure 'uid' and 'academic_session' are in fields
        fields = [
            "admission_number",
            "uid",
            "date_of_birth",
            "division",
            "section",
            "fee_category",
            "gender",
            "current_class",
            "academic_session",
            "roll_number",
        ]
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['current_class'].queryset = Class.objects.all().order_by('name')
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('name')
        # self.fields['parent'].queryset = ParentProfile.objects.all().order_by('user__last_name', 'user__first_name') # This field is now handled by parent_email

        # If instance exists, populate parent_email field
        if self.instance and self.instance.parent:
            self.fields['parent_email'].initial = self.instance.parent.user.email

    def clean_parent_email(self):
        parent_email = self.cleaned_data.get('parent_email')
        if parent_email:
            try:
                parent_user = User.objects.get(email=parent_email, role='parent')
                return parent_user.parent_profile  # Return the ParentProfile instance
            except User.DoesNotExist:
                raise forms.ValidationError("Parent user with this email does not exist or is not a parent.")
            except ParentProfile.DoesNotExist:
                raise forms.ValidationError(
                    "Parent profile for this user does not exist. Please ensure the parent user has a profile.")
        return None  # Allow parent_email to be blank

    def save(self, commit=True):
        student = super().save(commit=False)
        parent_profile = self.cleaned_data.get('parent_email')  # This now holds the ParentProfile instance or None
        student.parent = parent_profile  # Assign the ParentProfile instance

        if commit:
            student.save()
        return student


# Custom Password Change Form with explicit widget styling
class AuthPasswordChangeForm(DjangoAuthPasswordChangeForm):  # Inherit from Django's original form
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Apply widgets and placeholders directly for each password field
        # This is the most robust way to ensure attributes are set
        self.fields['old_password'].widget.attrs = {
            'class': COMMON_TAILWIND_CLASSES,  # Use the common classes constant
            'autocomplete': 'current-password',
            'placeholder': 'Enter old password'
        }
        self.fields['new_password1'].widget.attrs = {
            'class': COMMON_TAILWIND_CLASSES,  # Use the common classes constant
            'autocomplete': 'new-password',
            'placeholder': 'Enter new password'
        }
        self.fields['new_password2'].widget.attrs = {
            'class': COMMON_TAILWIND_CLASSES,  # Use the common classes constant
            'autocomplete': 'new-password',
            'placeholder': 'Confirm new password'
        }


# NEW FORM FOR BULK USER UPLOAD
class BulkUserUploadForm(forms.Form):
    """
    Form for uploading an Excel file for bulk user registration.
    """
    excel_file = forms.FileField(
        label="Upload Excel File (.xlsx)",
        help_text="Upload an Excel file containing user data for bulk registration. "
                  "See the template for required columns.",
        widget=forms.FileInput(attrs={
            'class': 'block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100'})
    )

    def clean_excel_file(self):
        excel_file = self.cleaned_data['excel_file']
        if not excel_file.name.endswith('.xlsx'):
            raise forms.ValidationError("Only .xlsx Excel files are allowed.")
        return excel_file
