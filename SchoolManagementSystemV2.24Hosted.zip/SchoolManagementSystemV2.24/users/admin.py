# SchoolManagementSystem/users/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .forms import CustomUserCreationForm, CustomUserChangeForm
from .models import CustomUser, TeacherProfile, Student, ParentProfile


# Admin for CustomUser (using Django's UserAdmin)
@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    add_form = CustomUserCreationForm
    form = CustomUserChangeForm
    model = CustomUser
    list_display = ('email', 'first_name', 'last_name', 'role', 'is_staff', 'is_active',
                    'force_password_change')  # ADDED 'force_password_change'
    list_filter = ('role', 'is_staff', 'is_active', 'force_password_change')  # ADDED 'force_password_change'
    search_fields = ('email', 'first_name', 'last_name')
    ordering = ('email',)

    # fieldsets for editing an existing user
    fieldsets = (
        (None, {'fields': ('email',)}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'role', 'force_password_change')}),
        # ADDED 'force_password_change'
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
        ('Password Change', {'fields': ('new_password1', 'new_password2'), 'classes': ('collapse',)}),
    )
    # add_fieldsets for creating a new user
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'first_name', 'last_name', 'role', 'password1', 'password2', 'force_password_change'),
            # ADDED 'force_password_change'
        }),
    )

    # Override get_form and get_add_form to pass the request to the form
    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.request = request  # Pass the request to the form instance
        return form

    def get_add_form(self, request, **kwargs):
        form = super().get_add_form(request, **kwargs)
        form.request = request  # Pass the request to the form instance
        return form


# Admin for TeacherProfile
@admin.register(TeacherProfile)
class TeacherProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'address', 'date_of_joining', 'qualifications')
    list_filter = ('date_of_joining',)
    search_fields = ('user__email', 'user__first_name', 'user__last_name', 'phone_number')
    raw_id_fields = ('user',)
    ordering = ('user__last_name', 'user__first_name')


# Admin for ParentProfile
@admin.register(ParentProfile)
class ParentProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'address')
    search_fields = ('user__email', 'user__first_name', 'user__last_name', 'phone_number')
    raw_id_fields = ('user',)
    ordering = ('user__last_name', 'user__first_name')


# Admin for Student
@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = (
        "user",
        "admission_number",
        "uid",
        "current_class",
        "parent",
        "date_of_birth",
        "gender",
        "section",
        "fee_category",
    )  # ADDED 'uid'
    list_filter = ("current_class", "gender", "parent", "section", "fee_category")
    search_fields = ('user__email', 'user__first_name', 'user__last_name', 'admission_number', 'uid')  # ADDED 'uid'
    raw_id_fields = ('user', 'current_class', 'parent')
    ordering = ('user__last_name', 'user__first_name')
