# SchoolManagementSystem/users/urls.py
from django.urls import path

from . import views

app_name = 'users'  # Added app_name for namespacing

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    # User Management (Admin Only)
    path('users/', views.user_list, name='user_list'),
    path('users/create/', views.user_create, name='user_create'),
    path('users/<int:pk>/update/', views.user_update, name='user_update'),
    # This is the target URL for editing user info
    path('users/<int:pk>/delete/', views.user_delete, name='user_delete'),

    # Student Profiles
    # Updated student_list URL to accept optional query parameters for filtering and pagination
    path('students/', views.student_list, name='student_list'),
    path('students/create_profile/<int:user_pk>/', views.student_create_profile, name='student_create_profile'),
    path('students/<int:pk>/', views.student_profile_detail_view, name='student_profile_detail_view'),
    path('students/<int:pk>/update/', views.user_update, name='student_profile_update'),
    path('students/<int:pk>/delete/', views.student_profile_delete, name='student_profile_delete'),

    # Teacher Profiles
    path('teachers/', views.teacher_list, name='teacher_list'),
    path('teachers/create/', views.teacher_profile_create, name='teacher_profile_create'),
    path('teachers/<int:pk>/update/', views.user_update, name='teacher_profile_update'),
    path('teachers/<int:pk>/delete/', views.teacher_profile_delete, name='teacher_profile_delete'),

    # Parent Profiles
    path('parents/', views.parent_list, name='parent_list'),
    path('parents/create/', views.parent_profile_create, name='parent_profile_create'),
    path('parents/<int:pk>/update/', views.user_update, name='parent_profile_update'),
    path('parents/<int:pk>/delete/', views.parent_profile_delete, name='parent_profile_delete'),
    path('parents/children/', views.parent_child_list, name='parent_child_list'),

    # User's Own Profile and Password Change
    path('profile/', views.user_profile_view, name='my_profile'),
    path('password_change/', views.password_change_view, name='password_change'),

    # Message Sending (AJAX endpoint - assuming these are still needed and views exist)
    path('send_message/', views.send_message_view, name='send_message'),
    # Temporarily commented out to avoid conflicts if not fully implemented yet
    # path('notifications/', views.notification_list_view, name='notification_list'),
    # path('notifications/<int:pk>/read/', views.mark_notification_read, name='mark_notification_read'),

    # NEW: Bulk User Upload URLs (Admin Only)
    path('bulk-upload/', views.bulk_user_upload_view, name='bulk_user_upload'),
    path('bulk-upload/download-credentials/<str:download_key>/', views.download_bulk_credentials_view,
         name='download_bulk_credentials'),
]
