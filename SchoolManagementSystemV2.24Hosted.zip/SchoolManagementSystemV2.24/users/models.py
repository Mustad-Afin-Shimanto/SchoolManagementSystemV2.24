# SchoolManagementSystem/users/models.py
import uuid  # Import uuid for unique ID generation

from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.utils.translation import gettext_lazy as _


class CustomUserManager(BaseUserManager):
    """
    Custom user model manager where email is the unique identifiers
    for authentication instead of usernames.
    """

    def create_user(self, email, password, **extra_fields):
        """
        Create and save a User with the given email and password.
        """
        if not email:
            raise ValueError(_('The Email must be set'))
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save()
        return user

    def create_superuser(self, email, password, **extra_fields):
        """
        Create and save a SuperUser with the given email and password.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)
        extra_fields.setdefault('role', 'admin')  # Default role for superuser

        if extra_fields.get('is_staff') is not True:
            raise ValueError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValueError(_('Superuser must have is_superuser=True.'))

        # Ensure that a superuser cannot be created with a non-admin role
        if extra_fields.get('role') != 'admin':
            raise ValueError(_('Superuser must have role="admin".'))

        return self.create_user(email, password, **extra_fields)


class CustomUser(AbstractUser):
    """
    Custom User model extending Django's AbstractUser.
    Uses email as the unique identifier instead of username.
    Adds a 'role' field for role-based access control.
    """

    class UserRole(models.TextChoices):
        ADMIN = 'admin', _('Admin')
        TEACHER = 'teacher', _('Teacher')
        STUDENT = 'student', _('Student')
        PARENT = 'parent', _('Parent')

    username = None  # Remove username field
    email = models.EmailField(_('email address'), unique=True)
    role = models.CharField(max_length=10, choices=UserRole.choices, default=UserRole.STUDENT)
    force_password_change = models.BooleanField(default=False,
                                                help_text="If checked, user must change password on next login.")  # NEW FIELD

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name', 'role']  # Email is implicitly required by USERNAME_FIELD

    objects = CustomUserManager()

    def __str__(self):
        return self.email

    def get_full_name(self):
        """
        Returns the first_name plus the last_name, with a space in between.
        """
        full_name = '%s %s' % (self.first_name, self.last_name)
        return full_name.strip()

    def get_short_name(self):
        """
        Returns the short name for the user.
        """
        return self.first_name

    class Meta:
        verbose_name = _('user')
        verbose_name_plural = _('users')
        # Add constraints or indexes if necessary for performance or data integrity
        # Example: models.UniqueConstraint(fields=['email', 'role'], name='unique_email_role')


class TeacherProfile(models.Model):
    """
    Profile information for teachers.
    One-to-one relationship with CustomUser.
    """
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True, related_name='teacher_profile')
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    qualifications = models.TextField(blank=True, null=True)
    date_of_joining = models.DateField(auto_now_add=True)

    # Add other teacher-specific fields as needed

    class Meta:
        verbose_name = "Teacher Profile"
        verbose_name_plural = "Teacher Profiles"
        ordering = ['user__last_name', 'user__first_name']

    def __str__(self):
        return f"Teacher: {self.user.get_full_name()}"


class ParentProfile(models.Model):
    """
    Profile information for parents.
    One-to-one relationship with CustomUser.
    """
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True, related_name='parent_profile')
    phone_number = models.CharField(max_length=20, blank=True, null=True)
    address = models.TextField(blank=True, null=True)

    # Add other parent-specific fields as needed

    class Meta:
        verbose_name = "Parent Profile"
        verbose_name_plural = "Parent Profiles"
        ordering = ['user__last_name', 'user__first_name']

    def __str__(self):
        return f"Parent: {self.user.get_full_name()}"


class Student(models.Model):
    """
    Profile information for students.
    One-to-one relationship with CustomUser.
    """
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, primary_key=True, related_name='student_profile')
    admission_number = models.CharField(max_length=50, unique=True, blank=True, null=True,
                                        help_text="Unique admission number for the student.")
    uid = models.CharField(max_length=100, unique=True, blank=True, null=True,
                           help_text="Unique ID for Education (national identifier).")  # NEW FIELD
    date_of_birth = models.DateField(blank=True, null=True)  # MODIFIED: Added blank=True, null=True
    gender = models.CharField(max_length=10, blank=True, null=True,
                              choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')])
    # FIXED: Use string reference for 'academic.Class' to break circular import
    current_class = models.ForeignKey('academic.Class', on_delete=models.SET_NULL, null=True, blank=True,
                                      related_name='students')
    parent = models.ForeignKey(ParentProfile, on_delete=models.SET_NULL, null=True, blank=True, related_name='children')
    roll_number = models.CharField(max_length=20, unique=False, blank=True, null=True,  # Changed unique to False
                                   help_text="Roll number within the current class.")
    academic_session = models.ForeignKey('academic.AcademicSession', on_delete=models.SET_NULL, blank=True, null=True,
                                         related_name='students_in_session')  # Added academic_session
    division = models.ForeignKey(
        "academic.Division",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="students",
    )
    section = models.ForeignKey(
        "academic.Section",  # string reference instead of direct import
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="students",
    )
    fee_category = models.ForeignKey(
        'academic.StudentFeeCategory',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='students')

    def save(self, *args, **kwargs):
        if not self.admission_number:
            # Generate a unique admission number if not provided
            self.admission_number = str(uuid.uuid4())[:10].replace('-', '')  # Example: first 10 chars of a UUID
        super().save(*args, **kwargs)

    class Meta:
        verbose_name = "Student"
        verbose_name_plural = "Students"
        ordering = ['current_class__name', 'roll_number', 'user__last_name']
        # Add a unique constraint for roll_number within a class and academic session
        unique_together = ('roll_number', 'current_class', 'academic_session')

    def __str__(self):
        # Handle case where admission_number might still be None before save or if it's not set
        return f"Student: {self.user.get_full_name()} ({self.admission_number or 'N/A'})"
