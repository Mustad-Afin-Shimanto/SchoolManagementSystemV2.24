# SchoolManagementSystem/marks/models.py
from decimal import Decimal

from django.core.validators import MinValueValidator, MaxValueValidator, ValidationError
from django.db import models
from django.utils import timezone

# Import models from other apps for foreign keys
# Explicitly import to ensure resolution and prevent potential circular import issues during startup
from academic.models import AcademicSession, Class, Subject, ClassSubjectAssignment
from users.models import Student, TeacherProfile, CustomUser


class ExamType(models.Model):
    """Defines types of exams (e.g., Midterm, Final, Quiz)."""

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    academic_session = models.ForeignKey(
        AcademicSession, on_delete=models.CASCADE, related_name="exam_types"
    )
    is_final_exam = models.BooleanField(
        default=False, help_text="Designate as the final exam for grade calculation."
    )
    is_active = models.BooleanField(
        default=True, help_text="Designates whether this exam type is currently active."
    )  # NEW FIELD
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="exam_types_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="exam_types_updated",
    )

    class Meta:
        verbose_name = "Exam Type"
        verbose_name_plural = "Exam Types"
        ordering = ["-academic_session__start_date", "name"]
        unique_together = ("name", "academic_session")

    def __str__(self):
        return f"{self.name} ({self.academic_session.name})"

    def clean(self):
        # Ensure only one final exam type per academic session
        if self.is_final_exam:
            if (
                ExamType.objects.filter(
                    academic_session=self.academic_session, is_final_exam=True
                )
                .exclude(pk=self.pk)
                .exists()
            ):
                raise ValidationError(
                    {
                        "is_final_exam": "Only one exam type can be designated as the final exam per academic session."
                    }
                )

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation including unique_together and clean method
        super().save(*args, **kwargs)


class ExamStructure(models.Model):
    """
    Defines the mark distribution for a specific subject within an exam type.
    E.g., For "Midterm Exam" and "Physics", Written: 50, MCQ: 25, Practical: 25.
    """

    exam_type = models.ForeignKey(
        ExamType, on_delete=models.CASCADE, related_name="exam_structures"
    )
    subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="exam_structures"
    )
    written_max_marks = models.DecimalField(
        max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0)]
    )
    mcq_max_marks = models.DecimalField(
        max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0)]
    )
    practical_max_marks = models.DecimalField(
        max_digits=5, decimal_places=2, default=0, validators=[MinValueValidator(0)]
    )
    total_max_marks = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="exam_structures_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="exam_structures_updated",
    )

    class Meta:
        verbose_name = "Exam Structure"
        verbose_name_plural = "Exam Structures"
        unique_together = ("exam_type", "subject")
        ordering = ["exam_type__name", "subject__name"]

    def __str__(self):
        return f"{self.exam_type.name} - {self.subject.name}"

    def clean(self):
        # Calculate total_max_marks before saving
        self.total_max_marks = (
            self.written_max_marks + self.mcq_max_marks + self.practical_max_marks
        )
        if self.total_max_marks != 100:
            # Modified: Raise a non-field error instead of a field-specific error
            raise ValidationError(
                "The sum of Written, MCQ, and Practical marks must total 100."
            )

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation including unique_together and clean method
        super().save(*args, **kwargs)


class StudentExamMark(models.Model):
    """
    Records a student's marks for a specific exam (e.g., Midterm, Final) in a subject.
    """

    academic_session = models.ForeignKey(
        AcademicSession, on_delete=models.CASCADE, related_name="exam_marks"
    )
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="exam_marks"
    )
    subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="exam_marks"
    )
    exam_type = models.ForeignKey(
        ExamType, on_delete=models.CASCADE, related_name="exam_marks"
    )
    student = models.ForeignKey(
        Student, on_delete=models.CASCADE, related_name="exam_marks"
    )
    # Marks can be null if not applicable or not yet entered
    written_marks = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    mcq_marks = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    practical_marks = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    total_marks_obtained = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True
    )
    remarks = models.TextField(blank=True, null=True)
    pass_status = models.BooleanField(default=False)
    recorded_at = models.DateTimeField(auto_now_add=True)
    recorded_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="recorded_exam_marks",
    )

    class Meta:
        verbose_name = "Student Exam Mark"
        verbose_name_plural = "Student Exam Marks"
        unique_together = (
            "academic_session",
            "class_obj",
            "subject",
            "exam_type",
            "student",
        )
        ordering = [
            "-academic_session__start_date",
            "class_obj__name",
            "subject__name",
            "student__roll_number",
        ]

    def __str__(self):
        return f"{self.student.user.get_full_name()} - {self.subject.name} ({self.exam_type.name})"

    def clean(self):
        # Validate marks against exam structure
        exam_structure = ExamStructure.objects.filter(
            exam_type=self.exam_type, subject=self.subject
        ).first()

        if not exam_structure:
            raise ValidationError(
                "No exam structure defined for this exam type and subject. Please define it first."
            )

        if (
            self.written_marks is not None
            and self.written_marks > exam_structure.written_max_marks
        ):
            raise ValidationError(
                {
                    "written_marks": f"Written marks cannot exceed {exam_structure.written_max_marks}."
                }
            )
        if self.mcq_marks is not None and self.mcq_marks > exam_structure.mcq_max_marks:
            raise ValidationError(
                {
                    "mcq_marks": f"MCQ marks cannot exceed {exam_structure.mcq_max_marks}."
                }
            )
        if (
            self.practical_marks is not None
            and self.practical_marks > exam_structure.practical_max_marks
        ):
            raise ValidationError(
                {
                    "practical_marks": f"Practical marks cannot exceed {exam_structure.practical_max_marks}."
                }
            )

        # Calculate total_marks_obtained
        self.total_marks_obtained = Decimal(0)
        if self.written_marks is not None:
            self.total_marks_obtained += self.written_marks
        if self.mcq_marks is not None:
            self.total_marks_obtained += self.mcq_marks
        if self.practical_marks is not None:
            self.total_marks_obtained += self.practical_marks

        # Pass/Fail status based on total marks obtained against total max marks from structure
        # Assuming a default pass percentage if not explicitly configured elsewhere
        system_config = SystemConfiguration.objects.first()
        default_pass_percentage = (
            system_config.default_pass_percentage if system_config else Decimal("33.00")
        )

        if exam_structure.total_max_marks > 0:
            obtained_percentage = (
                self.total_marks_obtained / exam_structure.total_max_marks
            ) * 100
            self.pass_status = obtained_percentage >= default_pass_percentage
        else:
            self.pass_status = False  # Cannot pass if total max marks is zero

    def save(self, *args, **kwargs):
        self.full_clean()  # Run full validation including unique_together and clean method
        super().save(*args, **kwargs)

# marks/models.py
from django.core.exceptions import ValidationError
from django.db import models


class ClassTest(models.Model):
    academic_session = models.ForeignKey(
        AcademicSession, on_delete=models.CASCADE, related_name="class_tests"
    )
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="class_tests"
    )
    subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="class_tests"
    )
    teacher = models.ForeignKey(
        TeacherProfile, on_delete=models.CASCADE, related_name="conducted_class_tests"
    )
    title = models.CharField(max_length=100)
    description = models.TextField(blank=True, null=True)

    max_marks = models.DecimalField(max_digits=5, decimal_places=2)
    test_date = models.DateField()
    # NEW:
    exam_type = models.ForeignKey(
        "marks.ExamType",
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="class_tests",
        help_text="Select Half-Yearly, Yearly, etc.",
    )

    def clean(self):
        super().clean()
        # If exam_type is set, force it to match the CT’s session
        if (
            self.exam_type
            and self.exam_type.academic_session_id != self.academic_session_id
        ):
            raise ValidationError(
                {"exam_type": "Exam type must belong to the same academic session."}
            )

    class Meta:
        constraints = [
            # Allow same CT title across exam terms but keep it unique within a term
            models.UniqueConstraint(
                fields=[
                    "academic_session",
                    "class_obj",
                    "subject",
                    "exam_type",
                    "title",
                ],
                name="uniq_ct_title_per_term",
            ),
        ]
        indexes = [
            models.Index(
                fields=[ "class_obj", "subject", "exam_type"]
            ),
        ]


class ClassTestMark(models.Model):
    """
    Records a student's marks for a specific ClassTest.
    """

    class_test = models.ForeignKey(
        ClassTest, on_delete=models.CASCADE, related_name="class_test_marks"
    )
    student = models.ForeignKey(
        Student, on_delete=models.CASCADE, related_name="class_test_marks"
    )
    # MODIFIED: Added null=True, blank=True to allow marks to be optional
    marks_obtained = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        null=True,
        blank=True,
        validators=[MinValueValidator(0)],
    )
    remarks = models.TextField(blank=True, null=True)
    recorded_at = models.DateTimeField(auto_now_add=True)
    recorded_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="recorded_class_test_marks",
    )

    class Meta:
        verbose_name = "Class Test Mark"
        verbose_name_plural = "Class Test Marks"
        unique_together = ("class_test", "student")
        ordering = ["class_test__test_date", "student__roll_number"]

    def __str__(self):
        return f"{self.student.user.get_full_name()} - {self.class_test.title}: {self.marks_obtained}"

    def clean(self):
        if (
            self.marks_obtained is not None
            and self.marks_obtained > self.class_test.max_marks
        ):
            raise ValidationError(
                {
                    "marks_obtained": f"Marks obtained cannot exceed {self.class_test.max_marks} for this class test."
                }
            )

        # Ensure the student is enrolled in the class and academic session of the class test
        if self.student and self.class_test:
            if not (
                self.student.current_class == self.class_test.class_obj
                and self.student.academic_session == self.class_test.academic_session
            ):
                raise ValidationError(
                    {
                        "student": "This student is not enrolled in the class/academic session of this class test."
                    }
                )

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)


class GradingConfiguration(models.Model):
    """
    Defines how final marks are calculated for a specific subject in a class for an academic session.
    Allows customization of CT contribution and number of best CTs to consider.
    """

    academic_session = models.ForeignKey(
        AcademicSession, on_delete=models.CASCADE, related_name="grading_configurations"
    )
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="grading_configurations"
    )
    subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="grading_configurations"
    )

    # Percentage of total final marks that will come from CTs (e.g., 10 for 10%)
    ct_contribution_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=10.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    # Number of best CTs to consider for the average
    num_best_cts_to_consider = models.IntegerField(
        default=3, validators=[MinValueValidator(0)]
    )
    # The marks that CTs will be scaled to before averaging (e.g., if CTs are out of 10, they are scaled to 10 marks for calculation)
    ct_scale_to_marks = models.DecimalField(
        max_digits=5, decimal_places=2, default=10.00, validators=[MinValueValidator(0)]
    )

    # Grade thresholds (out of 100)
    grade_a_plus_min = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=80.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    grade_a_min = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=70.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    grade_b_min = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=60.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    grade_c_min = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=50.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    grade_d_min = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=33.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )

    # NEW FIELD: Allows teachers to edit marks for this configuration if set to True
    is_teacher_editable = models.BooleanField(
        default=False, help_text="Allow teachers to edit marks for this configuration."
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="grading_configs_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="grading_configs_updated",
    )

    class Meta:
        verbose_name = "Grading Configuration"
        verbose_name_plural = "Grading Configurations"
        unique_together = ("academic_session", "class_obj", "subject")
        ordering = ["academic_session__name", "class_obj__name", "subject__name"]

    def __str__(self):
        return f"Grading for {self.subject.name} in {self.class_obj.name} ({self.academic_session.name})"

    def clean(self):
        # Ensure CT contribution percentage and main exam percentage sum to 100
        if self.ct_contribution_percentage > 100:
            raise ValidationError(
                {"ct_contribution_percentage": "CT contribution cannot exceed 100%."}
            )

        # Ensure grade thresholds are in descending order
        if not (
            self.grade_a_plus_min
            >= self.grade_a_min
            >= self.grade_b_min
            >= self.grade_c_min
            >= self.grade_d_min
        ):
            raise ValidationError(
                "Grade thresholds must be in descending order (A+ >= A >= B >= C >= D)."
            )

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)


class SystemConfiguration(models.Model):
    """
    Stores system-wide configurable parameters, such as default scaling percentages.
    This model is designed to be a singleton (only one instance).
    """

    # Main exam scaling percentage (e.g., 90 for 90%)
    main_exam_scaling_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=90.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )
    # Default number of best CTs to consider if not overridden by GradingConfiguration
    default_num_best_cts_to_consider = models.IntegerField(
        default=3, validators=[MinValueValidator(0)]
    )
    # Default marks that CTs will be scaled to if not overridden by GradingConfiguration
    default_ct_scale_to_marks = models.DecimalField(
        max_digits=5, decimal_places=2, default=10.00, validators=[MinValueValidator(0)]
    )
    # Default pass percentage for subjects if not explicitly defined in GradingConfiguration
    default_pass_percentage = models.DecimalField(
        max_digits=5,
        decimal_places=2,
        default=33.00,
        validators=[MinValueValidator(0), MaxValueValidator(100)],
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="system_configs_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="system_configs_updated",
    )

    class Meta:
        verbose_name = "System Configuration"
        verbose_name_plural = "System Configurations"

    def __str__(self):
        return "System-Wide Grading Configuration"

    def clean(self):
        from django.core.exceptions import ValidationError

        if (
            self.main_exam_scaling_percentage < 0
            or self.main_exam_scaling_percentage > 100
        ):
            raise ValidationError(
                {
                    "main_exam_scaling_percentage": "Scaling percentage must be between 0 and 100."
                }
            )
        if self.default_num_best_cts_to_consider < 0:
            raise ValidationError(
                {
                    "default_num_best_cts_to_consider": "Default number of best CTs cannot be negative."
                }
            )
        if self.default_ct_scale_to_marks < 0:
            raise ValidationError(
                {
                    "default_ct_scale_to_marks": "Default CT scale to marks cannot be negative."
                }
            )
        if self.default_pass_percentage < 0 or self.default_pass_percentage > 100:
            raise ValidationError(
                {
                    "default_pass_percentage": "Default pass percentage must be between 0 and 100."
                }
            )

    def save(self, *args, **kwargs):
        # Ensure only one SystemConfiguration instance exists
        if SystemConfiguration.objects.exists() and not self.pk:
            raise ValidationError("Only one SystemConfiguration instance can exist.")
        self.full_clean()
        super().save(*args, **kwargs)
