# SchoolManagementSystem/marks/templatetags/academic_filters.py
from django import template

register = template.Library()


# REMOVED: Unnecessary model imports that caused ModuleNotFoundError
# from .models import ExamType, ExamStructure, SystemConfiguration, StudentExamMark, ClassTest, ClassTestMark, \
#     GradingConfiguration
# from academic.models import AcademicSession, Class, Subject
# from users.models import Student


@register.filter
def get_item(dictionary, key):
    """
    Allows accessing dictionary/list items by key/index in Django templates.
    Usage: {{ my_list|get_item:forloop.counter0 }} or {{ my_dict|get_item:'my_key' }}
    """
    if isinstance(dictionary, (list, tuple)):
        try:
            return dictionary[key]
        except (IndexError, TypeError):
            return None  # Return None if index is out of bounds or key is not an int
    elif isinstance(dictionary, dict):
        return dictionary.get(key)
    return None
