# SchoolManagementSystem/marks/forms.py
from django import forms

from academic.models import (
    AcademicSession,
    Class,
    Subject,
)  # Import from academic for choices
from users.models import Student, TeacherProfile  # Import Student for choices

# Updated imports to reflect new/renamed models
from .models import (
    ExamType,
    ExamStructure,
    SystemConfiguration,
    StudentExamMark,
    ClassTest,
    ClassTestMark,
    GradingConfiguration,
)


# Helper function to apply Tailwind classes consistently
def add_tailwind_classes(field, field_name=None):
    if hasattr(field.widget, "attrs"):
        current_classes = field.widget.attrs.get("class", "").split()
        # Ensure base_classes for non-checkboxes
        base_classes = "block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm min-h-8"

        # Checkbox styling is different, often just needs basic sizing
        if isinstance(field.widget, forms.CheckboxInput):
            checkbox_classes = (
                "h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
            )
            for cls in checkbox_classes.split():
                if cls not in current_classes:
                    current_classes.append(cls)
        else:
            for cls in base_classes.split():
                if cls not in current_classes:
                    current_classes.append(cls)
        field.widget.attrs["class"] = " ".join(current_classes)

        if field_name:
            placeholder_text = {
                "name": "Enter name",
                "description": "Enter description",
                "written_max_marks": "Max marks for written",
                "mcq_max_marks": "Max marks for MCQ",
                "practical_max_marks": "Max marks for practical",
                "title": "Enter title",
                "max_marks": "Enter max marks",
                "test_date": "Select test date",
                "marks_obtained": "Enter marks obtained",
                "remarks": "Enter remarks",
                "ct_contribution_percentage": "e.g., 10 (for 10%)",
                "num_best_cts_to_consider": "e.g., 3",
                "ct_scale_to_marks": "e.g., 10",
                "grade_a_plus_min": "e.g., 80",
                "grade_a_min": "e.g., 70",
                "grade_b_min": "e.g., 60",
                "grade_c_min": "e.g., 50",
                "grade_d_min": "e.g., 33",
                "config_key": "e.g., MainExamScalingPercentage",
                "config_value": "Enter value",
                "exam_date": "Select exam date",
                "start_time": "Start time",
                "end_time": "End time",
                "room_number": "e.g., Room 101",
                "total_marks": "Total marks for exam",
                "passing_marks": "Passing marks",
                "invigilator": "Select invigilator",
                "notes": "Any additional notes",
                # Add more specific placeholders as needed
            }
            if (
                field_name in placeholder_text
                and "placeholder" not in field.widget.attrs
            ):
                field.widget.attrs["placeholder"] = placeholder_text[field_name]


# --- Exam Type Forms ---
class ExamTypeForm(forms.ModelForm):
    class Meta:
        model = ExamType
        fields = [
            "academic_session",
            "name",
            "description",
            "is_final_exam",
            "is_active",
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields["academic_session"].queryset = (
            AcademicSession.objects.all().order_by("-start_date")
        )


# --- Exam Structure Forms ---
class ExamStructureForm(forms.ModelForm):
    class Meta:
        model = ExamStructure
        fields = [
            "exam_type",
            "subject",
            "written_max_marks",
            "mcq_max_marks",
            "practical_max_marks",
        ]
        # total_max_marks is calculated in the model's clean method, not directly a form field

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields["exam_type"].queryset = ExamType.objects.all().order_by(
            "-academic_session__start_date", "name"
        )
        self.fields["subject"].queryset = Subject.objects.all().order_by("name")


# --- Student Exam Mark Forms ---
class StudentExamMarkForm(forms.ModelForm):
    # These fields are for display only in the formset, not directly saved
    student_name = forms.CharField(
        label="Student Name",
        required=False,
        widget=forms.TextInput(attrs={"readonly": "readonly", "class": "bg-gray-100"}),
    )
    roll_number = forms.CharField(
        label="Roll No.",
        required=False,
        widget=forms.TextInput(
            attrs={"readonly": "readonly", "class": "bg-gray-100 w-20"}
        ),
    )

    class Meta:
        model = StudentExamMark
        fields = ["student", "written_marks", "mcq_marks", "practical_marks", "remarks"]
        widgets = {
            "student": forms.HiddenInput(),  # Student is hidden, set by view
            "remarks": forms.Textarea(attrs={"rows": 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if field_name not in ["student_name", "roll_number", "student"]:
                add_tailwind_classes(field, field_name)

        # If instance exists, populate student_name and roll_number
        if self.instance and self.instance.pk:
            self.fields["student_name"].initial = (
                self.instance.student.user.get_full_name()
            )
            self.fields["roll_number"].initial = self.instance.student.roll_number
        elif "initial" in kwargs and "student" in kwargs["initial"]:
            # For new forms in a formset, if student is passed in initial
            student_obj = Student.objects.get(pk=kwargs["initial"]["student"])
            self.fields["student_name"].initial = student_obj.user.get_full_name()
            self.fields["roll_number"].initial = student_obj.roll_number


class DateInput(forms.DateInput):
    input_type = "date"


# marks/forms.py
class ClassTestForm(forms.ModelForm):
    class Meta:
        model = ClassTest
        fields = [
            "academic_session",
            "class_obj",
            "subject",
            "title",
            "description",
            "max_marks",
            "test_date",
            "exam_type",
            "teacher",  # ← add this
        ]
        widgets = {
            "test_date": DateInput(attrs={
                "class": "mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm " 
                         "focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Optional: narrow exam types to the selected session for better UX
        session_id = None
        if self.data.get("academic_session"):
            session_id = self.data.get("academic_session")
        elif self.instance and self.instance.academic_session_id:
            session_id = self.instance.academic_session_id

        if session_id:
            self.fields["exam_type"].queryset = ExamType.objects.filter(
                academic_session_id=session_id
            )


# --- Class Test Mark Forms ---
class ClassTestMarkForm(forms.ModelForm):
    # These fields are for display only in the formset, not directly saved
    student_name = forms.CharField(
        label="Student Name",
        required=False,
        widget=forms.TextInput(attrs={"readonly": "readonly", "class": "bg-gray-100"}),
    )
    roll_number = forms.CharField(
        label="Roll No.",
        required=False,
        widget=forms.TextInput(
            attrs={"readonly": "readonly", "class": "bg-gray-100 w-20"}
        ),
    )

    class Meta:
        model = ClassTestMark
        fields = ["student", "marks_obtained", "remarks"]
        widgets = {
            "student": forms.HiddenInput(),  # Student is hidden, set by view
            "remarks": forms.Textarea(attrs={"rows": 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Apply Tailwind classes to all fields first
        for field_name, field in self.fields.items():
            # Only apply common tailwind classes to non-display fields if they are not hidden
            if field_name not in ["student_name", "roll_number"] and not isinstance(
                field.widget, forms.HiddenInput
            ):
                add_tailwind_classes(field, field_name)
            # Ensure display-only fields also get their specific classes
            elif field_name in ["student_name", "roll_number"]:
                add_tailwind_classes(field, field_name)

        self.fields["student"].queryset = Student.objects.all().order_by(
            "user__first_name"
        )

        # If instance exists, populate student_name and roll_number
        if self.instance and self.instance.pk:
            self.fields["student_name"].initial = (
                self.instance.student.user.get_full_name()
            )
            self.fields["roll_number"].initial = self.instance.student.roll_number
        elif "initial" in kwargs and "student" in kwargs["initial"]:
            # For new forms in a formset, if student is passed in initial
            student_obj = Student.objects.get(pk=kwargs["initial"]["student"])
            self.fields["student_name"].initial = student_obj.user.get_full_name()
            self.fields["roll_number"].initial = student_obj.roll_number


# --- Grading Configuration Forms ---
class GradingConfigurationForm(forms.ModelForm):
    class Meta:
        model = GradingConfiguration
        fields = [
            "academic_session",
            "class_obj",
            "subject",
            "ct_contribution_percentage",
            "num_best_cts_to_consider",
            "ct_scale_to_marks",
            "grade_a_plus_min",
            "grade_a_min",
            "grade_b_min",
            "grade_c_min",
            "grade_d_min",
            "is_teacher_editable",  # ADDED THIS FIELD
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields["academic_session"].queryset = (
            AcademicSession.objects.all().order_by("-start_date")
        )
        self.fields["class_obj"].queryset = Class.objects.all().order_by("name")
        self.fields["subject"].queryset = Subject.objects.all().order_by("name")


# --- System Configuration Form (Singleton) ---
class SystemConfigurationForm(forms.ModelForm):
    class Meta:
        model = SystemConfiguration
        fields = [
            "main_exam_scaling_percentage",
            "default_num_best_cts_to_consider",
            "default_ct_scale_to_marks",
            "default_pass_percentage",
        ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


# --- Marksheet Selection Form (for Admin/Teacher) ---
class StudentMarksheetSelectForm(forms.Form):
    academic_session = forms.ModelChoiceField(
        queryset=AcademicSession.objects.all().order_by("-start_date"),
        empty_label="Select Academic Session",
        label="Academic Session",
    )
    student = forms.ModelChoiceField(
        queryset=Student.objects.all().order_by("user__first_name", "user__last_name"),
        empty_label="Select Student",
        label="Student",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            add_tailwind_classes(field)
        # Dynamically filter students based on selected academic session (optional, can be done via JS on frontend)
        if "academic_session" in self.data:
            try:
                session_id = int(self.data.get("academic_session"))
                self.fields["student"].queryset = Student.objects.filter(
                    academic_session__id=session_id
                ).order_by("user__first_name")
            except (ValueError, TypeError):
                pass  # Handle invalid input gracefully


# --- Mark Comparison Forms ---
class MarkComparisonSelectForm(forms.Form):
    academic_session = forms.ModelChoiceField(
        queryset=AcademicSession.objects.all().order_by("-start_date"),
        empty_label="Select Academic Session",
        label="Academic Session",
    )
    class_obj = forms.ModelChoiceField(
        queryset=Class.objects.all().order_by("name"),
        empty_label="Select Class",
        label="Class",
    )
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.all().order_by("name"),
        empty_label="Select Subject",
        label="Subject",
    )
    student1 = forms.ModelChoiceField(
        queryset=Student.objects.all().order_by("user__first_name", "user__last_name"),
        empty_label="Select Student 1",
        label="Student 1",
    )
    student2 = forms.ModelChoiceField(
        queryset=Student.objects.all().order_by("user__first_name", "user__last_name"),
        empty_label="Select Student 2",
        label="Student 2",
    )


    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            add_tailwind_classes(field)
        # Dynamically filter students based on selected class (optional, can be done via JS on frontend)
        if "class_obj" in self.data:
            try:
                class_id = int(self.data.get("class_obj"))
                self.fields["student1"].queryset = Student.objects.filter(
                    current_class__id=class_id
                ).order_by("user__first_name")
                self.fields["student2"].queryset = Student.objects.filter(
                    current_class__id=class_id
                ).order_by("user__first_name")
            except (ValueError, TypeError):
                pass  # Handle invalid input gracefully
# marks/forms.py
class ClassTestSelectForm(forms.Form):
    academic_session = forms.ModelChoiceField(
        queryset=AcademicSession.objects.all().order_by("-start_date"),
        empty_label="Select Session",
        label="Academic Session",
        required=True,
    )
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.all().order_by("name"),
        empty_label="Select Subject",
        label="Subject",
        required=True,
    )
    exam_type = forms.ModelChoiceField(  # ✅ NEW FILTER
        queryset=ExamType.objects.all().order_by("name"),
        empty_label="Select Exam Type",
        label="Exam Type",
        required=False,
    )
    class_test = forms.ModelChoiceField(
        queryset=ClassTest.objects.none(),  # will populate dynamically
        empty_label="Select Class Test",
        label="Class Test",
        required=True,
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # If filters were already chosen, narrow down CT list
        session_id = self.data.get("academic_session") or self.initial.get(
            "academic_session"
        )
        subject_id = self.data.get("subject") or self.initial.get("subject")
        exam_type_id = self.data.get("exam_type") or self.initial.get("exam_type")

        qs = ClassTest.objects.all()

        if session_id:
            qs = qs.filter(academic_session_id=session_id)
        if subject_id:
            qs = qs.filter(subject_id=subject_id)
        if exam_type_id:
            qs = qs.filter(exam_type_id=exam_type_id)

        self.fields["class_test"].queryset = qs.order_by("-test_date")
