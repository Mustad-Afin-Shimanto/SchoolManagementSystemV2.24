# SchoolManagementSystem/marks/urls.py
from django.urls import path
from . import views

app_name = "marks"  # THIS LINE IS CRUCIAL AND MUST BE EXACTLY HERE

urlpatterns = [
    # Exam Type URLs
    path("exam-types/", views.exam_type_list_view, name="exam_type_list"),
    path("exam-types/create/", views.exam_type_create_view, name="exam_type_create"),
    path(
        "exam-types/update/<int:pk>/",
        views.exam_type_update_view,
        name="exam_type_update",
    ),
    path(
        "exam-types/delete/<int:pk>/",
        views.exam_type_delete_view,
        name="exam_type_delete",
    ),
    # Exam Structure URLs
    path(
        "exam-structures/", views.exam_structure_list_view, name="exam_structure_list"
    ),
    path(
        "exam-structures/create/",
        views.exam_structure_create_view,
        name="exam_structure_create",
    ),
    path(
        "exam-structures/update/<int:pk>/",
        views.exam_structure_update_view,
        name="exam_structure_update",
    ),
    path(
        "exam-structures/delete/<int:pk>/",
        views.exam_structure_delete_view,
        name="exam_structure_delete",
    ),
    # System Configuration URLs
    path(
        "system-configs/",
        views.system_configuration_list_view,
        name="system_configuration_list",
    ),
    # Student Exam Mark URLs
    path(
        "exam-marks/submission-select/",
        views.student_exam_mark_submission_select_view,
        name="student_exam_mark_submission_select",
    ),
    path(
        "exam-marks/entry/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:exam_type_pk>/",
        views.student_exam_mark_entry_form_view,
        name="student_exam_mark_entry_form",
    ),
    path(
        "exam-marks/list/",
        views.student_exam_mark_list_view,
        name="student_exam_mark_list",
    ),
    path(
        "exam-marks/update/<int:pk>/",
        views.student_exam_mark_update_view,
        name="student_exam_mark_update",
    ),
    path(
        "exam-marks/delete/<int:pk>/",
        views.student_exam_mark_delete_view,
        name="student_exam_mark_delete",
    ),
    # Class Test URLs
    path("class-tests/", views.class_test_list_view, name="class_test_list"),
    path("class-tests/create/", views.class_test_create_view, name="class_test_create"),
    path(
        "class-tests/update/<int:pk>/",
        views.class_test_update_view,
        name="class_test_update",
    ),
    path(
        "class-tests/delete/<int:pk>/",
        views.class_test_delete_view,
        name="class_test_delete",
    ),
    # Class Test Mark URLs
    path(
        "class-tests/marks/submission-select/",
        views.class_test_mark_submission_select_view,
        name="class_test_mark_submission_select",
    ),
    path(
        "class-tests/marks/entry/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:class_test_pk>/",
        views.class_test_mark_entry_form_view,
        name="class_test_mark_entry_form",
    ),
    path(
        "class-tests/marks/list/",
        views.class_test_mark_list_view,
        name="class_test_mark_list",
    ),
    path(
        "class-tests/marks/update/<int:pk>/",
        views.class_test_mark_update_view,
        name="class_test_mark_update",
    ),
    path(
        "class-tests/marks/delete/<int:pk>/",
        views.class_test_mark_delete_view,
        name="class_test_mark_delete",
    ),
    # Grading Configuration URLs
    path(
        "grading-configs/",
        views.grading_configuration_list_view,
        name="grading_configuration_list",
    ),
    path(
        "grading-configs/create/",
        views.grading_configuration_create_view,
        name="grading_configuration_create",
    ),
    path(
        "grading-configs/update/<int:pk>/",
        views.grading_configuration_update_view,
        name="grading_configuration_update",
    ),
    path(
        "grading-configs/delete/<int:pk>/",
        views.grading_configuration_delete_view,
        name="grading_configuration_delete",
    ),
    # Marksheet View
    path(
        "marksheet/<int:student_pk>/<int:academic_session_pk>/",
        views.student_marksheet_view,
        name="student_marksheet",
    ),
    path(
        "marksheet/select/",
        views.student_marksheet_select_view,
        name="student_marksheet_select",
    ),
    # Mark Comparison
    path(
        "mark-comparison/select/",
        views.mark_comparison_select_view,
        name="mark_comparison_select",
    ),
    path("mark-comparison/results/", views.compare_marks_view, name="compare_marks"),
    # Export Exam Marks
    path(
        "exam-marks/export/excel/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:exam_type_pk>/",
        views.export_exam_marks_excel_view,
        name="export_exam_marks_excel",
    ),
    path(
        "exam-marks/export/pdf/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:exam_type_pk>/",
        views.export_exam_marks_pdf_view,
        name="export_exam_marks_pdf",
    ),
    # Export Class Test Marks
    path(
        "class-tests/export/excel/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:class_test_pk>/",
        views.export_class_test_marks_excel_view,
        name="export_class_test_marks_excel",
    ),
    path(
        "class-tests/export/pdf/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:class_test_pk>/",
        views.export_class_test_marks_pdf_view,
        name="export_class_test_marks_pdf",
    ),
    # NEW: Existing marksheet generator
    path(
        "marksheet/generate-pdf/<int:student_pk>/<int:academic_session_pk>/",
        views.generate_marksheet_pdf_view,
        name="generate_marksheet_pdf",
    ),
    # NEW: Official result card generator
    path("results/official/<int:student_pk>/", views.official_result_card, name="official_result_card"),

]
