# SchoolManagementSystem/marks/views.py

# Standard library
import os, re, subprocess
from decimal import Decimal, ROUND_HALF_UP

# Django
from django.conf import settings
from django.http import FileResponse, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction, models
from django.db.models import Q
from django.forms import modelformset_factory

# Third-party
import openpyxl
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
from openpyxl.cell.cell import MergedCell
from openpyxl.worksheet.page import PageMargins
from openpyxl.utils import get_column_letter
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer


# Local app imports
from academic.models import AcademicSession, Class, ClassSubjectAssignment, Subject
from users.models import Student, TeacherProfile, ParentProfile
from .forms import (
    ExamTypeForm,
    ExamStructureForm,
    StudentExamMarkForm,
    ClassTestForm,
    ClassTestMarkForm,
    GradingConfigurationForm,
    SystemConfigurationForm,
    StudentMarksheetSelectForm,
    MarkComparisonSelectForm,
)
from .models import (
    ExamType,
    ExamStructure,
    StudentExamMark,
    ClassTest,
    ClassTestMark,
    GradingConfiguration,
    SystemConfiguration,
)

# Path to official result card template
TEMPLATE_PATH = os.path.join(
    settings.BASE_DIR, "result_templates", "Result-Card-Formate.xlsx"
)



# --- Helper functions for role-based access ---
def is_admin(user):
    return user.is_authenticated and user.role == "admin"


def is_teacher(user):
    return user.is_authenticated and user.role == "teacher"


def is_student(user):
    return user.is_authenticated and user.role == "student"


def is_parent(user):
    return user.is_authenticated and user.role == "parent"


def is_admin_or_teacher(user):
    return user.is_authenticated and (user.role == "admin" or user.role == "teacher")


# --- Exam Type Views ---
@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Types
def exam_type_list_view(request):
    exam_types = ExamType.objects.all().order_by(
        "-academic_session__start_date", "name"
    )
    paginator = Paginator(exam_types, 10)  # Show 10 exam types per page

    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        page_obj = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        page_obj = paginator.page(paginator.num_pages)

    context = {"page_title": "Exam Types", "page_obj": page_obj}
    return render(request, "marks/exam_type_list.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Types
def exam_type_create_view(request):
    if request.method == "POST":
        form = ExamTypeForm(request.POST)
        if form.is_valid():
            exam_type = form.save(commit=False)
            exam_type.created_by = request.user
            exam_type.save()
            messages.success(request, "Exam Type created successfully!")
            return redirect("marks:exam_type_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ExamTypeForm()

    context = {"page_title": "Create Exam Type", "form": form, "action": "create"}
    return render(request, "marks/exam_type_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Types
def exam_type_update_view(request, pk):
    exam_type = get_object_or_404(ExamType, pk=pk)
    if request.method == "POST":
        form = ExamTypeForm(request.POST, instance=exam_type)
        if form.is_valid():
            exam_type = form.save(commit=False)
            exam_type.updated_by = request.user
            exam_type.save()
            messages.success(request, "Exam Type updated successfully!")
            return redirect("marks:exam_type_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ExamTypeForm(instance=exam_type)

    context = {"page_title": "Update Exam Type", "form": form, "action": "update"}
    return render(request, "marks/exam_type_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Types
def exam_type_delete_view(request, pk):
    exam_type = get_object_or_404(ExamType, pk=pk)
    if request.method == "POST":
        try:
            exam_type.delete()
            messages.success(request, "Exam Type deleted successfully!")
            return redirect("marks:exam_type_list")
        except Exception as e:
            messages.error(request, f"Error deleting exam type: {e}")
    context = {
        "page_title": "Confirm Delete Exam Type",
        "object": exam_type,
        "confirm_message": f"Are you sure you want to delete the exam type '{exam_type.name}'? This action cannot be undone.",
    }
    return render(request, "marks/exam_type_confirm_delete.html", context)


# --- Exam Structure Views (Max Marks per Exam Type and Subject) ---
@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Structures
def exam_structure_list_view(request):
    exam_structures = ExamStructure.objects.all().order_by(
        "exam_type__academic_session__name", "exam_type__name", "subject__name"
    )
    paginator = Paginator(exam_structures, 10)

    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {"page_title": "Exam Structures", "page_obj": page_obj}
    return render(request, "marks/exam_structure_list.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Structures
def exam_structure_create_view(request):
    if request.method == "POST":
        form = ExamStructureForm(request.POST)
        if form.is_valid():
            exam_structure = form.save(commit=False)
            exam_structure.created_by = request.user
            exam_structure.save()
            messages.success(request, "Exam Structure created successfully!")
            return redirect("marks:exam_structure_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ExamStructureForm()

    context = {"page_title": "Create Exam Structure", "form": form, "action": "create"}
    return render(request, "marks/exam_structure_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Structures
def exam_structure_update_view(request, pk):
    exam_structure = get_object_or_404(ExamStructure, pk=pk)
    if request.method == "POST":
        form = ExamStructureForm(request.POST, instance=exam_structure)
        if form.is_valid():
            exam_structure = form.save(commit=False)
            exam_structure.updated_by = request.user
            exam_structure.save()
            messages.success(request, "Exam Structure updated successfully!")
            return redirect("marks:exam_structure_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ExamStructureForm(instance=exam_structure)

    context = {"page_title": "Update Exam Structure", "form": form, "action": "update"}
    return render(request, "marks/exam_structure_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Exam Structures
def exam_structure_delete_view(request, pk):
    exam_structure = get_object_or_404(ExamStructure, pk=pk)
    if request.method == "POST":
        try:
            exam_structure.delete()
            messages.success(request, "Exam Structure deleted successfully!")
            return redirect("marks:exam_structure_list")
        except Exception as e:
            messages.error(request, f"Error deleting exam structure: {e}")
    context = {
        "page_title": "Confirm Delete Exam Structure",
        "object": exam_structure,
        "confirm_message": f"Are you sure you want to delete the exam structure for '{exam_structure.exam_type.name} - {exam_structure.subject.name}'? This action cannot be undone.",
    }
    return render(request, "marks/exam_structure_confirm_delete.html", context)


# --- Student Exam Mark Views ---
@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can list marks
def student_exam_mark_list_view(request):
    marks = StudentExamMark.objects.all().order_by(
        "-academic_session__start_date",
        "class_obj__name",
        "subject__name",
        "student__roll_number",
    )
    # Teachers should only see marks for their assigned subjects/classes
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        assigned_classes_subjects = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values("class_obj", "subject")
        # Filter marks to only include those where the subject and class are assigned to the teacher
        marks = marks.filter(
            class_obj__in=[item["class_obj"] for item in assigned_classes_subjects],
            subject__in=[item["subject"] for item in assigned_classes_subjects],
        )

    paginator = Paginator(marks, 10)

    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {"page_title": "Student Exam Marks", "page_obj": page_obj}
    return render(request, "marks/student_exam_mark_list.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can select for entry
def student_exam_mark_submission_select_view(request):
    academic_sessions = AcademicSession.objects.filter(is_current=True).order_by(
        "-start_date"
    )
    classes = Class.objects.all().order_by("name")
    subjects = Subject.objects.all().order_by("name")
    exam_types = ExamType.objects.filter(is_active=True).order_by("name")

    # Teachers should only see classes/subjects they are assigned to
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        assigned_classes_ids = (
            ClassSubjectAssignment.objects.filter(teacher=teacher_profile)
            .values_list("class_obj", flat=True)
            .distinct()
        )
        assigned_subjects_ids = (
            ClassSubjectAssignment.objects.filter(teacher=teacher_profile)
            .values_list("subject", flat=True)
            .distinct()
        )

        classes = classes.filter(pk__in=assigned_classes_ids)
        subjects = subjects.filter(pk__in=assigned_subjects_ids)

    if request.method == "POST":
        pass

    context = {
        "page_title": "Select for Student Exam Mark Entry",
        "academic_sessions": academic_sessions,
        "classes": classes,
        "subjects": subjects,
        "exam_types": exam_types,
    }
    return render(request, "marks/student_exam_mark_submission_select.html", context)


# Helper function to check if a form in the formset has any meaningful data
def has_mark_data(form):
    """
    Checks if a StudentExamMarkForm or ClassTestMarkForm has any non-empty mark data.
    Considers 0 as valid input.
    """
    if isinstance(form, StudentExamMarkForm):
        written = form.cleaned_data.get("written_marks")
        mcq = form.cleaned_data.get("mcq_marks")
        practical = form.cleaned_data.get("practical_marks")
        return (
            (written is not None and written != "")
            or (mcq is not None and mcq != "")
            or (practical is not None and practical != "")
        )
    elif isinstance(form, ClassTestMarkForm):
        marks_obtained = form.cleaned_data.get("marks_obtained")
        return (
            marks_obtained is not None
        )  # Check if it's not None, allows 0 as valid input


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can enter marks
def student_exam_mark_entry_form_view(
    request, academic_session_pk, class_pk, subject_pk, exam_type_pk
):
    page_title = "Enter Student Exam Marks"
    academic_session_obj = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject_obj = get_object_or_404(Subject, pk=subject_pk)
    exam_type_obj = get_object_or_404(ExamType, pk=exam_type_pk)

    # Teacher-specific authorization check
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        if not ClassSubjectAssignment.objects.filter(
            academic_session=academic_session_obj,
            class_obj=class_obj,
            subject=subject_obj,
            teacher=teacher_profile,
        ).exists():
            messages.error(
                request,
                "You are not authorized to enter marks for this class and subject.",
            )
            return redirect(
                "marks:student_exam_mark_submission_select"
            )  # Redirect back to selection

    try:
        exam_structure = ExamStructure.objects.get(
            exam_type=exam_type_obj, subject=subject_obj
        )
    except ExamStructure.DoesNotExist:
        messages.error(
            request,
            f"No exam structure defined for {exam_type_obj.name} in {subject_obj.name}. Please define it first.",
        )
        return redirect("marks:exam_structure_create")

    # MODIFIED: Filter students to only include those WITHOUT existing marks for this exam
    students = Student.objects.filter(
        current_class=class_obj, academic_session=academic_session_obj
    ).order_by("roll_number", "user__first_name")

    StudentMarkFormSet = modelformset_factory(
        StudentExamMark,
        form=StudentExamMarkForm,
        extra=students.count(),  # Create one form for each student who needs marks
        can_delete=False,
        # Reverted empty_permitted=True here, as per user's request.
    )

    if request.method == "POST":
        formset = StudentMarkFormSet(request.POST)

        student_map = {str(s.pk): s for s in students}

        for form in formset:
            if not form.instance.pk:  # This is a new form instance
                student_pk_from_post = request.POST.get(f"{form.prefix}-student")
                if student_pk_from_post and student_pk_from_post in student_map:
                    form.instance.student = student_map[student_pk_from_post]
                else:
                    form.add_error(
                        "student", "Student information is missing or invalid."
                    )

            # --- FIX: Set these foreign key fields on the instance BEFORE validation ---
            # These are essential for model's clean method to find related ExamStructure/Subject/ExamType
            form.instance.academic_session = academic_session_obj
            form.instance.class_obj = class_obj
            form.instance.subject = subject_obj
            form.instance.exam_type = exam_type_obj
            form.instance.recorded_by = request.user
            # --- END FIX ---

        if formset.is_valid():
            with transaction.atomic():
                saved_count = 0
                for form in formset:
                    # Only save if the form has changed AND has meaningful mark data
                    # Check for form.has_changed() to prevent saving unchanged forms,
                    # and has_mark_data() to prevent saving empty forms.
                    if form.has_changed() and has_mark_data(form):
                        if form.instance.student:  # Ensure student is linked
                            mark_instance = form.save(commit=False)
                            mark_instance.save()
                            saved_count += 1
                        else:
                            messages.warning(
                                request,
                                f"Skipped saving mark for unknown student due to missing ID.",
                            )
            if saved_count > 0:
                messages.success(
                    request, f"{saved_count} student marks saved successfully!"
                )
            else:
                messages.info(request, "No new marks were entered.")
            return redirect("marks:student_exam_mark_list")  # Redirect to the list view

        else:  # Formset is NOT valid (due to other errors, not just empty forms)
            messages.error(request, "Please correct the errors in the form.")
            # Re-populate student_name and roll_number for displaying errors
            student_map = {s.pk: s for s in students}
            for form in formset:
                current_student = None
                if (
                    form.instance.student_id
                ):  # If the instance was partially created/bound
                    current_student = student_map.get(form.instance.student_id)
                elif (
                    f"{form.prefix}-student" in request.POST
                ):  # Get student from POST data for new forms
                    try:
                        student_pk_from_post = request.POST.get(
                            f"{form.prefix}-student"
                        )
                        current_student = student_map.get(int(student_pk_from_post))
                    except (ValueError, TypeError):
                        pass

                if current_student:
                    form.fields["student_name"].initial = (
                        current_student.user.get_full_name()
                    )
                    form.fields["roll_number"].initial = current_student.roll_number
                else:
                    form.fields["student_name"].initial = "N/A"
                    form.fields["roll_number"].initial = "N/A"

    else:  # GET request
        # The `students` queryset already excludes students with existing marks,
        # so `existing_marks_queryset` will be empty.
        StudentMarkFormSet = modelformset_factory(
            StudentExamMark,
            form=StudentExamMarkForm,
            extra=students.count(),  # Create one form for each student who needs marks
            can_delete=False,
            # Reverted empty_permitted=True here, as per user's request.
        )
        formset = StudentMarkFormSet(
            queryset=StudentExamMark.objects.none()
        )  # Pass empty queryset for new forms

        # Manually set initial student data for each empty form
        for i, form in enumerate(formset):
            if i < len(students):
                current_student = students[i]
                form.initial["student"] = current_student.pk
                form.fields["student_name"].initial = (
                    current_student.user.get_full_name()
                )
                form.fields["roll_number"].initial = current_student.roll_number
            else:
                # This should ideally not be reached if extra=students.count() is correct
                pass

    context = {
        "page_title": page_title,
        "academic_session_obj": academic_session_obj,
        "class_obj": class_obj,
        "subject_obj": subject_obj,
        "exam_type_obj": exam_type_obj,
        "formset": formset,
        "exam_structure": exam_structure,
    }
    return render(request, "marks/student_exam_mark_entry_form.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can update marks
def student_exam_mark_update_view(request, pk):
    mark = get_object_or_404(StudentExamMark, pk=pk)

    # Teacher-specific authorization check for updating marks
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        # Check if grading configuration allows teacher editing for this subject/class
        grading_config = GradingConfiguration.objects.filter(
            academic_session=mark.academic_session,
            class_obj=mark.class_obj,
            subject=mark.subject,
        ).first()

        if not grading_config or not grading_config.is_teacher_editable:
            messages.error(
                request,
                "You are not authorized to update marks for this subject/class.",
            )
            return redirect(
                "marks:student_exam_mark_list"
            )  # Redirect back to marks list

        # Additionally, ensure the teacher is assigned to this class and subject
        if not ClassSubjectAssignment.objects.filter(
            academic_session=mark.academic_session,
            class_obj=mark.class_obj,
            subject=mark.subject,
            teacher=teacher_profile,
        ).exists():
            messages.error(request, "You are not assigned to this class and subject.")
            return redirect("marks:student_exam_mark_list")

    # Fetch the exam structure relevant to this mark's subject and exam type
    exam_structure = None  # Initialize exam_structure to None
    try:
        exam_structure = ExamStructure.objects.get(
            exam_type=mark.exam_type, subject=mark.subject
        )
    except ExamStructure.DoesNotExist:
        messages.error(
            request,
            f"No exam structure defined for {mark.exam_type.name} in {mark.subject.name}. Please define it first.",
        )
        # Redirect back to the list or a selection page if structure is missing
        return redirect(
            "marks:student_exam_mark_list"
        )  # Or 'marks:exam_structure_create'

    if request.method == "POST":
        form = StudentExamMarkForm(request.POST, instance=mark)
        if form.is_valid():
            mark = form.save(commit=False)
            mark.recorded_by = request.user
            # Ensure foreign keys are explicitly set, even for updates, if they are hidden in the form
            # This is a safeguard; ideally, they are correctly handled by the form's hidden inputs
            mark.academic_session = mark.academic_session  # Already on mark instance
            mark.class_obj = mark.class_obj  # Already on mark instance
            mark.subject = mark.subject  # Already on mark instance
            mark.exam_type = mark.exam_type  # Already on mark instance
            mark.save()
            messages.success(request, "Student mark updated successfully!")
            return redirect("marks:student_exam_mark_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = StudentExamMarkForm(instance=mark)

    context = {
        "page_title": "Update Student Mark",
        "form": form,
        "mark": mark,
        "action": "update",
        "exam_structure": exam_structure,  # Pass exam_structure to the template
    }
    return render(request, "marks/student_exam_mark_form.html", context)


@login_required
@user_passes_test(
    is_admin
)  # Only Admin can delete marks (teachers might accidentally delete)
def student_exam_mark_delete_view(request, pk):
    mark = get_object_or_404(StudentExamMark, pk=pk)
    if request.method == "POST":
        try:
            mark.delete()
            messages.success(request, "Student mark deleted successfully!")
            # When a mark is deleted, it should reappear in the entry form.
            # So, redirect back to the entry selection or the form itself if parameters are known.
            # For simplicity, redirect to the list view; the mark will appear in the entry form next time the teacher navigates there.
            return redirect("marks:student_exam_mark_list")
        except Exception as e:
            messages.error(request, f"Error deleting student mark: {e}")
    context = {
        "page_title": "Confirm Delete Student Mark",
        "object": mark,
        "confirm_message": f"Are you sure you want to delete the mark for {mark.student.user.get_full_name()} in {mark.subject.name} ({mark.exam_type.name})? This action cannot be undone.",
    }
    return render(request, "marks/student_exam_mark_confirm_delete.html", context)


# --- Class Test Views ---
@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can list class tests
def class_test_list_view(request):
    from marks.models import ClassTest
    from academic.models import AcademicSession, Class, Subject
    

    class_tests = ClassTest.objects.all().select_related("academic_session", "class_obj", "subject", "exam_type")
    academic_sessions = AcademicSession.objects.all()
    classes = Class.objects.all()
    subjects = Subject.objects.all()
    exam_types = ExamType.objects.all()   # ✅ Add this

    # Pagination
    from django.core.paginator import Paginator
    paginator = Paginator(class_tests, 10)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)

    return render(request, "marks/class_test_list.html", {
        "page_title": "Class Tests",
        "page_obj": page_obj,
        "academic_sessions": academic_sessions,
        "classes": classes,
        "subjects": subjects,
        "exam_types": exam_types,   # ✅ Send to template
    })

@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can create class tests
def class_test_create_view(request):
    if request.method == "POST":
        form = ClassTestForm(request.POST)
        if form.is_valid():
            class_test = form.save(commit=False)
            class_test.created_by = request.user
            class_test.save()
            messages.success(request, "Class Test created successfully!")
            return redirect("marks:class_test_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ClassTestForm()
        # Pre-filter teacher queryset for the form based on the logged-in teacher
        if request.user.role == "teacher":
            teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
            form.fields["teacher"].queryset = TeacherProfile.objects.filter(
                pk=teacher_profile.pk
            )
            form.fields["teacher"].initial = (
                teacher_profile.pk
            )  # Pre-select the teacher
            form.fields["teacher"].widget.attrs[
                "readonly"
            ] = "readonly"  # Make it read-only
            form.fields["teacher"].widget.attrs[
                "class"
            ] += " bg-gray-100 cursor-not-allowed"  # Add styling

    context = {"page_title": "Create Class Test", "form": form, "action": "create"}
    return render(request, "marks/class_test_form.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can update class tests
def class_test_update_view(request, pk):
    class_test = get_object_or_404(ClassTest, pk=pk)

    # Teacher-specific authorization check for updating class tests
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        if class_test.teacher != teacher_profile:
            messages.error(request, "You are not authorized to update this class test.")
            return redirect("marks:class_test_list")

    if request.method == "POST":
        form = ClassTestForm(request.POST, instance=class_test)
        if form.is_valid():
            class_test = form.save(commit=False)
            class_test.updated_by = request.user
            class_test.save()
            messages.success(request, "Class Test updated successfully!")
            return redirect("marks:class_test_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ClassTestForm(instance=class_test)
        # Pre-filter teacher queryset for the form based on the logged-in teacher
        if request.user.role == "teacher":
            teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
            form.fields["teacher"].queryset = TeacherProfile.objects.filter(
                pk=teacher_profile.pk
            )
            form.fields["teacher"].initial = (
                teacher_profile.pk
            )  # Pre-select the teacher
            form.fields["teacher"].widget.attrs[
                "readonly"
            ] = "readonly"  # Make it read-only
            form.fields["teacher"].widget.attrs[
                "class"
            ] += " bg-gray-100 cursor-not-allowed"  # Add styling

    context = {"page_title": "Update Class Test", "form": form, "action": "update"}
    return render(request, "marks/class_test_form.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can delete class tests
def class_test_delete_view(request, pk):
    class_test = get_object_or_404(ClassTest, pk=pk)

    # Teacher-specific authorization check for deleting class tests
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        if class_test.teacher != teacher_profile:
            messages.error(request, "You are not authorized to delete this class test.")
            return redirect("marks:class_test_list")

    if request.method == "POST":
        try:
            class_test.delete()
            messages.success(request, "Class Test deleted successfully!")
            return redirect("marks:class_test_list")
        except Exception as e:
            messages.error(request, f"Error deleting class test: {e}")
    context = {
        "page_title": "Confirm Delete Class Test",
        "object": class_test,
        "confirm_message": f"Are you sure you want to delete the class test '{class_test.title}'? This action cannot be undone.",
    }
    return render(request, "marks/class_test_confirm_delete.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)
def class_test_mark_submission_select_view(request):
    academic_sessions = AcademicSession.objects.filter(is_current=True).order_by(
        "-start_date"
    )
    classes = Class.objects.all().order_by("name")
    subjects = Subject.objects.all().order_by("name")
    class_tests = (
        ClassTest.objects.all()
        .select_related("exam_type")
        .order_by("-test_date", "title")
    )
    exam_types = ExamType.objects.all().order_by("name")

    # --- Filtering by GET params ---
    selected_exam_type = request.GET.get("exam_type")
    if selected_exam_type:
        class_tests = class_tests.filter(exam_type_id=selected_exam_type)

    selected_session = request.GET.get("academic_session")
    if selected_session:
        class_tests = class_tests.filter(academic_session_id=selected_session)

    selected_class = request.GET.get("class_obj")
    if selected_class:
        class_tests = class_tests.filter(class_obj_id=selected_class)

    selected_subject = request.GET.get("subject")
    if selected_subject:
        class_tests = class_tests.filter(subject_id=selected_subject)

    # --- Restrict for teachers ---
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        assigned_classes_subjects = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values("class_obj", "subject")

        classes = classes.filter(
            pk__in=[item["class_obj"] for item in assigned_classes_subjects]
        )
        subjects = subjects.filter(
            pk__in=[item["subject"] for item in assigned_classes_subjects]
        )
        class_tests = class_tests.filter(teacher=teacher_profile)

    context = {
        "page_title": "Select for Class Test Mark Entry",
        "academic_sessions": academic_sessions,
        "classes": classes,
        "subjects": subjects,
        "class_tests": class_tests,
        "exam_types": exam_types,
    }
    return render(request, "marks/class_test_mark_submission_select.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can enter class test marks
def class_test_mark_entry_form_view(
    request, academic_session_pk, class_pk, subject_pk, class_test_pk
):
    academic_session_obj = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject_obj = get_object_or_404(Subject, pk=subject_pk)
    class_test_obj = get_object_or_404(ClassTest, pk=class_test_pk)

    page_title = f"Enter Class Test Marks for {class_test_obj.title}"

    # Teacher-specific authorization check
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        if not ClassSubjectAssignment.objects.filter(
            academic_session=academic_session_obj,
            class_obj=class_obj,
            subject=subject_obj,
            teacher=teacher_profile,
        ).exists():
            messages.error(
                request,
                "You are not authorized to enter marks for this class and subject.",
            )
            return redirect(
                "marks:class_test_mark_submission_select"
            )  # Redirect back to selection
        # Also ensure the class_test_obj belongs to this teacher
        if class_test_obj.teacher != teacher_profile:
            messages.error(
                request,
                "You are not authorized to enter marks for this specific class test.",
            )
            return redirect("marks:class_test_mark_submission_select")

    if not (
        class_test_obj.academic_session == academic_session_obj
        and class_test_obj.class_obj == class_obj
        and class_test_obj.subject == subject_obj
    ):
        messages.error(
            request,
            "The selected Class Test does not match the provided Academic Session, Class, and Subject.",
        )
        return redirect("marks:class_test_mark_submission_select")

    # MODIFIED: Filter students to only include those WITHOUT existing marks for this class test
    students = (
        Student.objects.filter(
            current_class=class_obj, academic_session=academic_session_obj
        )
        .exclude(
            class_test_marks__class_test=class_test_obj  # Exclude students who already have a mark for THIS class test
        )
        .order_by("roll_number", "user__first_name")
    )

    ClassTestMarkFormSet = modelformset_factory(
        ClassTestMark,
        form=ClassTestMarkForm,
        extra=students.count(),  # Create one form for each student who needs marks
        can_delete=False,
        # Removed empty_permitted=True as it's deprecated and caused the TypeError.
        # Logic to handle empty forms will rely on has_changed() and has_mark_data()
    )

    if request.method == "POST":
        formset = ClassTestMarkFormSet(request.POST)

        student_map = {str(s.pk): s for s in students}

        for form in formset:
            if not form.instance.pk:  # This is a new form instance
                student_pk_from_post = request.POST.get(f"{form.prefix}-student")
                if student_pk_from_post and student_pk_from_post in student_map:
                    form.instance.student = student_map[student_pk_from_post]
                else:
                    form.add_error(
                        "student", "Student information is missing or invalid."
                    )

            # --- FIX: Set these foreign key fields on the instance BEFORE validation ---
            # academic_session_obj, class_obj, subject_obj are not direct fields on ClassTestMark model,
            # but class_test_obj is. Keeping the others for consistency with exam marks.
            # They are likely used for related object lookups in clean methods if they were defined on the model.
            form.instance.class_test = class_test_obj
            form.instance.recorded_by = request.user
            # --- END FIX ---

        if formset.is_valid():
            with transaction.atomic():
                saved_count = 0
                for form in formset:
                    # Only save if the form has changed AND has meaningful mark data
                    # Check for form.has_changed() to prevent saving unchanged forms,
                    # and has_mark_data() to prevent saving empty forms.
                    if form.has_changed() and has_mark_data(form):
                        if form.instance.student:  # Ensure student is linked
                            mark_instance = form.save(commit=False)
                            mark_instance.save()
                            saved_count += 1
                        else:
                            messages.warning(
                                request,
                                f"Skipped saving mark for unknown student due to missing ID.",
                            )
            if saved_count > 0:
                messages.success(
                    request, f"{saved_count} class test marks saved successfully!"
                )
            else:
                messages.info(request, "No new marks were entered.")
            return redirect("marks:class_test_mark_list")  # Redirect to the list view
        else:
            messages.error(request, "Please correct the errors in the form.")
            # Re-populate student_name and roll_number for displaying errors
            student_map = {s.pk: s for s in students}
            for form in formset:
                current_student = None
                if form.instance.student_id:
                    current_student = student_map.get(form.instance.student_id)
                elif f"{form.prefix}-student" in request.POST:
                    try:
                        student_pk_from_post = request.POST.get(
                            f"{form.prefix}-student"
                        )
                        current_student = student_map.get(int(student_pk_from_post))
                    except (ValueError, TypeError):
                        pass

                if current_student:
                    form.fields["student_name"].initial = (
                        current_student.user.get_full_name()
                    )
                    form.fields["roll_number"].initial = current_student.roll_number
                else:
                    form.fields["student_name"].initial = "N/A"
                    form.fields["roll_number"].initial = "N/A"

    else:  # GET request
        ClassTestMarkFormSet = modelformset_factory(
            ClassTestMark,
            form=ClassTestMarkForm,
            extra=students.count(),  # Create one form for each student who needs marks
            can_delete=False,
            # Removed empty_permitted=True as it's deprecated and caused the TypeError.
        )
        formset = ClassTestMarkFormSet(
            queryset=ClassTestMark.objects.none()
        )  # Pass empty queryset for new forms

        for i, form in enumerate(formset):
            if i < len(students):
                current_student = students[i]
                form.initial["student"] = current_student.pk
                form.fields["student_name"].initial = (
                    current_student.user.get_full_name()
                )
                form.fields["roll_number"].initial = current_student.roll_number
            else:
                pass

    context = {
        "page_title": page_title,
        "academic_session_obj": academic_session_obj,
        "class_obj": class_obj,
        "subject_obj": subject_obj,
        "class_test_obj": class_test_obj,
        "formset": formset,
    }
    return render(request, "marks/class_test_mark_entry_form.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can update class test marks
def class_test_mark_update_view(request, pk):
    mark = get_object_or_404(ClassTestMark, pk=pk)

    # Teacher-specific authorization check for updating class test marks
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        # Check if grading configuration allows teacher editing for this subject/class
        grading_config = GradingConfiguration.objects.filter(
            academic_session=mark.class_test.academic_session,
            class_obj=mark.class_test.class_obj,
            subject=mark.class_test.subject,
        ).first()

        if not grading_config or not grading_config.is_teacher_editable:
            messages.error(
                request,
                "You are not authorized to update marks for this subject/class.",
            )
            return redirect("marks:class_test_mark_list")  # Redirect back to marks list

        # Additionally, ensure the teacher is assigned to this class and subject and owns the class test
        if (
            not ClassSubjectAssignment.objects.filter(
                academic_session=mark.class_test.academic_session,
                class_obj=mark.class_test.class_obj,
                subject=mark.class_test.subject,
                teacher=teacher_profile,
            ).exists()
            or mark.class_test.teacher != teacher_profile
        ):
            messages.error(
                request, "You are not authorized to update this class test mark."
            )
            return redirect("marks:class_test_mark_list")

    if request.method == "POST":
        form = ClassTestMarkForm(request.POST, instance=mark)
        if form.is_valid():
            mark = form.save(commit=False)
            mark.recorded_by = request.user
            mark.save()
            messages.success(request, "Class Test mark updated successfully!")
            return redirect("marks:class_test_mark_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = ClassTestMarkForm(instance=mark)

    context = {
        "page_title": "Update Class Test Mark",
        "form": form,
        "mark": mark,
        "action": "update",
    }
    return render(request, "marks/class_test_mark_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can delete class test marks
def class_test_mark_delete_view(request, pk):
    mark = get_object_or_404(ClassTestMark, pk=pk)
    if request.method == "POST":
        try:
            mark.delete()
            messages.success(request, "Class Test deleted successfully!")
            return redirect("marks:class_test_list")
        except Exception as e:
            messages.error(request, f"Error deleting class test mark: {e}")
    context = {
        "page_title": "Confirm Delete Class Test Mark",
        "object": mark,
        "confirm_message": f"Are you sure you want to delete the mark for {mark.student.user.get_full_name()} in {mark.class_test.title}? This action cannot be undone.",
    }
    return render(request, "marks/class_test_mark_confirm_delete.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)  # Admin or Teacher can list class test marks
def class_test_mark_list_view(request):
    marks = ClassTestMark.objects.all().order_by(
        "-class_test__test_date",
        "class_test__class_obj__name",
        "class_test__subject__name",
        "student__roll_number",
    )
    # Teachers should only see marks for their assigned subjects/classes
    if request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        assigned_classes_subjects = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values("class_obj", "subject")
        marks = marks.filter(
            class_test__class_obj__in=[
                item["class_obj"] for item in assigned_classes_subjects
            ],
            class_test__subject__in=[
                item["subject"] for item in assigned_classes_subjects
            ],
        )

    paginator = Paginator(marks, 10)

    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {"page_title": "Class Test Marks", "page_obj": page_obj}
    return render(request, "marks/class_test_mark_list.html", context)


# --- Grading Configuration Views ---
@login_required
@user_passes_test(is_admin)  # Only Admin can manage Grading Configurations
def grading_configuration_list_view(request):
    grading_configs = GradingConfiguration.objects.all().order_by(
        "academic_session__name", "class_obj__name", "subject__name"
    )
    paginator = Paginator(grading_configs, 10)

    page_number = request.GET.get("page")
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {"page_title": "Grading Configurations", "page_obj": page_obj}
    return render(request, "marks/grading_configuration_list.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Grading Configurations
def grading_configuration_create_view(request):
    if request.method == "POST":
        form = GradingConfigurationForm(request.POST)
        if form.is_valid():
            grading_config = form.save(commit=False)
            grading_config.created_by = request.user
            grading_config.save()
            messages.success(request, "Grading Configuration created successfully!")
            return redirect("marks:grading_configuration_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = GradingConfigurationForm()

    context = {
        "page_title": "Create Grading Configuration",
        "form": form,
        "action": "create",
    }
    return render(request, "marks/grading_configuration_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Grading Configurations
def grading_configuration_update_view(request, pk):
    grading_config = get_object_or_404(GradingConfiguration, pk=pk)
    if request.method == "POST":
        form = GradingConfigurationForm(request.POST, instance=grading_config)
        if form.is_valid():
            grading_config = form.save(commit=False)
            grading_config.updated_by = request.user
            grading_config.save()
            messages.success(request, "Grading Configuration updated successfully!")
            return redirect("marks:grading_configuration_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = GradingConfigurationForm(instance=grading_config)

    context = {
        "page_title": "Update Grading Configuration",
        "form": form,
        "action": "update",
    }
    return render(request, "marks/grading_configuration_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage Grading Configurations
def grading_configuration_delete_view(request, pk):
    grading_config = get_object_or_404(GradingConfiguration, pk=pk)
    if request.method == "POST":
        try:
            grading_config.delete()
            messages.success(request, "Grading Configuration deleted successfully!")
            return redirect("marks:grading_configuration_list")
        except Exception as e:
            messages.error(request, f"Error deleting grading configuration: {e}")
    context = {
        "page_title": "Confirm Delete Grading Configuration",
        "object": grading_config,
        "confirm_message": f"Are you sure you want to delete the grading configuration for {grading_config.subject.name} in {grading_config.class_obj.name} ({grading_config.academic_session.name})? This action cannot be undone.",
    }
    return render(request, "marks/grading_configuration_confirm_delete.html", context)


# --- System Configuration Views ---
@login_required
@user_passes_test(is_admin)  # Only Admin can manage System Configurations
def system_configuration_list_view(request):
    # SystemConfiguration is a singleton, so we get the first or create one if it doesn't exist
    system_config, created = SystemConfiguration.objects.get_or_create(
        pk=1
    )  # Assuming pk=1 for the single instance

    if request.method == "POST":
        form = SystemConfigurationForm(request.POST, instance=system_config)
        if form.is_valid():
            system_config = form.save(commit=False)
            system_config.updated_by = request.user
            system_config.save()
            messages.success(request, "System Configuration updated successfully!")
            # Redirect to the same view or a dashboard after successful update
            return redirect(
                "marks:system_configuration_list"
            )  # Assuming this is the name of this view's URL
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = SystemConfigurationForm(instance=system_config)

    context = {
        "page_title": "System Configuration",
        "form": form,  # Pass the form to the template for display/editing
        "system_config": system_config,  # Pass the instance to the template for display if needed
    }
    # Render a form for a single instance, not a list
    return render(request, "marks/system_configuration_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage System Configurations
def system_configuration_create_view(request):
    if request.method == "POST":
        form = SystemConfigurationForm(request.POST)
        if form.is_valid():
            system_config = form.save(commit=False)
            system_config.created_by = request.user
            system_config.save()
            messages.success(request, "System Configuration created successfully!")
            return redirect("marks:system_configuration_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = SystemConfigurationForm()

    context = {
        "page_title": "Create System Configuration",
        "form": form,
        "action": "create",
    }
    return render(request, "marks/system_configuration_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage System Configurations
def system_configuration_update_view(request, pk):
    system_config = get_object_or_404(SystemConfiguration, pk=pk)
    if request.method == "POST":
        form = SystemConfigurationForm(request.POST, instance=system_config)
        if form.is_valid():
            system_config = form.save(commit=False)
            system_config.updated_by = request.user
            system_config.save()
            messages.success(request, "System Configuration updated successfully!")
            return redirect("marks:system_configuration_list")
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
    else:
        form = SystemConfigurationForm(instance=system_config)

    context = {
        "page_title": "Update System Configuration",
        "form": form,
        "action": "update",
    }
    return render(request, "marks/system_configuration_form.html", context)


@login_required
@user_passes_test(is_admin)  # Only Admin can manage System Configurations
def system_configuration_delete_view(request, pk):
    system_config = get_object_or_404(SystemConfiguration, pk=pk)
    if request.method == "POST":
        try:
            system_config.delete()
            messages.success(request, "System Configuration deleted successfully!")
            return redirect("marks:system_configuration_list")
        except Exception as e:
            messages.error(request, f"Error deleting system configuration: {e}")
    context = {
        "page_title": "Confirm Delete System Configuration",
        "object": system_config,
        "confirm_message": f"Are you sure you want to delete the system configuration '{system_config.config_key}'? This action cannot be undone.",
    }
    return render(request, "marks/system_configuration_confirm_delete.html", context)


# --- Marksheet View for Student ---
# This entire function block should replace your existing student_marksheet_view in marks/views.py
@login_required
@user_passes_test(
    lambda u: u.role == "student" or is_admin_or_teacher(u) or is_parent(u)
)
def student_marksheet_view(request, student_pk, academic_session_pk):
    student = get_object_or_404(Student, pk=student_pk)
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)

    # Authorization Check
    if request.user.role == "student":
        # Get the student profile linked to the logged-in user
        try:
            logged_in_student = Student.objects.get(user=request.user)
            if logged_in_student.pk != student_pk:
                messages.error(
                    request, "You are not authorized to view this marksheet."
                )
                return redirect("users:dashboard")
        except Student.DoesNotExist:
            messages.error(
                request,
                "Your student profile is not linked. Please contact an administrator.",
            )
            return redirect("users:dashboard")
    elif request.user.role == "parent":
        parent_profile = get_object_or_404(ParentProfile, user=request.user)
        if not student.parent == parent_profile:
            messages.error(
                request, "You are not authorized to view this child's marksheet."
            )
            return redirect("users:dashboard")
    elif request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        # Teachers can view if they are assigned to any subject in the student's current class for this session
        if not ClassSubjectAssignment.objects.filter(
            class_obj=student.current_class,
            academic_session=academic_session,
            teacher=teacher_profile,
        ).exists():
            messages.warning(
                request,
                "You can only view marksheets for students in your assigned classes/subjects.",
            )
            return redirect("users:dashboard")

    # Get system-wide configurations (defaults)
    system_config = SystemConfiguration.objects.first()
    default_main_exam_scaling_percentage = (
        system_config.main_exam_scaling_percentage
        if system_config
        else Decimal("90.00")
    )
    default_num_best_cts_to_consider = (
        system_config.default_num_best_cts_to_consider if system_config else 3
    )
    default_ct_scale_to_marks = (
        system_config.default_ct_scale_to_marks if system_config else Decimal("10.00")
    )
    default_pass_percentage = (
        system_config.default_pass_percentage if system_config else Decimal("33.00")
    )

    exam_types = ExamType.objects.filter(
        academic_session=academic_session, is_active=True
    ).order_by("name")

    subjects_in_class = ClassSubjectAssignment.objects.filter(
        class_obj=student.current_class, academic_session=academic_session
    ).values_list("subject", flat=True)
    subjects = Subject.objects.filter(pk__in=subjects_in_class).order_by("name")

    marks_data = {}  # This will store all processed data for the template

    total_final_percentages = []  # For overall average calculation

    for subject in subjects:
        marks_data[subject.name] = {
            "exam_marks": {},  # Raw exam marks (written, mcq, practical)
            "class_test_marks": [],  # Raw CT marks (objects)
            "class_tests_details": [],  # Processed CT details for display
            "exam_structure": None,  # Exam structure for main exams
            "grading_config": None,  # Specific grading config for this subject
            "final_percentage": Decimal(0),  # Calculated final percentage
            "final_grade": "N/A",  # Calculated final grade (A+, A, B, etc.)
            "pass_status": "N/A",  # Calculated pass/fail status
            "scaled_main_exam_marks": Decimal(0),  # Calculated scaled main exam marks
            "average_top_n_scaled_cts": Decimal(
                0
            ),  # Calculated average top N scaled CTs
            "total_main_exam_obtained": Decimal(0),  # Sum of written, mcq, practical
            "total_main_exam_max": Decimal(
                0
            ),  # Sum of max marks for written, mcq, practical (should be 100)
            "main_exam_remarks": "",  # Remarks from main exam
        }

        # 1. Get Exam Structure for the subject (assuming one main exam per subject per session)
        # We need to find the ExamType that is designated as the final exam for this session
        final_exam_type = ExamType.objects.filter(
            academic_session=academic_session, is_final_exam=True
        ).first()
        exam_structure = None  # Initialize exam_structure to None before the if block
        if final_exam_type:
            exam_structure = ExamStructure.objects.filter(
                exam_type=final_exam_type, subject=subject
            ).first()
            marks_data[subject.name]["exam_structure"] = exam_structure

            # Get student's marks for the final exam type
            student_final_exam_mark = StudentExamMark.objects.filter(
                student=student,
                academic_session=academic_session,
                class_obj=student.current_class,
                subject=subject,
                exam_type=final_exam_type,
            ).first()

            if student_final_exam_mark:
                marks_data[subject.name]["exam_marks"] = {
                    "written_marks": student_final_exam_mark.written_marks,
                    "mcq_marks": student_final_exam_mark.mcq_marks,
                    "practical_marks": student_final_exam_mark.practical_marks,
                }
                marks_data[subject.name][
                    "total_main_exam_obtained"
                ] = student_final_exam_mark.total_marks_obtained
                marks_data[subject.name][
                    "main_exam_remarks"
                ] = student_final_exam_mark.remarks
                if exam_structure:  # Check again if exam_structure was found
                    marks_data[subject.name][
                        "total_main_exam_max"
                    ] = exam_structure.total_max_marks
            else:
                # If no exam mark recorded, ensure numerical fields are 0 for calculation, 'N/A' for display
                marks_data[subject.name]["exam_marks"] = {
                    "written_marks": "N/A",
                    "mcq_marks": "N/A",
                    "practical_marks": "N/A",
                }
                if exam_structure:  # Check again if exam_structure was found
                    marks_data[subject.name][
                        "total_main_exam_max"
                    ] = exam_structure.total_max_marks
                else:  # No exam structure, no max marks
                    marks_data[subject.name]["total_main_exam_max"] = "N/A"

        # 2. Get Class Test Marks
        class_tests = ClassTest.objects.filter(
            academic_session=academic_session,
            class_obj=student.current_class,
            subject=subject,
        ).order_by("-test_date")

        for ct in class_tests:
            try:
                ct_mark = ClassTestMark.objects.get(class_test=ct, student=student)
                marks_data[subject.name]["class_test_marks"].append(ct_mark)
                marks_data[subject.name]["class_tests_details"].append(
                    {
                        "title": ct.title,
                        "test_date": ct.test_date,
                        "marks_obtained": ct_mark.marks_obtained,
                        "max_marks": ct.max_marks,
                        "remarks": ct_mark.remarks,
                    }
                )
            except ClassTestMark.DoesNotExist:
                # Student did not take this CT, or mark not entered
                pass

        # 3. Get Grading Configuration for this subject/class/session
        grading_config = GradingConfiguration.objects.filter(
            academic_session=academic_session,
            class_obj=student.current_class,
            subject=subject,
        ).first()
        marks_data[subject.name]["grading_config"] = grading_config

        # Determine actual values to use for calculation (from grading_config or system_config defaults)
        # Default CT contribution to 0 if no specific grading config or it's not explicitly set
        ct_contribution_percentage_effective = (
            grading_config.ct_contribution_percentage
            if grading_config
            else Decimal("0.00")
        )

        num_best_cts_to_consider_effective = (
            grading_config.num_best_cts_to_consider
            if grading_config
            else default_num_best_cts_to_consider
        )

        ct_scale_to_marks_effective = (
            grading_config.ct_scale_to_marks
            if grading_config
            else default_ct_scale_to_marks
        )

        # Main exam scaling is ALWAYS from SystemConfiguration as per SRS.
        main_exam_scaling_percentage_effective = default_main_exam_scaling_percentage

        # --- Perform Calculations as per SRS ---

        # A. Calculate Scaled Main Exam Marks
        scaled_main_exam_marks = Decimal(0)
        total_main_exam_obtained = marks_data[subject.name][
            "total_main_exam_obtained"
        ]  # This will be 0 if no mark entered

        # SRS: Scaled Main Exam Marks = (Student's Total Main Exam Marks / 100) * Scaling Percentage
        # We will use the actual total_max_marks from ExamStructure if it exists, otherwise assume 100.
        main_exam_max_for_scaling = Decimal(
            100
        )  # Default to 100 if exam_structure or total_max_marks is not available
        if exam_structure and exam_structure.total_max_marks > 0:
            main_exam_max_for_scaling = exam_structure.total_max_marks

        if main_exam_max_for_scaling > 0:
            # Ensure total_main_exam_obtained is treated as Decimal for calculation
            scaled_main_exam_marks = (
                Decimal(total_main_exam_obtained) / main_exam_max_for_scaling
            ) * main_exam_scaling_percentage_effective
        marks_data[subject.name]["scaled_main_exam_marks"] = (
            scaled_main_exam_marks.quantize(Decimal("0.01"))
        )

        # B. Calculate Average Top N Scaled CTs for Contribution
        scaled_ct_marks_for_average_calc = []
        for ct_mark_obj in marks_data[subject.name]["class_test_marks"]:
            if ct_mark_obj.class_test.max_marks > 0:
                # Scale each individual CT mark to the `ct_scale_to_marks_effective` value
                scaled_individual_ct = (
                    ct_mark_obj.marks_obtained / ct_mark_obj.class_test.max_marks
                ) * ct_scale_to_marks_effective
                scaled_ct_marks_for_average_calc.append(scaled_individual_ct)

        # Apply "Top N" logic
        if num_best_cts_to_consider_effective > 0:
            scaled_ct_marks_for_average_calc.sort(
                reverse=True
            )  # Sort descending to get best N
            scaled_ct_marks_for_average_calc = scaled_ct_marks_for_average_calc[
                :num_best_cts_to_consider_effective
            ]

        average_top_n_scaled_cts_raw = Decimal(0)
        if scaled_ct_marks_for_average_calc:
            average_top_n_scaled_cts_raw = sum(scaled_ct_marks_for_average_calc) / len(
                scaled_ct_marks_for_average_calc
            )

        marks_data[subject.name]["ct_average_raw_scaled_for_display"] = (
            average_top_n_scaled_cts_raw.quantize(Decimal("0.01"))
        )

        # Now, calculate the final contribution of this CT average to the overall 100% mark.
        # This is where the 'ct_contribution_percentage_effective' comes into play.
        # The average_top_n_scaled_cts_raw is 'out of' `ct_scale_to_marks_effective`.
        # We need to find what percentage of `ct_contribution_percentage_effective` this raw average represents.
        final_ct_contribution = Decimal(0)
        if ct_scale_to_marks_effective > 0:  # Avoid division by zero
            final_ct_contribution = (
                average_top_n_scaled_cts_raw / ct_scale_to_marks_effective
            ) * ct_contribution_percentage_effective
        else:  # If ct_scale_to_marks_effective is 0, then CT contribution is 0
            final_ct_contribution = Decimal(0)

        marks_data[subject.name]["ct_average_scaled"] = final_ct_contribution.quantize(
            Decimal("0.01")
        )

        # C. Calculate Final Calculated Marks (out of 100)
        # SRS: Final Marks = Scaled Main Exam Marks + Average Top N Scaled CTs (where these CTs are already scaled to their contribution)
        final_calculated_marks = (
            marks_data[subject.name]["scaled_main_exam_marks"]
            + marks_data[subject.name]["ct_average_scaled"]
        )
        marks_data[subject.name]["final_percentage"] = final_calculated_marks.quantize(
            Decimal("0.01")
        )

        # Add to overall total for average
        total_final_percentages.append(final_calculated_marks)

        # D. Determine Final Grade and Pass/Fail Status
        final_grade = "N/A"
        pass_status = "N/A"

        if grading_config:
            if final_calculated_marks >= grading_config.grade_a_plus_min:
                final_grade = "A+"
            elif final_calculated_marks >= grading_config.grade_a_min:
                final_grade = "A"
            elif final_calculated_marks >= grading_config.grade_b_min:
                final_grade = "B"
            elif final_calculated_marks >= grading_config.grade_c_min:
                final_grade = "C"
            elif final_calculated_marks >= grading_config.grade_d_min:
                final_grade = "D"
            else:
                final_grade = "F"

            pass_status = (
                "Pass"
                if final_calculated_marks >= grading_config.grade_d_min
                else "Fail"
            )
        else:
            # Fallback to system default pass percentage if no specific grading config
            if final_calculated_marks >= default_pass_percentage:
                final_grade = (
                    "Pass"  # Or consider a generic 'P' or 'S' for satisfactory
                )
                pass_status = "Pass"
            else:
                final_grade = "Fail"  # Or consider 'F' for failing
                pass_status = "Fail"

        marks_data[subject.name]["final_grade"] = final_grade
        marks_data[subject.name]["pass_status"] = pass_status

    # Calculate Overall Performance Summary
    overall_final_grade_percentage = Decimal(0)
    overall_final_letter_grade = "N/A"

    if total_final_percentages:
        overall_final_grade_percentage = sum(total_final_percentages) / len(
            total_final_percentages
        )
        overall_final_grade_percentage = overall_final_grade_percentage.quantize(
            Decimal("0.01")
        )

        # Determine overall letter grade (this is a simplified approach, could be more complex)
        # For simplicity, use system default pass percentage for overall pass/fail, and a generic grade.
        # For a truly accurate overall letter grade, you might need an 'overall' grading configuration
        # or a weighted average of individual subject grades.
        if system_config:
            if overall_final_grade_percentage >= system_config.default_pass_percentage:
                overall_final_letter_grade = "Pass (Overall)"  # Can be refined
            else:
                overall_final_letter_grade = "Fail (Overall)"  # Can be refined

    academic_sessions_list = AcademicSession.objects.all().order_by("-start_date")

    context = {
        "page_title": f"Marksheet for {student.user.get_full_name()} ({academic_session.name})",
        "student": student,
        "academic_session": academic_session,
        "exam_types": exam_types,
        "subjects": subjects,
        "marks_data": marks_data,  # This now contains all calculated final results
        "system_config": system_config,  # Pass system config for display if needed
        "academic_sessions_list": academic_sessions_list,  # For the session selector in template
        "overall_final_grade_percentage": overall_final_grade_percentage,  # New
        "overall_final_letter_grade": overall_final_letter_grade,  # New
    }
    return render(request, "marks/student_marksheet.html", context)


@login_required
@user_passes_test(
    lambda u: is_admin(u) or is_parent(u) or is_teacher(u)
)  # ADDED is_teacher(u)
def student_marksheet_select_view(request):
    academic_sessions = AcademicSession.objects.all().order_by("-start_date")
    students = Student.objects.all().order_by("user__first_name", "user__last_name")

    if request.user.role == "parent":
        parent_profile = get_object_or_404(ParentProfile, user=request.user)
        students = Student.objects.filter(parent=parent_profile).order_by(
            "user__first_name", "user__last_name"
        )
        if not students.exists():
            messages.info(
                request, "You have no registered children to view marksheets for."
            )
            return redirect("users:dashboard")

    if request.method == "POST":
        form = StudentMarksheetSelectForm(request.POST)
        if form.is_valid():
            student_pk = form.cleaned_data["student"].pk
            academic_session_pk = form.cleaned_data["academic_session"].pk
            return redirect(
                "marks:student_marksheet",
                student_pk=student_pk,
                academic_session_pk=academic_session_pk,
            )
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
            return redirect("marks:student_marksheet_select")
    else:
        initial_data = {}
        if request.user.role == "parent" and students.count() == 1:
            initial_data["student"] = students.first()
        if academic_sessions.count() == 1:
            initial_data["academic_session"] = academic_sessions.first()
        form = StudentMarksheetSelectForm(initial=initial_data)

    context = {
        "page_title": "Select Student Marksheet",
        "form": form,
        "students": students,
        "academic_sessions": academic_sessions,
    }
    return render(request, "marks/student_marksheet_select.html", context)


# --- Mark Comparison Views ---
@login_required
@user_passes_test(is_admin_or_teacher)
def mark_comparison_select_view(request):
    form = MarkComparisonSelectForm()
    context = {
        "page_title": "Compare Student Marks",
        "form": form,
    }
    return render(request, "marks/mark_comparison_select.html", context)


@login_required
@user_passes_test(is_admin_or_teacher)
def compare_marks_view(request):
    if request.method == "GET":
        form = MarkComparisonSelectForm(request.GET)
        if form.is_valid():
            academic_session = form.cleaned_data["academic_session"]
            class_obj = form.cleaned_data["class_obj"]
            subject = form.cleaned_data["subject"]
            student1 = form.cleaned_data["student1"]
            student2 = form.cleaned_data["student2"]

            marks1 = StudentExamMark.objects.filter(
                student=student1,
                academic_session=academic_session,
                class_obj=class_obj,
                subject=subject,
            ).order_by("exam_type__name")

            marks2 = StudentExamMark.objects.filter(
                student=student2,
                academic_session=academic_session,
                class_obj=class_obj,
                subject=subject,
            ).order_by("exam_type__name")

            comparison_data = []
            exam_types = ExamType.objects.filter(
                academic_session=academic_session, is_active=True
            ).order_by("name")

            for exam_type in exam_types:
                mark1 = marks1.filter(exam_type=exam_type).first()
                mark2 = marks2.filter(exam_type=exam_type).first()

                exam_structure = ExamStructure.objects.filter(
                    exam_type=exam_type, subject=subject
                ).first()
                max_marks = exam_structure.total_max_marks if exam_structure else "N/A"

                comparison_data.append(
                    {
                        "exam_type": exam_type.name,
                        "student1_marks": (
                            mark1.total_marks_obtained if mark1 else "N/A"
                        ),
                        "student2_marks": (
                            mark2.total_marks_obtained if mark2 else "N/A"
                        ),
                        "max_marks": max_marks,
                    }
                )

            context = {
                "page_title": "Mark Comparison Results",
                "academic_session": academic_session,
                "class_obj": class_obj,
                "subject": subject,
                "student1": student1,
                "student2": student2,
                "comparison_data": comparison_data,
            }
            return render(request, "marks/mark_comparison_results.html", context)
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(
                        request, f"{field.replace('_', ' ').title()}: {error}"
                    )
            return redirect("marks:mark_comparison_select")
    else:
        return redirect("marks:mark_comparison_select")


# --- Excel Export Views ---


@login_required
@user_passes_test(is_admin_or_teacher)
def export_exam_marks_excel_view(
    request, academic_session_pk, class_pk, subject_pk, exam_type_pk
):
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    exam_type = get_object_or_404(ExamType, pk=exam_type_pk)

    exam_structure = get_object_or_404(
        ExamStructure, exam_type=exam_type, subject=subject
    )

    students = Student.objects.filter(
        current_class=class_obj, academic_session=academic_session
    ).order_by("roll_number")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = (
        f"attachment; filename=exam_marks_{academic_session.name}_{class_obj.name}_{subject.name}_{exam_type.name}.xlsx"
    )

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Exam Marks"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(
        start_color="4F81BD", end_color="4F81BD", fill_type="solid"
    )
    border_thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center_aligned_text = Alignment(horizontal="center", vertical="center")

    headers = ["Roll No.", "Student Name"]
    if exam_structure.written_max_marks > 0:
        headers.append(f"Written ({exam_structure.written_max_marks})")
    if exam_structure.mcq_max_marks > 0:
        headers.append(f"MCQ ({exam_structure.mcq_max_marks})")
    if exam_structure.practical_max_marks > 0:
        headers.append(f"Practical ({exam_structure.practical_max_marks})")
    headers.append(f"Total ({exam_structure.total_max_marks})")
    headers.append("Remarks")
    headers.append("Pass/Fail")

    sheet.append(headers)

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = border_thin
        cell.alignment = center_aligned_text

    for student in students:
        mark = StudentExamMark.objects.filter(
            student=student,
            academic_session=academic_session,
            class_obj=class_obj,
            subject=subject,
            exam_type=exam_type,
        ).first()

        row_data = [student.roll_number, student.user.get_full_name()]
        if exam_structure.written_max_marks > 0:
            row_data.append(mark.written_marks if mark else "")
        if exam_structure.mcq_max_marks > 0:
            row_data.append(mark.mcq_marks if mark else "")
        if exam_structure.practical_max_marks > 0:
            row_data.append(mark.practical_marks if mark else "")
        row_data.append(mark.total_marks_obtained if mark else "")
        row_data.append(mark.remarks if mark else "")
        row_data.append("Pass" if mark and mark.pass_status else "Fail")

        sheet.append(row_data)

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=sheet.max_row, column=col)
            cell.border = border_thin
            cell.alignment = center_aligned_text

    for col in sheet.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = max_length + 2
        sheet.column_dimensions[column].width = adjusted_width

    workbook.save(response)
    return response


@login_required
@user_passes_test(is_admin_or_teacher)
def export_exam_marks_pdf_view(
    request, academic_session_pk, class_pk, subject_pk, exam_type_pk
):
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    exam_type = get_object_or_404(ExamType, pk=exam_type_pk)

    exam_structure = get_object_or_404(
        ExamStructure, exam_type=exam_type, subject=subject
    )

    students = Student.objects.filter(
        current_class=class_obj, academic_session=academic_session
    ).order_by("roll_number")

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f"attachment; filename=exam_marks_{academic_session.name}_{class_obj.name}_{subject.name}_{exam_type.name}.pdf"
    )

    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    title_style = ParagraphStyle(
        "TitleStyle", parent=styles["h1"], alignment=TA_CENTER, spaceAfter=14
    )
    elements.append(Paragraph(f"Exam Marks Report", title_style))
    elements.append(Paragraph(f"{exam_type.name} - {subject.name}", styles["h2"]))
    elements.append(
        Paragraph(
            f"Class: {class_obj.name}, Academic Session: {academic_session.name}",
            styles["h3"],
        )
    )
    elements.append(Spacer(1, 0.2 * inch))

    table_data = []
    headers = ["Roll No.", "Student Name"]
    if exam_structure.written_max_marks > 0:
        headers.append(f"Written ({exam_structure.written_max_marks})")
    if exam_structure.mcq_max_marks > 0:
        headers.append(f"MCQ ({exam_structure.mcq_max_marks})")
    if exam_structure.practical_max_marks > 0:
        headers.append(f"Practical ({exam_structure.practical_max_marks})")
    headers.append(f"Total ({exam_structure.total_max_marks})")
    headers.append("Remarks")
    headers.append("Pass/Fail")
    table_data.append(headers)

    for student in students:
        mark = StudentExamMark.objects.filter(
            student=student,
            academic_session=academic_session,
            class_obj=class_obj,
            subject=subject,
            exam_type=exam_type,
        ).first()

        row = [
            str(student.roll_number),
            student.user.get_full_name(),
            str(mark.written_marks) if mark and mark.written_marks is not None else "",
            str(mark.mcq_marks) if mark and mark.mcq_marks is not None else "",
            (
                str(mark.practical_marks)
                if mark and mark.practical_marks is not None
                else ""
            ),
            (
                str(mark.total_marks_obtained)
                if mark and mark.total_marks_obtained is not None
                else ""
            ),
            mark.remarks if mark else "",
            "Pass" if mark and mark.pass_status else "Fail",
        ]
        table_data.append(row)

    table_style = TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4F81BD")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]
    )

    num_dynamic_columns = 0
    if exam_structure.written_max_marks > 0:
        num_dynamic_columns += 1
    if exam_structure.mcq_max_marks > 0:
        num_dynamic_columns += 1
    if exam_structure.practical_max_marks > 0:
        num_dynamic_columns += 1

    col_widths = [1.0 * inch, 2.0 * inch]
    for _ in range(num_dynamic_columns):
        col_widths.append(0.8 * inch)
    col_widths.append(0.8 * inch)
    col_widths.append(1.5 * inch)
    col_widths.append(0.8 * inch)

    table = Table(table_data, colWidths=col_widths)
    table.setStyle(table_style)
    elements.append(table)

    doc.build(elements)
    return response


@login_required
@user_passes_test(is_admin_or_teacher)
def export_class_test_marks_excel_view(
    request, academic_session_pk, class_pk, subject_pk, class_test_pk
):
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    class_test = get_object_or_404(ClassTest, pk=class_test_pk)

    students_in_class = Student.objects.filter(
        current_class=class_obj, academic_session=academic_session
    ).order_by("roll_number")

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    response["Content-Disposition"] = (
        f"attachment; filename=class_test_marks_{academic_session.name}_{class_obj.name}_{subject.name}_{class_test.title}.xlsx"
    )

    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Class Test Marks"

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(
        start_color="4F81BD", end_color="4F81BD", fill_type="solid"
    )
    border_thin = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    center_aligned_text = Alignment(horizontal="center", vertical="center")

    headers = [
        "Roll No.",
        "Student Name",
        f"Marks Obtained ({class_test.max_marks})",
        "Remarks",
    ]
    sheet.append(headers)

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = border_thin
        cell.alignment = center_aligned_text

    for student in students_in_class:
        mark = ClassTestMark.objects.filter(
            student=student, class_test=class_test
        ).first()

        row_data = [
            student.roll_number,
            student.user.get_full_name(),
            mark.marks_obtained if mark else "",
            mark.remarks if mark else "",
        ]
        sheet.append(row_data)

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=sheet.max_row, column=col)
            cell.border = border_thin
            cell.alignment = center_aligned_text

    for col in sheet.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = max_length + 2
        sheet.column_dimensions[column].width = adjusted_width

    workbook.save(response)
    return response


@login_required
@user_passes_test(is_admin_or_teacher)
def export_class_test_marks_pdf_view(
    request, academic_session_pk, class_pk, subject_pk, class_test_pk
):
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    class_test = get_object_or_404(ClassTest, pk=class_test_pk)

    students_in_class = Student.objects.filter(
        current_class=class_obj, academic_session=academic_session
    ).order_by("roll_number")

    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f"attachment; filename=class_test_marks_{academic_session.name}_{class_obj.name}_{subject.name}_{class_test.title}.pdf"
    )

    doc = SimpleDocTemplate(response, pagesize=letter)
    styles = getSampleStyleSheet()
    elements = []

    title_style = ParagraphStyle(
        "TitleStyle", parent=styles["h1"], alignment=TA_CENTER, spaceAfter=14
    )
    elements.append(Paragraph(f"Class Test Marks Report", title_style))
    elements.append(Paragraph(f"{class_test.title} - {subject.name}", styles["h2"]))
    elements.append(
        Paragraph(
            f"Class: {class_obj.name}, Academic Session: {academic_session.name}",
            styles["h3"],
        )
    )
    elements.append(Spacer(1, 0.2 * inch))

    table_data = []
    headers = [
        "Roll No.",
        "Student Name",
        f"Marks Obtained ({class_test.max_marks})",
        "Remarks",
    ]
    table_data.append(headers)

    for student in students_in_class:
        mark = ClassTestMark.objects.filter(
            student=student, class_test=class_test
        ).first()

        row = [
            str(student.roll_number),
            student.user.get_full_name(),
            (
                str(mark.marks_obtained)
                if mark and mark.marks_obtained is not None
                else ""
            ),
            mark.remarks if mark else "",
        ]
        table_data.append(row)

    table_style = TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4F81BD")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]
    )

    col_widths = [1.0 * inch, 2.0 * inch, 1.5 * inch, 2.0 * inch]

    table = Table(table_data, colWidths=col_widths)
    table.setStyle(table_style)
    elements.append(table)

    doc.build(elements)
    return response


@login_required
@user_passes_test(
    lambda u: u.role == "student" or is_admin_or_teacher(u) or is_parent(u)
)
def generate_marksheet_pdf_view(request, student_pk, academic_session_pk):
    """
    Generates a PDF marksheet for a given student and academic session.
    """
    student = get_object_or_404(Student, pk=student_pk)
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)

    # Authorization Check (replicated from student_marksheet_view for consistency)
    if request.user.role == "student":
        try:
            logged_in_student = Student.objects.get(user=request.user)
            if logged_in_student.pk != student_pk:
                messages.error(
                    request, "You are not authorized to view this marksheet."
                )
                return redirect("users:dashboard")
        except Student.DoesNotExist:
            messages.error(
                request,
                "Your student profile is not linked. Please contact an administrator.",
            )
            return redirect("users:dashboard")
    elif request.user.role == "parent":
        parent_profile = get_object_or_404(ParentProfile, user=request.user)
        if not student.parent == parent_profile:
            messages.error(
                request, "You are not authorized to view this child's marksheet."
            )
            return redirect("users:dashboard")
    elif request.user.role == "teacher":
        teacher_profile = get_object_or_404(TeacherProfile, user=request.user)
        if not ClassSubjectAssignment.objects.filter(
            class_obj=student.current_class,
            academic_session=academic_session,
            teacher=teacher_profile,
        ).exists():
            messages.warning(
                request,
                "You can only view marksheets for students in your assigned classes/subjects.",
            )
            return redirect("users:dashboard")

    # Get system-wide configurations (defaults)
    system_config = SystemConfiguration.objects.first()
    default_main_exam_scaling_percentage = (
        system_config.main_exam_scaling_percentage
        if system_config
        else Decimal("90.00")
    )
    default_num_best_cts_to_consider = (
        system_config.default_num_best_cts_to_consider if system_config else 3
    )
    default_ct_scale_to_marks = (
        system_config.default_ct_scale_to_marks if system_config else Decimal("10.00")
    )
    default_pass_percentage = (
        system_config.default_pass_percentage if system_config else Decimal("33.00")
    )

    exam_types = ExamType.objects.filter(
        academic_session=academic_session, is_active=True
    ).order_by("name")

    subjects_in_class = ClassSubjectAssignment.objects.filter(
        class_obj=student.current_class, academic_session=academic_session
    ).values_list("subject", flat=True)
    subjects = Subject.objects.filter(pk__in=subjects_in_class).order_by("name")

    marks_data = {}  # This will store all processed data for the PDF

    total_final_percentages = []  # For overall average calculation

    for subject in subjects:
        marks_data[subject.name] = {
            "exam_marks": {},
            "class_test_marks": [],
            "class_tests_details": [],
            "exam_structure": None,
            "grading_config": None,
            "final_percentage": Decimal(0),
            "final_grade": "N/A",
            "pass_status": "N/A",
            "scaled_main_exam_marks": Decimal(0),
            "average_top_n_scaled_cts": Decimal(0),
            "total_main_exam_obtained": Decimal(0),
            "total_main_exam_max": Decimal(0),
            "main_exam_remarks": "",
        }

        final_exam_type = ExamType.objects.filter(
            academic_session=academic_session, is_final_exam=True
        ).first()
        exam_structure = None
        if final_exam_type:
            exam_structure = ExamStructure.objects.filter(
                exam_type=final_exam_type, subject=subject
            ).first()
            marks_data[subject.name]["exam_structure"] = exam_structure

            student_final_exam_mark = StudentExamMark.objects.filter(
                student=student,
                academic_session=academic_session,
                class_obj=student.current_class,
                subject=subject,
                exam_type=final_exam_type,
            ).first()

            if student_final_exam_mark:
                marks_data[subject.name]["exam_marks"] = {
                    "written_marks": student_final_exam_mark.written_marks,
                    "mcq_marks": student_final_exam_mark.mcq_marks,
                    "practical_marks": student_final_exam_mark.practical_marks,
                }
                marks_data[subject.name][
                    "total_main_exam_obtained"
                ] = student_final_exam_mark.total_marks_obtained
                marks_data[subject.name][
                    "main_exam_remarks"
                ] = student_final_exam_mark.remarks
                if exam_structure:
                    marks_data[subject.name][
                        "total_main_exam_max"
                    ] = exam_structure.total_max_marks
            else:
                marks_data[subject.name]["exam_marks"] = {
                    "written_marks": "N/A",
                    "mcq_marks": "N/A",
                    "practical_marks": "N/A",
                }
                if exam_structure:
                    marks_data[subject.name][
                        "total_main_exam_max"
                    ] = exam_structure.total_max_marks
                else:
                    marks_data[subject.name]["total_main_exam_max"] = "N/A"

        class_tests = ClassTest.objects.filter(
            academic_session=academic_session,
            class_obj=student.current_class,
            subject=subject,
        ).order_by("-test_date")

        for ct in class_tests:
            try:
                ct_mark = ClassTestMark.objects.get(class_test=ct, student=student)
                marks_data[subject.name]["class_test_marks"].append(ct_mark)
                marks_data[subject.name]["class_tests_details"].append(
                    {
                        "title": ct.title,
                        "test_date": ct.test_date,
                        "marks_obtained": ct_mark.marks_obtained,
                        "max_marks": ct.max_marks,
                        "remarks": ct_mark.remarks,
                    }
                )
            except ClassTestMark.DoesNotExist:
                pass

        grading_config = GradingConfiguration.objects.filter(
            academic_session=academic_session,
            class_obj=student.current_class,
            subject=subject,
        ).first()
        marks_data[subject.name]["grading_config"] = grading_config

        ct_contribution_percentage_effective = (
            grading_config.ct_contribution_percentage
            if grading_config
            else Decimal("0.00")
        )
        num_best_cts_to_consider_effective = (
            grading_config.num_best_cts_to_consider
            if grading_config
            else default_num_best_cts_to_consider
        )
        ct_scale_to_marks_effective = (
            grading_config.ct_scale_to_marks
            if grading_config
            else default_ct_scale_to_marks
        )
        main_exam_scaling_percentage_effective = default_main_exam_scaling_percentage

        scaled_main_exam_marks = Decimal(0)
        total_main_exam_obtained = marks_data[subject.name]["total_main_exam_obtained"]
        main_exam_max_for_scaling = Decimal(100)
        if exam_structure and exam_structure.total_max_marks > 0:
            main_exam_max_for_scaling = exam_structure.total_max_marks

        if main_exam_max_for_scaling > 0:
            scaled_main_exam_marks = (
                Decimal(total_main_exam_obtained) / main_exam_max_for_scaling
            ) * main_exam_scaling_percentage_effective
        marks_data[subject.name]["scaled_main_exam_marks"] = (
            scaled_main_exam_marks.quantize(Decimal("0.01"))
        )

        scaled_ct_marks_for_average_calc = []
        for ct_mark_obj in marks_data[subject.name]["class_test_marks"]:
            if ct_mark_obj.class_test.max_marks > 0:
                scaled_individual_ct = (
                    ct_mark_obj.marks_obtained / ct_mark_obj.class_test.max_marks
                ) * ct_scale_to_marks_effective
                scaled_ct_marks_for_average_calc.append(scaled_individual_ct)

        if num_best_cts_to_consider_effective > 0:
            scaled_ct_marks_for_average_calc.sort(reverse=True)
            scaled_ct_marks_for_average_calc = scaled_ct_marks_for_average_calc[
                :num_best_cts_to_consider_effective
            ]

        average_top_n_scaled_cts_raw = Decimal(0)
        if scaled_ct_marks_for_average_calc:
            average_top_n_scaled_cts_raw = sum(scaled_ct_marks_for_average_calc) / len(
                scaled_ct_marks_for_average_calc
            )

        marks_data[subject.name]["ct_average_raw_scaled_for_display"] = (
            average_top_n_scaled_cts_raw.quantize(Decimal("0.01"))
        )

        final_ct_contribution = Decimal(0)
        if ct_scale_to_marks_effective > 0:
            final_ct_contribution = (
                average_top_n_scaled_cts_raw / ct_scale_to_marks_effective
            ) * ct_contribution_percentage_effective
        else:
            final_ct_contribution = Decimal(0)

        marks_data[subject.name]["ct_average_scaled"] = final_ct_contribution.quantize(
            Decimal("0.01")
        )

        final_calculated_marks = (
            marks_data[subject.name]["scaled_main_exam_marks"]
            + marks_data[subject.name]["ct_average_scaled"]
        )
        marks_data[subject.name]["final_percentage"] = final_calculated_marks.quantize(
            Decimal("0.01")
        )

        total_final_percentages.append(final_calculated_marks)

        final_grade = "N/A"
        pass_status = "N/A"

        if grading_config:
            if final_calculated_marks >= grading_config.grade_a_plus_min:
                final_grade = "A+"
            elif final_calculated_marks >= grading_config.grade_a_min:
                final_grade = "A"
            elif final_calculated_marks >= grading_config.grade_b_min:
                final_grade = "B"
            elif final_calculated_marks >= grading_config.grade_c_min:
                final_grade = "C"
            elif final_calculated_marks >= grading_config.grade_d_min:
                final_grade = "D"
            else:
                final_grade = "F"

            pass_status = (
                "Pass"
                if final_calculated_marks >= grading_config.grade_d_min
                else "Fail"
            )
        else:
            if final_calculated_marks >= default_pass_percentage:
                final_grade = "Pass"
                pass_status = "Pass"
            else:
                final_grade = "Fail"
                pass_status = "Fail"

        marks_data[subject.name]["final_grade"] = final_grade
        marks_data[subject.name]["pass_status"] = pass_status

    overall_final_grade_percentage = Decimal(0)
    overall_final_letter_grade = "N/A"

    if total_final_percentages:
        overall_final_grade_percentage = sum(total_final_percentages) / len(
            total_final_percentages
        )
        overall_final_grade_percentage = overall_final_grade_percentage.quantize(
            Decimal("0.01")
        )

        if system_config:
            if overall_final_grade_percentage >= system_config.default_pass_percentage:
                overall_final_letter_grade = "Pass (Overall)"
            else:
                overall_final_letter_grade = "Fail (Overall)"

    # PDF Generation
    response = HttpResponse(content_type="application/pdf")
    response["Content-Disposition"] = (
        f'attachment; filename=marksheet_{student.user.get_full_name().replace(" ", "_")}_{academic_session.name.replace(" ", "_")}.pdf'
    )

    doc = SimpleDocTemplate(response, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = []

    # Title and Header
    title_style = ParagraphStyle(
        "TitleStyle",
        parent=styles["h1"],
        alignment=TA_CENTER,
        spaceAfter=14,
        fontSize=18,
        fontName="Helvetica-Bold",
    )
    elements.append(Paragraph("Student Marksheet", title_style))
    elements.append(
        Paragraph(f"Academic Session: {academic_session.name}", styles["h3"])
    )
    elements.append(Spacer(1, 0.2 * inch))

    # Student Information Table
    student_info_data = [
        ["Student Name:", student.user.get_full_name()],
        ["Admission Number:", student.admission_number],
        ["Class:", student.current_class.name if student.current_class else "N/A"],
        ["Roll Number:", student.roll_number if student.roll_number else "N/A"],
        ["Overall Percentage:", f"{overall_final_grade_percentage}%"],
        ["Overall Grade:", overall_final_letter_grade],
    ]

    student_info_table_style = TableStyle(
        [
            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
            ("FONTNAME", (1, 0), (-1, -1), "Helvetica"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]
    )
    student_info_table = Table(student_info_data, colWidths=[2.0 * inch, 4.0 * inch])
    student_info_table.setStyle(student_info_table_style)
    elements.append(student_info_table)
    elements.append(Spacer(1, 0.2 * inch))

    # Subject-wise Marks Table
    elements.append(Paragraph("Subject-wise Performance", styles["h2"]))
    elements.append(Spacer(1, 0.1 * inch))

    subject_table_headers = [
        "Subject",
        "Main Exam (Obt/Max)",
        "Scaled Main Exam",
        "CT Avg (Scaled)",
        "Final %",
        "Grade",
        "Status",
    ]
    subject_table_data = [subject_table_headers]

    for subject_name, data in marks_data.items():
        main_exam_obt = data["total_main_exam_obtained"]
        main_exam_max = data["total_main_exam_max"]
        main_exam_display = (
            f"{main_exam_obt}/{main_exam_max}" if main_exam_max != "N/A" else "N/A"
        )

        row = [
            subject_name,
            main_exam_display,
            f"{data['scaled_main_exam_marks']}%",
            f"{data['ct_average_scaled']}%",
            f"{data['final_percentage']}%",
            data["final_grade"],
            data["pass_status"],
        ]
        subject_table_data.append(row)

    subject_table_style = TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4F81BD")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
            ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ]
    )

    subject_table = Table(
        subject_table_data,
        colWidths=[
            1.5 * inch,
            1.2 * inch,
            1.2 * inch,
            1.2 * inch,
            0.8 * inch,
            0.8 * inch,
            0.8 * inch,
        ],
    )
    subject_table.setStyle(subject_table_style)
    elements.append(subject_table)
    elements.append(Spacer(1, 0.2 * inch))

    # Grading Scale and System Configurations (Optional, can be added if needed)
    elements.append(Paragraph("Grading Scale and Configuration Notes:", styles["h2"]))
    elements.append(Spacer(1, 0.1 * inch))
    elements.append(
        Paragraph(
            f"Main Exam Scaling: {default_main_exam_scaling_percentage}%",
            styles["Normal"],
        )
    )
    elements.append(
        Paragraph(
            f"Number of Best CTs Considered: {default_num_best_cts_to_consider}",
            styles["Normal"],
        )
    )
    elements.append(
        Paragraph(f"CTs Scaled to: {default_ct_scale_to_marks} marks", styles["Normal"])
    )
    elements.append(
        Paragraph(
            f"Default Pass Percentage: {default_pass_percentage}%", styles["Normal"]
        )
    )
    elements.append(Spacer(1, 0.2 * inch))

    doc.build(elements)  # Smila
    return response


@login_required
def student_marksheet_view(request, student_pk, academic_session_pk=None):
    """
    Renders the marksheet page exactly as before — untouched.
    """
    student = get_object_or_404(Student, pk=student_pk)

    if academic_session_pk:
        academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    else:
        session_id = request.GET.get("academic_session_pk")
        if session_id:
            academic_session = get_object_or_404(AcademicSession, pk=session_id)
        else:
            academic_session = AcademicSession.objects.order_by("-start_date").first()

    if not academic_session:
        messages.warning(request, "No academic session found.")
        return redirect("marks:student_marksheet_select")

    academic_sessions_list = AcademicSession.objects.all()
    system_config = SystemConfiguration.objects.first()
    grading_boundaries = {
        "A+": getattr(system_config, "grade_a_plus_min", 80),
        "A": getattr(system_config, "grade_a_min", 70),
        "B": getattr(system_config, "grade_b_min", 60),
        "C": getattr(system_config, "grade_c_min", 50),
        "D": getattr(system_config, "grade_d_min", 40),
    }

    def get_grade(percentage):
        if percentage is None:
            return None
        for grade, min_percent in grading_boundaries.items():
            if percentage >= min_percent:
                return grade
        return "F"

    marks_qs = StudentExamMark.objects.filter(
        student=student, academic_session=academic_session
    ).select_related("subject", "exam_type")

    marks_data = {}
    for mark in marks_qs:
        subject_name = mark.subject.name
        exam_structure = ExamStructure.objects.filter(
            subject=mark.subject, exam_type=mark.exam_type
        ).first()
        scaled_main_exam = None
        if exam_structure and exam_structure.total_max_marks:
            scaled_main_exam = (
                round(
                    (mark.total_marks_obtained / exam_structure.total_max_marks) * 100,
                    2,
                )
                if mark.total_marks_obtained is not None
                else None
            )

        ct_avg_scaled = None
        class_test_qs = ClassTestMark.objects.filter(
            student=student,
            class_test__subject=mark.subject,
            class_test__academic_session=academic_session,
        )
        if class_test_qs.exists():
            total_ct_marks = sum(
                ct.marks_obtained
                for ct in class_test_qs
                if hasattr(ct, "marks_obtained") and ct.marks_obtained is not None
            )
            total_ct_max = sum(
                ct.class_test.max_marks
                for ct in class_test_qs
                if hasattr(ct.class_test, "max_marks")
                and ct.class_test.max_marks is not None
            )
            if total_ct_max > 0:
                ct_avg_scaled = round((total_ct_marks / total_ct_max) * 100, 2)

        final_percentage = None
        if scaled_main_exam is not None and ct_avg_scaled is not None:
            final_percentage = round((scaled_main_exam + ct_avg_scaled) / 2, 2)

        final_grade = get_grade(final_percentage)

        marks_data[subject_name] = {
            "exam_marks": mark,
            "exam_structure": exam_structure,
            "written_marks": getattr(mark, "written_marks", None),
            "written_max": (
                getattr(exam_structure, "written_max_marks", None)
                if exam_structure
                else None
            ),
            "mcq_marks": getattr(mark, "mcq_marks", None),
            "mcq_max": (
                getattr(exam_structure, "mcq_max_marks", None)
                if exam_structure
                else None
            ),
            "practical_marks": getattr(mark, "practical_marks", None),
            "practical_max": (
                getattr(exam_structure, "practical_max_marks", None)
                if exam_structure
                else None
            ),
            "total_main_exam_obtained": getattr(mark, "total_marks_obtained", None),
            "total_main_exam_max": (
                getattr(exam_structure, "total_max_marks", None)
                if exam_structure
                else None
            ),
            "scaled_main_exam_marks": scaled_main_exam,
            "ct_average_scaled": ct_avg_scaled,
            "final_percentage": final_percentage,
            "final_grade": final_grade,
            "pass_status": "Pass" if mark.pass_status else "Fail",
            "class_test_marks": class_test_qs,
        }

    overall_final_grade_percentage = None
    overall_final_letter_grade = None
    if marks_qs.exists():
        total_percentage_sum = sum(
            md["final_percentage"]
            for md in marks_data.values()
            if md["final_percentage"] is not None
        )
        subjects_with_percentage = sum(
            1 for md in marks_data.values() if md["final_percentage"] is not None
        )
        if subjects_with_percentage > 0:
            overall_final_grade_percentage = round(
                total_percentage_sum / subjects_with_percentage, 2
            )
            overall_final_letter_grade = get_grade(overall_final_grade_percentage)

    context = {
        "page_title": "Student Marksheet",
        "student": student,
        "academic_session": academic_session,
        "academic_sessions_list": academic_sessions_list,
        "marks_data": marks_data,
        "overall_final_grade_percentage": overall_final_grade_percentage,
        "overall_final_letter_grade": overall_final_letter_grade,
        "system_config": system_config,
    }

    return render(request, "marks/student_marksheet.html", context)


@login_required
def official_result_card(request, student_pk, academic_session_pk=None):
    from openpyxl.cell.cell import MergedCell
    from openpyxl.worksheet.page import PageMargins
    from openpyxl.utils import get_column_letter

    def round_half_up(value):
        if value in ("", None):
            return ""
        return Decimal(value).quantize(Decimal("1"), rounding=ROUND_HALF_UP)

    # ---- Student & Session ----
    student = get_object_or_404(Student, pk=student_pk)
    academic_session = (
        get_object_or_404(AcademicSession, pk=academic_session_pk)
        if academic_session_pk
        else AcademicSession.objects.order_by("-start_date").first()
    )
    system_cfg = SystemConfiguration.objects.first()

    # ---- Helpers ----
    def compute_ct_scaled_for_term(student, academic_session, subject, exam_type: ExamType, system_cfg):
        if not subject or not exam_type:
            return ""
        default_num_best = system_cfg.default_num_best_cts_to_consider or 3
        default_ct_scale = Decimal(system_cfg.default_ct_scale_to_marks or "10.00")
        grading_cfg = GradingConfiguration.objects.filter(
            academic_session=academic_session,
            class_obj=student.current_class,
            subject=subject,
        ).first()
        num_best = grading_cfg.num_best_cts_to_consider if grading_cfg else default_num_best
        ct_scale = Decimal(grading_cfg.ct_contribution_percentage) if grading_cfg else default_ct_scale
        qs = (
            ClassTestMark.objects.filter(
                student=student,
                class_test__class_obj=student.current_class,
                class_test__subject=subject,
                class_test__exam_type=exam_type,
            ).select_related("class_test").order_by("class_test__test_date")
        )
        if not qs.exists():
            return ""
        scaled_points = []
        for ctm in qs:
            if ctm.marks_obtained is not None and ctm.class_test and ctm.class_test.max_marks:
                s = (Decimal(ctm.marks_obtained) / Decimal(ctm.class_test.max_marks)) * ct_scale
                scaled_points.append(s)
        if not scaled_points:
            return ""
        scaled_points.sort(reverse=True)
        if num_best > 0:
            scaled_points = scaled_points[:num_best]
        avg_scaled = sum(scaled_points) / Decimal(len(scaled_points))
        return round_half_up(avg_scaled)

    def calc_gpa(total_mark):
        if total_mark is None: return Decimal("0.00")
        if total_mark >= 80: return Decimal("5.00")
        if total_mark >= 70: return Decimal("4.00")
        if total_mark >= 60: return Decimal("3.50")
        if total_mark >= 50: return Decimal("3.00")
        if total_mark >= 40: return Decimal("2.00")
        if total_mark >= 33: return Decimal("1.00")
        return Decimal("0.00")

    def calc_grade(total_mark, merged=False):
        if total_mark is None: return "F"
        if merged:
            if total_mark >= 160: return "A+"
            if total_mark >= 140: return "A"
            if total_mark >= 120: return "A-"
            if total_mark >= 100: return "B"
            if total_mark >= 80: return "C"
            if total_mark >= 66: return "D"
            return "F"
        else:
            if total_mark >= 80: return "A+"
            if total_mark >= 70: return "A"
            if total_mark >= 60: return "A-"
            if total_mark >= 50: return "B"
            if total_mark >= 40: return "C"
            if total_mark >= 33: return "D"
            return "F"

    def pass_fail_ok(cq, mcq, prac, mark_obj):
        cq, mcq, prac = cq or 0, mcq or 0, prac or 0
        try:
            es = ExamStructure.objects.get(exam_type=mark_obj.exam_type, subject=mark_obj.subject)
            cq_max, mcq_max, prac_max = es.written_max_marks or 0, es.mcq_max_marks or 0, es.practical_max_marks or 0
        except ExamStructure.DoesNotExist:
            cq_max, mcq_max, prac_max = 0, 0, 0
        if cq_max > 0 and mcq_max == 0 and prac_max == 0: return cq >= 33
        elif cq_max > 0 and mcq_max > 0 and prac_max == 0: return cq >= 17 and mcq >= 7
        elif cq_max > 0 and mcq_max > 0 and prac_max > 0: return cq >= 17 and mcq >= 7 and prac >= 7
        else: return (cq + mcq + prac) >= 33

    def parts_total(mark_obj):
        if not mark_obj: return None, None, None, None
        cq = mark_obj.written_marks if mark_obj.written_marks is not None else None
        mcq = mark_obj.mcq_marks if mark_obj.mcq_marks is not None else None
        prac = mark_obj.practical_marks if mark_obj.practical_marks is not None else None
        tot = (cq or 0) + (mcq or 0) + (prac or 0)
        return cq, mcq, prac, tot

    def compute_scaled_total(mark_obj, ct_score):
        if not mark_obj: return None
        raw_total = (mark_obj.written_marks or 0) + (mark_obj.mcq_marks or 0) + (mark_obj.practical_marks or 0)
        exam_scale = Decimal(system_cfg.main_exam_scaling_percentage or "100.00")
        scaled_exam = (Decimal(raw_total) / Decimal(100)) * exam_scale
        final_total = scaled_exam + (Decimal(ct_score) if ct_score not in ("", None) else 0)
        return round_half_up(final_total)

    def is_half(name): return bool(name and re.search(r'\b(half|mid|term ?1|semester ?1)\b', name, re.I))
    def is_year(name): return bool(name and re.search(r'\b(final|yearly|annual|term ?2|semester ?2)\b', name, re.I))

    subject_row_map = {
        "bangla 1st paper": 15,"bangla 2nd paper": 16,"english 1st paper": 17,"english 2nd paper": 18,
        "mathematics": 19,"religious studies": 20,"bangladesh & social science": 21,"ict": 22,"physics": 23,
        "chemistry": 24,"biology": 25,"higher math": 26,"physical studies": 27,"career": 28
    }
    SUBJECT_ORDER = list(subject_row_map.keys())

    all_marks = StudentExamMark.objects.filter(student=student, academic_session=academic_session).select_related("subject", "exam_type")
    half_by_name, final_by_name = {}, {}
    for m in all_marks:
        subj = (m.subject.name or "").strip().lower()
        etname = m.exam_type.name if m.exam_type else ""
        if is_half(etname): half_by_name[subj] = m
        elif is_year(etname): final_by_name[subj] = m

    wb = load_workbook(TEMPLATE_PATH, data_only=True)
    ws = wb.active

    white_fill = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")

    def safe_set(cell_ref, value):
        real_cell = ws[cell_ref]
        if isinstance(real_cell, MergedCell):
            for merged_range in ws.merged_cells.ranges:
                if cell_ref in merged_range:
                    cell = ws.cell(row=merged_range.min_row, column=merged_range.min_col)
                    cell.value = value
                    if value in ("", None):
                        cell.fill = white_fill
                    return
        else:
            real_cell.value = value
            if value in ("", None):
                real_cell.fill = white_fill

    # ---- Header ----
    safe_set("D9", f"Student's Name : {student.user.get_full_name()}     Father's Name: {getattr(student, 'father_name', '')}")
    safe_set("D11", f"Class: {getattr(student.current_class, 'name', '')}    Roll: {getattr(student, 'roll_number', '')}    Section: {getattr(getattr(student, 'section', None), 'name', '')}    Division: {getattr(student, 'division', '')}")

    # ---- Fill Subjects ----
    for name in SUBJECT_ORDER:
        row = subject_row_map[name]
        half = half_by_name.get(name)
        fin = final_by_name.get(name)
        subject = half.subject if half else fin.subject if fin else None

        half_exam_type = ExamType.objects.filter(Q(name__iregex=r'\bhalf\b') | Q(name__iregex=r'\bmid\b') | Q(name__iregex=r'term ?1') | Q(name__iregex=r'semester ?1')).first()
        year_exam_type = ExamType.objects.filter(Q(name__iregex=r'\b(final|yearly|annual)\b') | Q(name__iregex=r'term ?2') | Q(name__iregex=r'semester ?2')).first()

        ct_half = compute_ct_scaled_for_term(student, academic_session, subject, half_exam_type, system_cfg)
        ct_year = compute_ct_scaled_for_term(student, academic_session, subject, year_exam_type, system_cfg)

        safe_set(f"D{row}", float(ct_half) if ct_half != "" else "")
        safe_set(f"L{row}", float(ct_year) if ct_year != "" else "")

        hcq, hmcq, hpr, htot = parts_total(half) if half else (None, None, None, None)
        safe_set(f"E{row}", hcq if hcq is not None else "")
        safe_set(f"F{row}", hmcq if hmcq is not None else "")
        safe_set(f"G{row}", hpr if hpr is not None else "")

        fcq, fmcq, fpr, ftot = parts_total(fin) if fin else (None, None, None, None)
        safe_set(f"M{row}", fcq if fcq is not None else "")
        safe_set(f"N{row}", fmcq if fmcq is not None else "")
        safe_set(f"O{row}", fpr if fpr is not None else "")

        # Bangla & English merged logic (Grade only on 1st paper, GPA both)
        if name == "bangla 1st paper" and half:
            total1 = compute_scaled_total(half, ct_half)
            total2 = compute_scaled_total(half_by_name.get("bangla 2nd paper"), ct_half) if "bangla 2nd paper" in half_by_name else 0
            merged_total = round_half_up((total1 or 0) + (total2 or 0))
            pass1 = pass_fail_ok(hcq, hmcq, hpr, half)
            pass2 = True
            if "bangla 2nd paper" in half_by_name:
                hcq2, hmcq2, hpr2, _ = parts_total(half_by_name["bangla 2nd paper"])
                pass2 = pass_fail_ok(hcq2, hmcq2, hpr2, half_by_name["bangla 2nd paper"])
            safe_set("H15", float(merged_total))
            grade = calc_grade(merged_total, merged=True) if (pass1 and pass2) else "F"
            gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total1)
            safe_set("J15", float(gpa_val)); safe_set("K15", grade)
        if name == "bangla 2nd paper" and half:
            total2 = compute_scaled_total(half, ct_half)
            gpa_val2 = Decimal("0.00") if not pass_fail_ok(hcq, hmcq, hpr, half) else calc_gpa(total2)
            safe_set("J16", float(gpa_val2))

        if name == "bangla 1st paper" and fin:
            total1 = compute_scaled_total(fin, ct_year)
            total2 = compute_scaled_total(final_by_name.get("bangla 2nd paper"), ct_year) if "bangla 2nd paper" in final_by_name else 0
            merged_total = round_half_up((total1 or 0) + (total2 or 0))
            pass1 = pass_fail_ok(fcq, fmcq, fpr, fin)
            pass2 = True
            if "bangla 2nd paper" in final_by_name:
                fcq2, fmcq2, fpr2, _ = parts_total(final_by_name["bangla 2nd paper"])
                pass2 = pass_fail_ok(fcq2, fmcq2, fpr2, final_by_name["bangla 2nd paper"])
            safe_set("P15", float(merged_total))
            grade = calc_grade(merged_total, merged=True) if (pass1 and pass2) else "F"
            gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total1)
            safe_set("R15", float(gpa_val)); safe_set("S15", grade)
        if name == "bangla 2nd paper" and fin:
            total2 = compute_scaled_total(fin, ct_year)
            gpa_val2 = Decimal("0.00") if not pass_fail_ok(fcq, fmcq, fpr, fin) else calc_gpa(total2)
            safe_set("R16", float(gpa_val2))

        if name == "english 1st paper" and half:
            total1 = compute_scaled_total(half, ct_half)
            total2 = compute_scaled_total(half_by_name.get("english 2nd paper"), ct_half) if "english 2nd paper" in half_by_name else 0
            merged_total = round_half_up((total1 or 0) + (total2 or 0))
            pass1 = pass_fail_ok(hcq, hmcq, hpr, half)
            pass2 = True
            if "english 2nd paper" in half_by_name:
                hcq2, hmcq2, hpr2, _ = parts_total(half_by_name["english 2nd paper"])
                pass2 = pass_fail_ok(hcq2, hmcq2, hpr2, half_by_name["english 2nd paper"])
            safe_set("H17", float(merged_total))
            grade = calc_grade(merged_total, merged=True) if (pass1 and pass2) else "F"
            gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total1)
            safe_set("J17", float(gpa_val)); safe_set("K17", grade)
        if name == "english 2nd paper" and half:
            total2 = compute_scaled_total(half, ct_half)
            gpa_val2 = Decimal("0.00") if not pass_fail_ok(hcq, hmcq, hpr, half) else calc_gpa(total2)
            safe_set("J18", float(gpa_val2))

        if name == "english 1st paper" and fin:
            total1 = compute_scaled_total(fin, ct_year)
            total2 = compute_scaled_total(final_by_name.get("english 2nd paper"), ct_year) if "english 2nd paper" in final_by_name else 0
            merged_total = round_half_up((total1 or 0) + (total2 or 0))
            pass1 = pass_fail_ok(fcq, fmcq, fpr, fin)
            pass2 = True
            if "english 2nd paper" in final_by_name:
                fcq2, fmcq2, fpr2, _ = parts_total(final_by_name["english 2nd paper"])
                pass2 = pass_fail_ok(fcq2, fmcq2, fpr2, final_by_name["english 2nd paper"])
            safe_set("P17", float(merged_total))
            grade = calc_grade(merged_total, merged=True) if (pass1 and pass2) else "F"
            gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total1)
            safe_set("R17", float(gpa_val)); safe_set("S17", grade)
        if name == "english 2nd paper" and fin:
            total2 = compute_scaled_total(fin, ct_year)
            gpa_val2 = Decimal("0.00") if not pass_fail_ok(fcq, fmcq, fpr, fin) else calc_gpa(total2)
            safe_set("R18", float(gpa_val2))

        if not ("bangla" in name or "english" in name):
            if half:
                total_with_ct = compute_scaled_total(half, ct_half)
                safe_set(f"H{row}", float(total_with_ct) if total_with_ct else "")
                grade = "F" if not pass_fail_ok(hcq, hmcq, hpr, half) else calc_grade(total_with_ct)
                gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total_with_ct)
                safe_set(f"J{row}", float(gpa_val)); safe_set(f"K{row}", grade)
            if fin:
                total_with_ct_y = compute_scaled_total(fin, ct_year)
                safe_set(f"P{row}", float(total_with_ct_y) if total_with_ct_y else "")
                grade = "F" if not pass_fail_ok(fcq, fmcq, fpr, fin) else calc_grade(total_with_ct_y)
                gpa_val = Decimal("0.00") if grade == "F" else calc_gpa(total_with_ct_y)
                safe_set(f"R{row}", float(gpa_val)); safe_set(f"S{row}", grade)

    # ---- Merge TOTAL + GRADE cells for Bangla & English ----
    merge_pairs = [(15, 16), (17, 18)]
    for r1, r2 in merge_pairs:
        ws.merge_cells(start_row=r1, start_column=8, end_row=r2, end_column=8)   # Half-Yearly Total H
        ws.merge_cells(start_row=r1, start_column=11, end_row=r2, end_column=11) # Half-Yearly Grade K
        ws.merge_cells(start_row=r1, start_column=16, end_row=r2, end_column=16) # Yearly Total P
        ws.merge_cells(start_row=r1, start_column=19, end_row=r2, end_column=19) # Yearly Grade S

        # ---- Print Setup ----
    ws.print_options.horizontalCentered = True
    ws.print_options.verticalCentered = True

    # Dynamic margins: shrink bottom so footer doesn't overflow
    ws.page_margins = PageMargins(left=0.5, right=0.5, top=0.5, bottom=0.2, header=0.3, footer=0.2)

    # Detect last used cell to define print area
    max_row_used, max_col_used = 0, 0
    for r in ws.iter_rows():
        for cell in r:
            if cell.value not in (None, ""):
                max_row_used = max(max_row_used, cell.row)
                max_col_used = max(max_col_used, cell.column)
    if max_row_used > 0 and max_col_used > 0:
        ws.print_area = f"A1:{get_column_letter(max_col_used)}{max_row_used}"

    # Force fit everything to exactly ONE page
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 1

    # ---- Save Excel ----
    xlsx_path = os.path.join(settings.MEDIA_ROOT, f"{student.roll_number}_result.xlsx")
    wb.save(xlsx_path)

    # ---- Convert to PDF ----
    soffice_path = r"C:\\Program Files\\LibreOffice\\program\\soffice.exe"
    soffice_cmd = soffice_path if os.path.exists(soffice_path) else "soffice"
    subprocess.run([soffice_cmd, "--headless", "--convert-to", "pdf", "--outdir", settings.MEDIA_ROOT, xlsx_path], check=True)

    pdf_path = os.path.join(settings.MEDIA_ROOT, f"{student.roll_number}_result.pdf")
    if os.path.exists(xlsx_path): os.remove(xlsx_path)

    return FileResponse(open(pdf_path, "rb"), content_type="application/pdf")
