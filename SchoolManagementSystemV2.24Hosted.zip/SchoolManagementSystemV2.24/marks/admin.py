# SchoolManagementManagementSystem/marks/admin.py
from django.contrib import admin

from .models import (
    ExamType,
    StudentExamMark,
    ClassTest,
    ClassTestMark,
    GradingConfiguration,
    ExamStructure,
    SystemConfiguration,
)


# Register ExamType model
@admin.register(ExamType)
class ExamTypeAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "academic_session",
        "is_final_exam",
        "is_active",
        "created_by",
        "updated_by",
    )
    list_filter = ("academic_session", "is_final_exam", "is_active")
    search_fields = ("name",)
    ordering = ("-academic_session__start_date", "name")
    raw_id_fields = ("academic_session", "created_by", "updated_by")


# Register ExamStructure model with multi-subject creation
from exams.forms import ExamStructureMultiForm  # import the form from exams


@admin.register(ExamStructure)
class ExamStructureAdmin(admin.ModelAdmin):
    list_display = (
        "exam_type",
        "subject",
        "written_max_marks",
        "mcq_max_marks",
        "practical_max_marks",
        "total_max_marks",
    )
    list_filter = ("exam_type__academic_session", "exam_type", "subject")
    search_fields = ("exam_type__name", "subject__name")
    raw_id_fields = ("exam_type", "subject")
    ordering = ("exam_type__name", "subject__name")

    def get_changelist_form(self, request, **kwargs):
        """
        Override the form to use our multi-subject selection.
        """
        return ExamStructureMultiForm

    def save_model(self, request, obj, form, change):
        """
        Create one ExamStructure per subject if multiple are selected.
        """
        exam_type = form.cleaned_data["exam_type"]
        subjects = form.cleaned_data["subjects"]
        total_max_marks = form.cleaned_data["total_max_marks"]

        for subj in subjects:
            ExamStructure.objects.create(
                exam_type=exam_type, subject=subj, total_max_marks=total_max_marks
            )


# Register StudentExamMark model
@admin.register(StudentExamMark)
class StudentExamMarkAdmin(admin.ModelAdmin):
    list_display = (
        "student",
        "academic_session",
        "class_obj",
        "subject",
        "exam_type",
        "written_marks",
        "mcq_marks",
        "practical_marks",
        "total_marks_obtained",
        "recorded_by",
        "recorded_at",
    )
    list_filter = (
        "academic_session",
        "class_obj",
        "subject",
        "exam_type",
        "recorded_by",
    )
    search_fields = (
        "student__user__first_name",
        "student__user__last_name",
        "subject__name",
        "exam_type__name",
        "remarks",
    )
    raw_id_fields = (
        "student",
        "academic_session",
        "class_obj",
        "subject",
        "exam_type",
        "recorded_by",
    )
    date_hierarchy = "recorded_at"
    ordering = (
        "-recorded_at",
        "academic_session__name",
        "class_obj__name",
        "subject__name",
        "student__user__last_name",
    )


# Register ClassTest model
# marks/admin.py
# marks/admin.py
from django.contrib import admin
from .models import ClassTest


@admin.register(ClassTest)
class ClassTestAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "class_obj",
        "subject",
        "exam_type",
        "max_marks",
        "test_date",
    )
    list_filter = ("class_obj", "subject", "exam_type", "test_date")
    search_fields = ("title", "subject__name", "class_obj__name")
    raw_id_fields = ("class_obj", "subject", "teacher", "exam_type")


# Register ClassTestMark model
@admin.register(ClassTestMark)
class ClassTestMarkAdmin(admin.ModelAdmin):
    list_display = (
        "class_test",
        "student",
        "marks_obtained",
        "recorded_at",
        "recorded_by",
    )
    list_filter = (
        "class_test__academic_session",
        "class_test__class_obj",
        "class_test__subject",
        "recorded_at",
    )
    search_fields = (
        "class_test__title",
        "student__user__first_name",
        "student__user__last_name",
    )
    raw_id_fields = ("class_test", "student", "recorded_by")
    date_hierarchy = "recorded_at"
    ordering = ("-recorded_at", "class_test__title", "student__user__last_name")


# Register GradingConfiguration model
@admin.register(GradingConfiguration)
class GradingConfigurationAdmin(admin.ModelAdmin):
    list_display = (
        "academic_session",
        "class_obj",
        "subject",
        "ct_contribution_percentage",
        "num_best_cts_to_consider",
        "ct_scale_to_marks",
    )
    list_filter = ("academic_session", "class_obj", "subject")
    search_fields = ("academic_session__name", "class_obj__name", "subject__name")
    raw_id_fields = (
        "academic_session",
        "class_obj",
        "subject",
        "created_by",
        "updated_by",
    )
    ordering = ("academic_session__name", "class_obj__name", "subject__name")


# Register SystemConfiguration model
@admin.register(SystemConfiguration)
class SystemConfigurationAdmin(admin.ModelAdmin):
    # UPDATED list_display, list_filter, and ordering to match new model fields
    list_display = (
        "main_exam_scaling_percentage",
        "default_num_best_cts_to_consider",
        "default_ct_scale_to_marks",
        "default_pass_percentage",
        "updated_at",
    )
    list_filter = (
        "main_exam_scaling_percentage",
        "default_num_best_cts_to_consider",
        "default_pass_percentage",
    )
    # SystemConfiguration is a singleton, so no specific ordering is typically needed beyond updated_at
    ordering = ("-updated_at",)
    raw_id_fields = ("updated_by",)

    # Restrict to only one instance
    def has_add_permission(self, request):
        return not SystemConfiguration.objects.exists()

    def has_delete_permission(self, request, obj=None):
        return False  # Prevent deletion of the single instance
