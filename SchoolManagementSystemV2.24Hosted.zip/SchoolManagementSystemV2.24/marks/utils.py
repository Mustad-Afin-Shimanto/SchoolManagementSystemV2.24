from openpyxl import load_workbook
import excel2img
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import os


def generate_result_pdf_from_excel(student, marks, template_path, output_pdf_path):
    # 1. Load Excel template
    wb = load_workbook(template_path)
    ws = wb.active

    # 2. Fill student info into specific cells
    ws["C5"] = student.user.get_full_name()  # Example: Name cell
    ws["C6"] = student.roll_number  # Example: Roll No cell
    ws["C7"] = student.current_class.name if student.current_class else ""

    # Fill marks (subject-wise)
    start_row = 12  # Adjust based on your Excel layout
    for idx, m in enumerate(marks):
        ws[f"B{start_row + idx}"] = m.subject.name
        ws[f"C{start_row + idx}"] = m.total_marks_obtained
        ws[f"D{start_row + idx}"] = m.pass_status

    temp_excel_path = "temp_filled.xlsx"
    wb.save(temp_excel_path)

    # 3. Convert filled Excel to PNG image
    img_path = "temp_result.png"
    excel2img.export_img(temp_excel_path, img_path, None, None)

    # 4. Place image in PDF
    c = canvas.Canvas(output_pdf_path, pagesize=A4)
    c.drawImage(img_path, 0, 0, width=A4[0], height=A4[1])
    c.showPage()
    c.save()

    # Cleanup
    os.remove(temp_excel_path)
    os.remove(img_path)
