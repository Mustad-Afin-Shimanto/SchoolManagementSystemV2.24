// SchoolManagementSystem/static/js/main.js
"use strict"; // Added for stricter parsing and error handling

document.addEventListener('DOMContentLoaded', function () {
    // NEW: Mobile Sidebar Toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');

    if (mobileMenuBtn && sidebar && sidebarOverlay) {
        mobileMenuBtn.addEventListener('click', () => {
            console.log("Mobile menu button clicked!"); // Added for debugging
            sidebar.classList.toggle('open');
            sidebarOverlay.classList.toggle('active');
        });

        sidebarOverlay.addEventListener('click', () => {
            sidebar.classList.remove('open');
            sidebarOverlay.classList.remove('active');
        });
    }

    // Notification Dropdown
    const notificationBtn = document.getElementById('notificationBtn');
    const notificationDropdown = document.getElementById('notificationDropdown');

    if (notificationBtn && notificationDropdown) {
        notificationBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent click from propagating to document
            notificationDropdown.classList.toggle('active');
            // Close other dropdowns if open
            const userMenuDropdown = document.getElementById('userMenuDropdown');
            if (userMenuDropdown) {
                userMenuDropdown.classList.remove('active');
            }
        });
    }

    // User Menu Dropdown
    const userMenuBtn = document.getElementById('userMenuBtn');
    const userMenuDropdown = document.getElementById('userMenuDropdown');

    if (userMenuBtn && userMenuDropdown) {
        userMenuBtn.addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent click from propagating to document
            userMenuDropdown.classList.toggle('active');
            // Close other dropdowns if open
            const notificationDropdown = document.getElementById('notificationDropdown');
            if (notificationDropdown) {
                notificationDropdown.classList.remove('active');
            }
        });
    }

    // Close dropdowns when clicking outside
    document.addEventListener('click', (e) => {
        if (notificationDropdown && notificationBtn && !notificationDropdown.contains(e.target) && !notificationBtn.contains(e.target)) {
            notificationDropdown.classList.remove('active');
        }
        if (userMenuDropdown && userMenuBtn && !userMenuDropdown.contains(e.target) && !userMenuBtn.contains(e.target)) {
            userMenuDropdown.classList.remove('active');
        }
    });

    // Send message (placeholder for actual AJAX submission)
    const sendMessageBtn = document.getElementById('sendMessage');
    if (sendMessageBtn) {
        sendMessageBtn.addEventListener('click', function () {
            const recipient = document.getElementById('recipient').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;

            if (!recipient || !subject || !message) {
                // Replaced alert with global modal
                if (typeof showGlobalModal === 'function') {
                    showGlobalModal('Missing Information', 'Please fill out all fields before sending the message.', () => { /* no action on confirm */
                    });
                } else {
                    console.warn('showGlobalModal function not found. Using console.log for missing fields.');
                }
                return;
            }

            // In a real application, you would send this data to your backend via AJAX
            console.log('Message sent:', {recipient, subject, message});
            // Replaced alert with global modal
            if (typeof showGlobalModal === 'function') {
                showGlobalModal('Message Sent', 'Your message has been sent successfully!', () => { /* no action on confirm */
                });
            } else {
                console.warn('showGlobalModal function not found. Using console.log for message sent.');
            }
            // Assuming closeModal is available globally from base.html
            if (typeof closeModal === 'function') {
                closeModal();
            } else {
                console.warn('closeModal function not found.');
            }
        });
    }

    // Dynamic Active Nav Link based on current path
    const navLinks = document.querySelectorAll('.nav-link');
    const currentPath = window.location.pathname;

    navLinks.forEach(link => {
        // Remove active class from all links first
        link.classList.remove('active');

        // Add active class if the link's href matches the current path
        // Or if the link's href is a base for the current path (e.g., /students/ for /students/add/)
        const linkHref = link.getAttribute('href');
        if (linkHref && currentPath.startsWith(linkHref)) {
            link.classList.add('active');
        }
    });
});
