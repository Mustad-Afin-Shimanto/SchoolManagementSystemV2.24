from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from .models import Subject, Topic, QuestionBank
import random


@api_view(["GET"])
@permission_classes([IsAuthenticated])
def get_subjects_topics(request):
    subjects = Subject.objects.all()
    data = [
        {
            "id": subj.id,
            "name": subj.name,
            "topics": [{"id": t.id, "name": t.name} for t in subj.topics.all()],
        }
        for subj in subjects
    ]
    return Response(data)


@api_view(["POST"])
@permission_classes([IsAuthenticated])
def generate_questions(request):
    subject_id = request.data.get("subject_id")
    topic_id = request.data.get("topic_id")
    question_types = request.data.get("question_types", [])
    count = int(request.data.get("count", 5))
    difficulty = request.data.get("difficulty", "medium")

    if not subject_id or not topic_id:
        return Response({"error": "Subject and Topic are required"}, status=400)

    # Step 1: Fetch from DB
    db_questions = list(
        QuestionBank.objects.filter(
            subject_id=subject_id, topic_id=topic_id, question_type__in=question_types
        )
    )
    random.shuffle(db_questions)

    selected_questions = []
    for q in db_questions[:count]:
        selected_questions.append(
            {
                "type": q.question_type,
                "text": q.text,
                "options": q.options,
                "correctAnswer": q.correct_answer,
                "points": 5,
                "debug_source": "DB",
            }
        )

    # Step 2: Fill missing with generated
    missing_count = count - len(selected_questions)
    if missing_count > 0:
        for i in range(missing_count):
            q_type = random.choice(question_types)
            selected_questions.append(
                {
                    "type": q_type,
                    "text": f"[Generated] {difficulty.title()} {q_type} question for topic {topic_id}",
                    "options": (
                        ["Option A", "Option B", "Option C", "Option D"]
                        if q_type == "mcq"
                        else None
                    ),
                    "correctAnswer": 0 if q_type == "mcq" else "True",
                    "points": 5,
                    "debug_source": "AI",
                }
            )

    random.shuffle(selected_questions)
    return Response(selected_questions)
