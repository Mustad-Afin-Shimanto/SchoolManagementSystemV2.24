from django.urls import path
from . import views

app_name = "questionbank"

urlpatterns = [
    path("generator/", views.question_generator_view, name="generator"),
    path("api/chapters/<int:subject_id>/", views.get_chapters, name="get_chapters"),
    path("api/topics/<int:chapter_id>/", views.get_topics, name="get_topics"),
    path("api/generate/", views.generate_questions_api, name="generate_questions_api"),
    path("bulk-upload/", views.bulk_question_upload, name="bulk_upload"),
    path("bulk-upload/", views.bulk_question_upload, name="bulk_upload"),
    path("generator/", views.generator_view, name="generator"),
    path("fetch-questions/", views.fetch_questions, name="fetch_questions"),
]
