from django.contrib import admin
from django import forms
from django.shortcuts import render, redirect
from django.urls import path
from .models import Subject, Chapter, Topic, Question
from .bulk_upload import handle_bulk_upload


class BulkUploadForm(forms.Form):
    file = forms.FileField()


@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("id", "name")
    search_fields = ("name",)


@admin.register(Chapter)
class ChapterAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "subject")
    search_fields = ("name",)
    list_filter = ("subject",)


@admin.register(Topic)
class TopicAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "chapter")
    search_fields = ("name",)
    list_filter = ("chapter__subject", "chapter")


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "text",
        "question_type",
        "topic",
        "class_obj",
        "division",
        "points",
    )
    search_fields = ("text",)
    list_filter = ("question_type", "topic__chapter__subject", "class_obj", "division")

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path(
                "bulk-upload/",
                self.admin_site.admin_view(self.bulk_upload_view),
                name="bulk_upload_questions",
            ),
        ]
        return custom_urls + urls

    def bulk_upload_view(self, request):
        if request.method == "POST":
            form = BulkUploadForm(request.POST, request.FILES)
            if form.is_valid():
                handle_bulk_upload(request.FILES["file"], request)
                return redirect("..")
        else:
            form = BulkUploadForm()
        return render(
            request,
            "admin/bulk_upload_questions.html",
            {"form": form, "title": "Bulk Upload Questions"},
        )
