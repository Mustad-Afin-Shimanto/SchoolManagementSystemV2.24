# questionbank/models.py
from django.db import models
from academic.models import Class, Division  # Using your existing models


class Subject(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name


class Chapter(models.Model):
    subject = models.ForeignKey(
        Subject, related_name="chapters", on_delete=models.CASCADE
    )
    name = models.CharField(max_length=255)

    class Meta:
        unique_together = ("subject", "name")

    def __str__(self):
        return f"{self.subject.name} - {self.name}"


class Topic(models.Model):
    chapter = models.ForeignKey(
        Chapter, related_name="topics", on_delete=models.CASCADE
    )
    name = models.CharField(max_length=255)

    class Meta:
        unique_together = ("chapter", "name")

    def __str__(self):
        return f"{self.chapter.name} - {self.name}"


class Question(models.Model):
    QUESTION_TYPES = (
        ("mcq", "Multiple Choice"),
        ("true_false", "True/False"),
        ("short_answer", "Short Answer"),
    )

    # Class & Division are required
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="questions"
    )
    division = models.ForeignKey(
        Division, on_delete=models.CASCADE, related_name="questions"
    )

    topic = models.ForeignKey(Topic, related_name="questions", on_delete=models.CASCADE)
    text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPES)
    options = models.JSONField(
        blank=True,
        null=True,
        help_text="Only for MCQs. Example: ['Option1', 'Option2']",
    )
    correct_answer = models.TextField(blank=True, null=True)
    points = models.PositiveIntegerField(default=1)

    def __str__(self):
        return f"{self.text[:50]}..."
