import pandas as pd
from django.core.exceptions import ObjectDoesNotExist
from .models import Subject, Chapter, Topic, Question, Class, Division


def handle_bulk_upload(file, request=None):
    errors = []
    success_count = 0

    # Determine file type and read into DataFrame
    if file.name.endswith(".xlsx"):
        df = pd.read_excel(file)
    elif file.name.endswith(".csv"):
        df = pd.read_csv(file)
    else:
        errors.append("Unsupported file format. Please upload a .xlsx or .csv file.")
        return errors, success_count

    # Ensure consistent column names
    expected_columns = [
        "Class",
        "Division",
        "Subject",
        "Chapter",
        "Topic",
        "Question",
        "Type",
        "Options",
        "Correct Answer",
        "Points",
    ]
    for col in expected_columns:
        if col not in df.columns:
            errors.append(f"Missing required column: {col}")
            return errors, success_count

    for _, row in df.iterrows():
        try:
            # Get Class (ignore session)
            class_obj = Class.objects.filter(name=str(row["Class"]).strip()).first()
            if not class_obj:
                errors.append(f"Class '{row['Class']}' not found.")
                continue

            # Get Division
            division_obj = Division.objects.filter(
                name=str(row["Division"]).strip()
            ).first()
            if not division_obj:
                errors.append(f"Division '{row['Division']}' not found.")
                continue

            # Get or create Subject
            subject_obj, _ = Subject.objects.get_or_create(
                name=str(row["Subject"]).strip()
            )

            # Get or create Chapter
            chapter_obj, _ = Chapter.objects.get_or_create(
                name=str(row["Chapter"]).strip(), subject=subject_obj
            )

            # Get or create Topic
            topic_obj, _ = Topic.objects.get_or_create(
                name=str(row["Topic"]).strip(), chapter=chapter_obj
            )

            # Question type mapping
            question_type = str(row["Type"]).strip()

            # Create Question
            q = Question(
                text=str(row["Question"]).strip(),
                question_type=question_type,
                topic=topic_obj,
                class_obj=class_obj,
                division=division_obj,
                options=(
                    str(row["Options"]).strip() if pd.notna(row["Options"]) else None
                ),
                correct_answer=str(row["Correct Answer"]).strip(),
                points=int(row["Points"]) if pd.notna(row["Points"]) else 0,
            )
            q.save()
            success_count += 1

        except ObjectDoesNotExist as e:
            errors.append(f"Missing related object: {e}")
        except Exception as e:
            errors.append(f"Error in row {dict(row)}: {str(e)}")

    return errors, success_count
