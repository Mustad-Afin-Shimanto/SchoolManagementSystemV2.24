from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Q
import random
from .models import Subject, Chapter, Topic, Question
from academic.models import Class, Division


def question_generator_view(request):
    """Render the Question Generator page"""
    subjects = Subject.objects.all()
    classes = Class.objects.all().order_by("name")
    divisions = Division.objects.all().order_by("name")
    return render(
        request,
        "questionbank/generator.html",
        {"subjects": subjects, "classes": classes, "divisions": divisions},
    )


def get_chapters(request, subject_id):
    chapters = Chapter.objects.filter(subject_id=subject_id).values("id", "name")
    return JsonResponse(list(chapters), safe=False)


def get_topics(request, chapter_id):
    topics = Topic.objects.filter(chapter_id=chapter_id).values("id", "name")
    return JsonResponse(list(topics), safe=False)


@csrf_exempt
def generate_questions_api(request):
    """
    Generate questions from DB based on filters sent from frontend.
    Required: class_id, division_id, topic_id, question_types, count, points
    """
    if request.method != "POST":
        return JsonResponse({"error": "POST method required"}, status=400)

    try:
        data = request.POST
        class_id = data.get("class_id")
        division_id = data.get("division_id")
        topic_id = data.get("topic_id")
        question_types = data.getlist("question_types[]")
        count = int(data.get("count", 5))
        points = int(data.get("points", 1))

        # Validate required fields
        if not class_id or not division_id or not topic_id:
            return JsonResponse(
                {"error": "Class, Division, and Topic are required"}, status=400
            )

        # Query questions
        queryset = Question.objects.filter(
            class_obj_id=class_id,
            division_id=division_id,
            topic_id=topic_id,
            question_type__in=question_types,
        )

        questions = list(queryset)
        if len(questions) > count:
            questions = random.sample(questions, count)

        results = []
        for q in questions:
            results.append(
                {
                    "id": q.id,
                    "text": q.text,
                    "type": q.question_type,
                    "options": q.options if q.options else [],
                    "correctAnswer": q.correct_answer,
                    "points": points,
                }
            )

        return JsonResponse({"questions": results}, safe=False)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
import csv
import openpyxl
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from .forms import BulkQuestionUploadForm
from .models import Class, Division, Subject, Chapter, Topic, Question
from users.models import CustomUser


def is_teacher_or_admin(user):
    return user.role in ["teacher", "admin"]


@login_required
@user_passes_test(is_teacher_or_admin)
def bulk_question_upload(request):
    if request.method == "POST":
        form = BulkQuestionUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file = request.FILES["file"]
            ext = file.name.split(".")[-1].lower()

            rows = []
            if ext in ["csv"]:
                decoded = file.read().decode("utf-8").splitlines()
                reader = csv.DictReader(decoded)
                rows = list(reader)
            elif ext in ["xlsx"]:
                wb = openpyxl.load_workbook(file)
                sheet = wb.active
                headers = [cell.value for cell in sheet[1]]
                for row in sheet.iter_rows(min_row=2, values_only=True):
                    rows.append(dict(zip(headers, row)))
            else:
                messages.error(request, "Unsupported file format. Use CSV or XLSX.")
                return redirect("questionbank:bulk_upload")

            created_count = 0
            for r in rows:
                try:
                    class_obj = Class.objects.get(name__iexact=r["Class"])
                    division = Division.objects.get(name__iexact=r["Division"])
                    subject, _ = Subject.objects.get_or_create(name=r["Subject"])
                    chapter, _ = Chapter.objects.get_or_create(
                        subject=subject, name=r["Chapter"]
                    )
                    topic, _ = Topic.objects.get_or_create(
                        chapter=chapter, name=r["Topic"]
                    )

                    options_list = []
                    if r.get("Options"):
                        options_list = [o.strip() for o in str(r["Options"]).split(",")]

                        Question.objects.create(
                          class_obj=class_obj,
                          division=division,
                          topic=topic,
                          text=r["Question"],
                          question_type=r["Type"],  # ✅ correct field name
                          options=options_list if options_list else None,
                            correct_answer=r.get("Correct Answer"),
                           points=int(r.get("Points", 1)),
)


                    created_count += 1
                except Exception as e:
                    messages.warning(request, f"Error in row {r}: {e}")

            messages.success(
                request, f"{created_count} questions uploaded successfully."
            )
            return redirect("questionbank:bulk_upload")
    else:
        form = BulkQuestionUploadForm()

    return render(request, "questionbank/bulk_upload.html", {"form": form})
from django.http import JsonResponse
from .models import Question


@login_required
@user_passes_test(is_teacher_or_admin)
def generator_view(request):
    classes = Class.objects.all()
    divisions = Division.objects.all()
    subjects = Subject.objects.all()
    return render(
        request,
        "questionbank/generator.html",
        {"classes": classes, "divisions": divisions, "subjects": subjects},
    )


@login_required
@user_passes_test(is_teacher_or_admin)
def fetch_questions(request):
    class_id = request.GET.get("class_id")
    division_id = request.GET.get("division_id")
    topic_id = request.GET.get("topic_id")

    questions = Question.objects.filter(
        class_obj_id=class_id, division_id=division_id, topic_id=topic_id
    ).values(
        "id", "text", "question_type", "options", "correct_answer", "points"
    )  # <-- fixed field name

    return JsonResponse(list(questions), safe=False)
