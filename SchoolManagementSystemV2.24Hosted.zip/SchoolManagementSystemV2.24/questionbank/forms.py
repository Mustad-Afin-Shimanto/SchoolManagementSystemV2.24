from django import forms


class BulkQuestionUploadForm(forms.Form):
    file = forms.FileField(
        label="Upload CSV/Excel",
        help_text="File must include: Class, Division, Subject, Chapter, Topic, Question, Type, Options (comma-separated), Correct Answer, Points",
    )
