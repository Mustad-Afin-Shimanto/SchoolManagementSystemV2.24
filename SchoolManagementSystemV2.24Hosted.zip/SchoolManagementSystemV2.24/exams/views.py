# SchoolManagementSystem/exams/views.py
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.shortcuts import render, redirect, get_object_or_404

# Import models from other apps for relationships
from users.models import Student, ParentProfile  # Import TeacherProfile for invigilator, etc.
# Import forms from current app
from .forms import ExamForm, QuestionForm, ExamScheduleForm
# Import models and forms from current app
from .models import Exam, Question, ExamSchedule


# --- Helper functions for role-based access (copied from users.views for self-containment) ---
def is_admin(user):
    return user.is_authenticated and user.role == 'admin'


def is_teacher(user):
    return user.is_authenticated and user.role == 'teacher'


def is_student(user):
    return user.is_authenticated and user.role == 'student'


def is_parent(user):
    return user.is_authenticated and user.role == 'parent'


# NEW: Add is_admin_or_teacher helper function
def is_admin_or_teacher(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher')


# --- Exam Schedule Views ---

@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_schedule_list_view(request):
    schedules = ExamSchedule.objects.all().select_related('exam', 'class_obj', 'subject', 'invigilator__user').order_by(
        'exam_date', 'start_time')
    paginator = Paginator(schedules, 10)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    context = {
        'page_title': 'Exam Schedules',
        'page_obj': page_obj,
    }
    return render(request, 'exams/exam_schedule_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_schedule_create_view(request):
    if request.method == 'POST':
        form = ExamScheduleForm(request.POST)
        if form.is_valid():
            exam_schedule = form.save(commit=False)
            exam_schedule.created_by = request.user
            exam_schedule.save()
            messages.success(request, 'Exam Schedule created successfully!')
            return redirect('exams:exam_schedule_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = ExamScheduleForm()
    context = {
        'page_title': 'Create Exam Schedule',
        'form': form,
        'action': 'create',
    }
    return render(request, 'exams/exam_schedule_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_schedule_update_view(request, pk):
    exam_schedule = get_object_or_404(ExamSchedule, pk=pk)
    if request.method == 'POST':
        form = ExamScheduleForm(request.POST, instance=exam_schedule)
        if form.is_valid():
            exam_schedule = form.save(commit=False)
            exam_schedule.updated_by = request.user
            exam_schedule.save()
            messages.success(request, 'Exam Schedule updated successfully!')
            return redirect('exams:exam_schedule_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = ExamScheduleForm(instance=exam_schedule)
    context = {
        'page_title': 'Update Exam Schedule',
        'form': form,
        'action': 'update',
    }
    return render(request, 'exams/exam_schedule_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_schedule_delete_view(request, pk):
    exam_schedule = get_object_or_404(ExamSchedule, pk=pk)
    if request.method == 'POST':
        try:
            exam_schedule.delete()
            messages.success(request, 'Exam Schedule deleted successfully!')
            return redirect('exams:exam_schedule_list')
        except Exception as e:
            messages.error(request, f"Error deleting exam schedule: {e}")
    context = {
        'page_title': 'Confirm Delete Exam Schedule',
        'object': exam_schedule,
        'confirm_message': f"Are you sure you want to delete the exam schedule for {exam_schedule.exam.name} - {exam_schedule.subject.name} on {exam_schedule.exam_date}?"
    }
    return render(request, 'exams/exam_schedule_confirm_delete.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def exam_list_view(request):
    exams = Exam.objects.all().select_related('academic_session', 'exam_type').order_by('-start_date', 'name')
    paginator = Paginator(exams, 10)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    context = {
        'page_title': 'Exams',
        'page_obj': page_obj,
    }
    return render(request, 'exams/exam_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_create_view(request):
    if request.method == 'POST':
        form = ExamForm(request.POST)
        if form.is_valid():
            exam = form.save(commit=False)
            exam.created_by = request.user
            exam.save()
            messages.success(request, 'Exam created successfully!')
            return redirect('exams:exam_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = ExamForm()
    context = {
        'page_title': 'Create Exam',
        'form': form,
        'action': 'create',
    }
    return render(request, 'exams/exam_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_update_view(request, pk):
    exam = get_object_or_404(Exam, pk=pk)
    if request.method == 'POST':
        form = ExamForm(request.POST, instance=exam)
        if form.is_valid():
            exam = form.save(commit=False)
            exam.updated_by = request.user
            exam.save()
            messages.success(request, 'Exam updated successfully!')
            return redirect('exams:exam_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = ExamForm(instance=exam)
    context = {
        'page_title': 'Update Exam',
        'form': form,
        'action': 'update',
    }
    return render(request, 'exams/exam_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def exam_delete_view(request, pk):
    exam = get_object_or_404(Exam, pk=pk)
    if request.method == 'POST':
        try:
            exam.delete()
            messages.success(request, 'Exam deleted successfully!')
            return redirect('exams:exam_list')
        except Exception as e:
            messages.error(request, f"Error deleting exam: {e}")
    context = {
        'page_title': 'Confirm Delete Exam',
        'object': exam,
        'confirm_message': f"Are you sure you want to delete the exam '{exam.name}'? This action cannot be undone."
    }
    return render(request, 'exams/exam_confirm_delete.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def exam_detail_view(request, pk):
    exam = get_object_or_404(Exam.objects.select_related('academic_session', 'exam_type'), pk=pk)
    # Get all schedules for this exam
    schedules = ExamSchedule.objects.filter(exam=exam).select_related('class_obj', 'subject',
                                                                      'invigilator__user').order_by('exam_date',
                                                                                                    'start_time')

    context = {
        'page_title': f'Exam Details: {exam.name}',
        'exam': exam,
        'schedules': schedules,
    }
    return render(request, 'exams/exam_detail.html', context)


# --- Question Views ---

@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def question_list_view(request):
    questions = Question.objects.all().select_related('exam', 'subject').order_by('exam__name', 'subject__name',
                                                                                  'question_type')
    paginator = Paginator(questions, 10)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)
    context = {
        'page_title': 'Questions',
        'page_obj': page_obj,
    }
    return render(request, 'exams/question_list.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def question_create_view(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.created_by = request.user
            question.save()
            messages.success(request, 'Question created successfully!')
            return redirect('exams:question_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = QuestionForm()
    context = {
        'page_title': 'Create Question',
        'form': form,
        'action': 'create',
    }
    return render(request, 'exams/question_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def question_update_view(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        form = QuestionForm(request.POST, instance=question)
        if form.is_valid():
            question = form.save(commit=False)
            question.updated_by = request.user
            question.save()
            messages.success(request, 'Question updated successfully!')
            return redirect('exams:question_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
    else:
        form = QuestionForm(instance=question)
    context = {
        'page_title': 'Update Question',
        'form': form,
        'action': 'update',
    }
    return render(request, 'exams/question_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def question_delete_view(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        try:
            question.delete()
            messages.success(request, 'Question deleted successfully!')
            return redirect('exams:question_list')
        except Exception as e:
            messages.error(request, f"Error deleting question: {e}")
    context = {
        'page_title': 'Confirm Delete Question',
        'object': question,
        'confirm_message': f"Are you sure you want to delete the question '{question.question_text[:50]}...'? This action cannot be undone."
    }
    return render(request, 'exams/question_confirm_delete.html', context)


@login_required
@user_passes_test(is_student, login_url='users:dashboard')
def student_exam_schedule_view(request):
    # Retrieve the student profile using the correct related_name
    student = request.user.student_profile

    if not student:
        messages.error(request, "Your student profile is incomplete. Please contact an administrator.")
        return redirect('users:dashboard')  # Redirect to dashboard or a more appropriate page

    current_class = student.current_class
    if not current_class:
        messages.warning(request, "You are not assigned to a class. Cannot display exam schedule.")
        # Render with empty schedules if no class is assigned
        return render(request, 'exams/student_exam_schedule.html', {'page_title': 'My Exam Schedule', 'schedules': []})

    # Filter schedules relevant to the student's class and current academic session
    schedules = ExamSchedule.objects.filter(
        class_obj=current_class,
        # Ensure schedules are for the academic session of the student's current class
        exam__academic_session=current_class.academic_session
    ).order_by('exam_date', 'start_time')  # Changed to exam_date

    context = {
        'page_title': 'My Exam Schedule',
        'student': student,
        'current_class': current_class,
        'schedules': schedules,
    }
    return render(request, 'exams/student_exam_schedule.html', context)


@login_required
@user_passes_test(is_parent, login_url='users:dashboard')
def parent_exam_schedule_view(request):
    parent_profile = get_object_or_404(ParentProfile, user=request.user)
    children = Student.objects.filter(parent=parent_profile).select_related('user', 'current_class__academic_session')

    if not children.exists():
        messages.info(request, "You have no registered children to view exam schedules for.")
        return redirect('users:dashboard')

    # Collect schedules for all children
    all_children_schedules = []
    for child in children:
        if child.current_class and child.current_class.academic_session:
            child_schedules = ExamSchedule.objects.filter(
                class_obj=child.current_class,
                exam__academic_session=child.current_class.academic_session
            ).order_by('exam_date', 'start_time').select_related('exam', 'class_obj', 'subject', 'invigilator__user')
            all_children_schedules.extend(list(child_schedules))

    # Remove duplicates and sort (if a schedule applies to multiple children, it might appear twice)
    # Convert to set for uniqueness, then back to list and sort
    unique_schedules = list({schedule.pk: schedule for schedule in all_children_schedules}.values())
    sorted_schedules = sorted(unique_schedules, key=lambda x: (x.exam_date, x.start_time))

    context = {
        'page_title': 'Children\'s Exam Schedules',
        'children': children,
        'schedules': sorted_schedules,
    }
    return render(request, 'exams/parent_exam_schedule.html', context)  # Assuming a new template for parent view
