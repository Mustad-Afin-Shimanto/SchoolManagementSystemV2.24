# SchoolManagementSystem/exams/forms.py
from django import forms

# Import models from other apps for foreign key querysets
from academic.models import AcademicSession, Class, Subject
from marks.models import ExamType  # Import ExamType for choices in forms
from users.models import TeacherProfile
from .models import Exam, Question, ExamSchedule

# Define the common Tailwind classes for most input types
COMMON_TAILWIND_CLASSES = 'block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
CHECKBOX_TAILWIND_CLASSES = 'h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500'


# Helper function to apply Tailwind classes consistently and add placeholders
def add_tailwind_classes(field, field_name=None):
    if hasattr(field.widget, 'attrs'):
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = CHECKBOX_TAILWIND_CLASSES
        else:
            current_classes = field.widget.attrs.get('class', '').split()
            for cls in COMMON_TAILWIND_CLASSES.split():
                if cls not in current_classes:
                    current_classes.append(cls)
            field.widget.attrs['class'] = ' '.join(current_classes)

            if field_name and not field.widget.attrs.get('placeholder'):
                # Exclude specific fields from placeholder generation if they don't need it
                if field_name not in ['start_date', 'end_date', 'start_time', 'end_time', 'notes', 'description',
                                      'correct_answer']:
                    placeholder_text = field_name.replace('_', ' ').title()
                    field.widget.attrs['placeholder'] = f"Enter {placeholder_text}"


# --- Exam Forms ---
class ExamForm(forms.ModelForm):
    # Custom field to control ExamType.is_final_exam
    # It's not directly mapped to Exam model, but will be handled in save()
    is_final_exam_checkbox = forms.BooleanField(
        label="Is Final Exam?",
        required=False,
        help_text="Check this if the selected Exam Type should be considered a final examination for grading.",
        widget=forms.CheckboxInput(attrs={'class': CHECKBOX_TAILWIND_CLASSES})  # Apply Tailwind classes directly
    )

    class Meta:
        model = Exam
        fields = ['name', 'academic_session', 'exam_type', 'description', 'start_date', 'end_date', 'is_active']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            # Apply Tailwind classes to all fields except our custom checkbox, which has it in its definition
            if field_name != 'is_final_exam_checkbox':
                add_tailwind_classes(field, field_name)

        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['exam_type'].queryset = ExamType.objects.all().order_by('name')
        self.fields['exam_type'].empty_label = "Select Exam Type"

        # Set initial value for the custom checkbox based on the selected ExamType's is_final_exam status
        if self.instance.pk and self.instance.exam_type:
            self.fields['is_final_exam_checkbox'].initial = self.instance.exam_type.is_final_exam
        elif 'initial' in kwargs and 'exam_type' in kwargs['initial'] and kwargs['initial']['exam_type']:
            # For create form if exam_type is pre-selected
            try:
                initial_exam_type = ExamType.objects.get(pk=kwargs['initial']['exam_type'])
                self.fields['is_final_exam_checkbox'].initial = initial_exam_type.is_final_exam
            except ExamType.DoesNotExist:
                pass  # Handle case where initial exam_type might not exist

    def save(self, commit=True):
        exam = super().save(commit=False)  # Save the Exam instance but don't commit yet

        # Handle the custom 'is_final_exam_checkbox' field
        selected_exam_type = self.cleaned_data.get('exam_type')
        is_final_exam_value = self.cleaned_data.get('is_final_exam_checkbox')

        if selected_exam_type:
            # Only update if the value has changed to avoid unnecessary database writes
            if selected_exam_type.is_final_exam != is_final_exam_value:
                selected_exam_type.is_final_exam = is_final_exam_value
                selected_exam_type.save(update_fields=['is_final_exam'])  # Explicitly save only this field

        if commit:
            exam.save()  # Now save the Exam instance
            self.save_m2m()  # Required for ManyToMany fields if any (though not directly relevant here, good practice)

        return exam


# --- Question Forms ---
class QuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = ['exam', 'subject', 'question_text', 'question_type', 'correct_answer', 'marks']
        widgets = {
            'question_text': forms.Textarea(attrs={'rows': 4}),
            'correct_answer': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['exam'].queryset = Exam.objects.all().order_by('-start_date', 'name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')


# --- Exam Schedule Forms ---
class ExamScheduleForm(forms.ModelForm):
    class Meta:
        model = ExamSchedule
        fields = ['exam', 'class_obj', 'subject', 'exam_date', 'start_time', 'end_time', 'room_number', 'total_marks',
                  'passing_marks', 'invigilator', 'notes']
        widgets = {
            'exam_date': forms.DateInput(attrs={'type': 'date'}),
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
            'notes': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['exam'].queryset = Exam.objects.all().order_by('-start_date', 'name')
        self.fields['class_obj'].queryset = Class.objects.all().order_by('name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')
        self.fields['invigilator'].queryset = TeacherProfile.objects.all().select_related('user').order_by(
            'user__first_name')
        self.fields['invigilator'].empty_label = "Select Invigilator (Optional)"



class ExamStructureMultiForm(forms.Form):
    exam_type = forms.ModelChoiceField(queryset=ExamType.objects.all())
    subjects = forms.ModelMultipleChoiceField(
        queryset=Subject.objects.all(), widget=forms.CheckboxSelectMultiple
    )
    total_max_marks = forms.IntegerField()
