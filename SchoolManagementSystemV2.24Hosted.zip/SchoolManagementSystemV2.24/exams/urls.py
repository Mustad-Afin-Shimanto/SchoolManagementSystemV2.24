# SchoolManagementSystem/exams/urls.py
from django.urls import path

from . import views

app_name = 'exams'  # ADD THIS LINE

urlpatterns = [
    # Exam URLs
    path('exams/', views.exam_list_view, name='exam_list'),
    path('exams/create/', views.exam_create_view, name='exam_create'),
    path('exams/<int:pk>/update/', views.exam_update_view, name='exam_update'),
    path('exams/<int:pk>/delete/', views.exam_delete_view, name='exam_delete'),
    path('exams/<int:pk>/detail/', views.exam_detail_view, name='exam_detail'),

    # Question URLs
    path('questions/', views.question_list_view, name='question_list'),
    path('questions/create/', views.question_create_view, name='question_create'),
    path('questions/<int:pk>/update/', views.question_update_view, name='question_update'),
    path('questions/<int:pk>/delete/', views.question_delete_view, name='question_delete'),

    # Exam Schedule URLs
    path('schedule/', views.exam_schedule_list_view, name='exam_schedule_list'),
    path('schedule/create/', views.exam_schedule_create_view, name='exam_schedule_create'),
    path('schedule/<int:pk>/update/', views.exam_schedule_update_view, name='exam_schedule_update'),
    path('schedule/<int:pk>/delete/', views.exam_schedule_delete_view, name='exam_schedule_delete'),

    # Student/Parent specific views
    path('my-schedule/', views.student_exam_schedule_view, name='student_exam_schedule'),
]
