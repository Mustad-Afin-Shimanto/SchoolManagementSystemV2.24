# SchoolManagementSystem/exams/models.py
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

# Import models from other apps to establish relationships
from academic.models import AcademicSession, Class, Subject
from users.models import CustomUser, TeacherProfile


# Removed direct import of ExamType to prevent circular import


class Exam(models.Model):
    """Represents a specific exam conducted in an academic session."""
    name = models.CharField(max_length=200, help_text="e.g., Midterm Exam, Final Exam, Quarterly Exam")
    academic_session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='exams')
    # NEW FIELD: Link to ExamType from the marks app - using string reference
    exam_type = models.ForeignKey('marks.ExamType', on_delete=models.SET_NULL, null=True, blank=True,
                                  related_name='exams_of_type')
    start_date = models.DateField()
    end_date = models.DateField()
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='created_exams')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='updated_exams')

    class Meta:
        verbose_name = "Exam"
        verbose_name_plural = "Exams"
        unique_together = ('academic_session', 'name', 'exam_type')
        ordering = ['-academic_session__start_date', 'name']

    def __str__(self):
        return f"{self.name} ({self.academic_session.name}) - {self.exam_type.name if self.exam_type else 'N/A'}"


class Question(models.Model):
    """Represents a question for an exam."""
    QUESTION_TYPE_CHOICES = [
        ('MCQ', 'Multiple Choice Question'),
        ('Short Answer', 'Short Answer'),
        ('Long Answer', 'Long Answer'),
        ('True/False', 'True/False'),
    ]
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='questions')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    question_type = models.CharField(max_length=20, choices=QUESTION_TYPE_CHOICES, default='Short Answer')
    correct_answer = models.TextField(blank=True, null=True,
                                      help_text="For MCQ/True-False, enter the correct option/answer. For others, can be a sample answer.")
    marks = models.DecimalField(max_digits=5, decimal_places=2, validators=[MinValueValidator(0)])
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='questions_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='questions_updated')

    class Meta:
        verbose_name = "Question"
        verbose_name_plural = "Questions"
        ordering = ['exam__name', 'subject__name', '-created_at']

    def __str__(self):
        return f"Q for {self.exam.name} - {self.subject.name}: {self.question_text[:50]}..."


class ExamSchedule(models.Model):
    """Defines the schedule for a specific subject within an exam."""
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='schedules')
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='exam_schedules')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='exam_schedules')
    exam_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    room_number = models.CharField(max_length=50, blank=True, null=True)
    total_marks = models.DecimalField(max_digits=5, decimal_places=2, default=100.00, validators=[MinValueValidator(0)])
    passing_marks = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True,
                                        validators=[MinValueValidator(0)])
    invigilator = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='invigilated_schedules')
    notes = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='exam_schedules_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='exam_schedules_updated')

    class Meta:
        verbose_name = "Exam Schedule"
        verbose_name_plural = "Exam Schedules"
        unique_together = ('exam', 'class_obj', 'subject', 'exam_date', 'start_time')
        ordering = ['exam_date', 'start_time', 'class_obj__name', 'subject__name']

    def __str__(self):
        return f"{self.exam.name} - {self.class_obj.name} - {self.subject.name} on {self.exam_date}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.start_time and self.end_time and self.start_time >= self.end_time:
            raise ValidationError('End time must be after start time.')
        if self.exam and self.exam_date:
            if not (
                    self.exam.start_date <= self.exam.end_date and self.exam.start_date <= self.exam_date <= self.exam.end_date):
                raise ValidationError(
                    f'Exam date must be within the range of the selected exam ({self.exam.start_date} to {self.exam.end_date}).')

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)

    def is_upcoming(self):
        now = timezone.now()
        exam_datetime_start = timezone.make_aware(timezone.datetime.combine(self.exam_date, self.start_time))
        return exam_datetime_start > now

    def is_ongoing(self):
        now = timezone.now()
        exam_datetime_start = timezone.make_aware(timezone.datetime.combine(self.exam_date, self.start_time))
        exam_datetime_end = timezone.make_aware(timezone.datetime.combine(self.exam_date, self.end_time))
        return exam_datetime_start <= now <= exam_datetime_end

    def is_past(self):
        now = timezone.now()
        exam_datetime_end = timezone.make_aware(timezone.datetime.combine(self.exam_date, self.end_time))
        return exam_datetime_end < now
