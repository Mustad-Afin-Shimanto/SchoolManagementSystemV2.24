# SchoolManagementSystem/exams/admin.py
from django.contrib import admin

from .models import Exam, Question, ExamSchedule


# Register your models here.

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ('name', 'academic_session', 'exam_type', 'start_date', 'end_date',
                    'is_active')  # Corrected 'is_final_exam' to 'is_active' and added 'exam_type'
    list_filter = ('academic_session', 'exam_type', 'is_active',
                   'start_date')  # Corrected 'is_final_exam' to 'is_active' and added 'exam_type'
    search_fields = ('name', 'description')
    raw_id_fields = ('academic_session', 'exam_type', 'created_by',
                     'updated_by')  # Added exam_type, created_by, updated_by
    date_hierarchy = 'start_date'
    ordering = ('-start_date', 'name')


@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ('question_text', 'exam', 'subject', 'question_type', 'marks')
    list_filter = ('exam__academic_session', 'exam', 'subject', 'question_type')
    search_fields = ('question_text', 'correct_answer', 'exam__name', 'subject__name')
    raw_id_fields = ('exam', 'subject', 'created_by', 'updated_by')
    ordering = ('exam__name', 'subject__name', '-created_at')


@admin.register(ExamSchedule)
class ExamScheduleAdmin(admin.ModelAdmin):
    list_display = ('exam', 'class_obj', 'subject', 'exam_date', 'start_time', 'end_time', 'room_number', 'total_marks',
                    'passing_marks', 'invigilator')
    list_filter = ('exam__academic_session', 'class_obj', 'subject', 'exam_date', 'invigilator')
    search_fields = ('exam__name', 'class_obj__name', 'subject__name', 'room_number',
                     'invigilator__user__username')  # Search by invigilator's username
    raw_id_fields = ('exam', 'class_obj', 'subject', 'invigilator', 'created_by', 'updated_by')
    date_hierarchy = 'exam_date'
    ordering = ('exam_date', 'start_time', 'class_obj__name')
