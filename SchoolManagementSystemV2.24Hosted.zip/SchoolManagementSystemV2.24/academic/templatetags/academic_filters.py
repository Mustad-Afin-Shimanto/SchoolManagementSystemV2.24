# SchoolManagementSystem/academic/templatetags/academic_filters.py
from django import template

from users.models import Student

register = template.Library()


@register.filter
def get_student_by_pk(pk):
    """
    Retrieves a Student object by its primary key.
    Returns None if the student is not found.
    """
    try:
        return Student.objects.get(pk=pk)
    except Student.DoesNotExist:
        return None
