# SchoolManagementSystem/academic/forms.py
from django import forms
from django.core.validators import MaxValueValidator  # Added import for MaxValueValidator
from django.utils import timezone  # Added import for timezone

# Import models from other apps for foreign key querysets
from users.models import Student, TeacherProfile
from .models import (
    AcademicSession, Class, Subject, ClassSubjectAssignment,
    AttendanceRecord, Fee, FeePayment, Syllabus, Notice, ClassRoutine,
    Assignment, AssignmentSubmission
)

# Define the common Tailwind classes for most input types
COMMON_TAILWIND_CLASSES = 'block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
CHECKBOX_TAILWIND_CLASSES = 'h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500'


# Helper function to apply Tailwind classes consistently and add placeholders
def add_tailwind_classes(field, field_name=None):
    if hasattr(field.widget, 'attrs'):
        if isinstance(field.widget, forms.CheckboxInput):
            field.widget.attrs['class'] = CHECKBOX_TAILWIND_CLASSES
        else:
            current_classes = field.widget.attrs.get('class', '').split()
            for cls in COMMON_TAILWIND_CLASSES.split():
                if cls not in current_classes:
                    current_classes.append(cls)
            field.widget.attrs['class'] = ' '.join(current_classes)

            # Add placeholder if not already set and field_name is provided
            if field_name and not field.widget.attrs.get('placeholder'):
                placeholder_text = f"Enter {field_name.replace('_', ' ').title()}"
                field.widget.attrs['placeholder'] = placeholder_text
    # For ChoiceField, remove placeholder as it often conflicts with empty_label or select behavior.
    if isinstance(field, forms.ChoiceField):
        field.widget.attrs.pop('placeholder', None)


# --- Academic Session Forms ---
class AcademicSessionForm(forms.ModelForm):
    class Meta:
        model = AcademicSession
        fields = ['name', 'start_date', 'end_date', 'is_current']
        widgets = {
            'start_date': forms.DateInput(attrs={'type': 'date'}),
            'end_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


# --- Class Forms ---
class ClassForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['name', 'academic_session', 'class_teacher', 'description']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['class_teacher'].queryset = TeacherProfile.objects.all().select_related('user').order_by(
            'user__first_name')
        self.fields['class_teacher'].empty_label = "Select Class Teacher (Optional)"


# --- Subject Forms ---
class SubjectForm(forms.ModelForm):
    class Meta:
        model = Subject
        fields = ['name', 'code', 'description']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


# --- Class Subject Assignment Forms ---
class ClassSubjectAssignmentForm(forms.ModelForm):
    class Meta:
        model = ClassSubjectAssignment
        fields = ['academic_session', 'class_obj', 'subject', 'teacher', 'is_homeroom_teacher']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['class_obj'].queryset = Class.objects.all().order_by('name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')
        self.fields['teacher'].queryset = TeacherProfile.objects.all().select_related('user').order_by(
            'user__first_name')


# --- Class Routine Forms ---
class ClassRoutineForm(forms.ModelForm):
    class Meta:
        model = ClassRoutine
        fields = ['academic_session', 'class_obj', 'subject', 'teacher', 'day_of_week', 'start_time', 'end_time',
                  'room_number']
        widgets = {
            'start_time': forms.TimeInput(attrs={'type': 'time'}),
            'end_time': forms.TimeInput(attrs={'type': 'time'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['class_obj'].queryset = Class.objects.all().order_by('name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')
        self.fields['teacher'].queryset = TeacherProfile.objects.all().select_related('user').order_by(
            'user__first_name')


# --- Attendance Forms ---
class AttendanceSelectionForm(forms.Form):
    academic_session = forms.ModelChoiceField(
        queryset=AcademicSession.objects.all().order_by('-start_date'),
        label="Academic Session",
        empty_label="Select Academic Session"
    )
    class_obj = forms.ModelChoiceField(
        queryset=Class.objects.all().order_by('name'),
        label="Class",
        empty_label="Select Class"
    )
    subject = forms.ModelChoiceField(
        queryset=Subject.objects.all().order_by('name'),
        label="Subject",
        empty_label="Select Subject"
    )
    date = forms.DateField(
        label="Date",
        widget=forms.DateInput(attrs={'type': 'date'}),
        initial=timezone.now().date()
    )

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)  # Get the user from kwargs
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)

        # Filter academic session queryset based on user role (if teacher)
        if self.user and self.user.role == 'teacher':
            teacher_profile = self.user.teacher_profile
            # Get sessions where the teacher is assigned to any class-subject
            assigned_session_ids = ClassSubjectAssignment.objects.filter(
                teacher=teacher_profile
            ).values_list('academic_session__id', flat=True).distinct()
            self.fields['academic_session'].queryset = AcademicSession.objects.filter(
                id__in=assigned_session_ids
            ).order_by('-start_date')

        # The class_obj and subject querysets will be dynamically updated via AJAX
        # So, we initially set them to empty or a default queryset.
        # However, if form is re-rendered with errors, we need to ensure their initial values are set.
        if self.data.get('academic_session'):
            try:
                selected_session = AcademicSession.objects.get(pk=self.data['academic_session'])
                classes_for_session = Class.objects.filter(academic_session=selected_session).order_by('name')

                # Corrected: Use 'class_assignments' related_name for Subject
                subjects_for_session = Subject.objects.filter(
                    class_assignments__academic_session=selected_session
                ).distinct().order_by('name')

                if self.user and self.user.role == 'teacher':
                    teacher_profile = self.user.teacher_profile
                    assigned_classes_ids = ClassSubjectAssignment.objects.filter(
                        academic_session=selected_session,
                        teacher=teacher_profile
                    ).values_list('class_obj__id', flat=True).distinct()
                    classes_for_session = classes_for_session.filter(id__in=assigned_classes_ids)

                    assigned_subjects_ids = ClassSubjectAssignment.objects.filter(
                        academic_session=selected_session,
                        teacher=teacher_profile
                    ).values_list('subject__id', flat=True).distinct()
                    subjects_for_session = subjects_for_session.filter(id__in=assigned_subjects_ids)

                self.fields['class_obj'].queryset = classes_for_session
                self.fields['subject'].queryset = subjects_for_session
            except AcademicSession.DoesNotExist:
                self.fields['class_obj'].queryset = Class.objects.none()
                self.fields['subject'].queryset = Subject.objects.none()
        else:
            self.fields['class_obj'].queryset = Class.objects.none()
            self.fields['subject'].queryset = Subject.objects.none()


class AttendanceRecordForm(forms.ModelForm):
    class Meta:
        model = AttendanceRecord
        # Ensure all fields are listed here, including the hidden ones
        fields = ['student', 'academic_session', 'class_obj', 'subject', 'date', 'is_present', 'remarks']
        widgets = {
            # Django automatically creates a ModelChoiceField for 'student'.
            # We just need to apply the HiddenInput widget.
            'student': forms.HiddenInput(),
            'academic_session': forms.HiddenInput(),
            'class_obj': forms.HiddenInput(),
            'subject': forms.HiddenInput(),
            'date': forms.HiddenInput(),
            'remarks': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        # Pop custom context arguments passed from the view's form_kwargs
        # These are used to provide context but should NOT be used to set initial values
        # for fields that are already part of Meta.fields and are receiving initial data
        # from the formset itself.
        self.academic_session_instance = kwargs.pop('academic_session', None)
        self.class_obj_instance = kwargs.pop('class_obj', None)
        self.subject_instance = kwargs.pop('subject', None)
        self.date_instance = kwargs.pop('date', None)

        super().__init__(*args, **kwargs)

        # Apply Tailwind classes
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)

        # Ensure student field is not required for the formset to handle it.
        # The formset will manage which forms are "required" based on `empty_permitted` etc.
        # This is important for hidden fields in formsets.
        if 'student' in self.fields:
            self.fields['student'].required = False

        # Removed the lines below. The initial values for these fields are expected
        # to come from the 'initial' data passed to the formset in the view,
        # not from the form's __init__ method.
        # if not self.instance or not self.instance.pk:
        #     if self.academic_session_instance:
        #         self.fields['academic_session'].initial = self.academic_session_instance
        #     if self.class_obj_instance:
        #         self.fields['class_obj'].initial = self.class_obj_instance
        #     if self.subject_instance:
        #         self.fields['subject'].initial = self.subject_instance
        #     if self.date_instance:
        #         self.fields['date'].initial = self.date_instance

    def clean(self):
        cleaned_data = super().clean()

        student = cleaned_data.get('student')
        academic_session = cleaned_data.get('academic_session')
        class_obj = cleaned_data.get('class_obj')
        subject = cleaned_data.get('subject')
        attendance_date = cleaned_data.get('date')

        # If the form is empty, skip validation. This is for cases where formset might have empty forms.
        # For our specific use case (pre-populating students with extra=0), this should ideally not be hit
        # for forms that are expected to represent a student.
        if not any([student, academic_session, class_obj, subject, attendance_date, cleaned_data.get('is_present')]):
            return cleaned_data

        # If essential data is missing, add errors.
        if not student:
            self.add_error('student', "Student is required.")
        if not academic_session:
            self.add_error('academic_session', "Academic session is required.")
        if not class_obj:
            self.add_error('class_obj', "Class is required.")
        if not subject:
            self.add_error('subject', "Subject is required.")
        if not attendance_date:
            self.add_error('date', "Date is required.")

        # Only proceed with uniqueness check if all required fields are present
        if student and academic_session and class_obj and subject and attendance_date:
            # If this is an existing instance (update), exclude itself from the uniqueness check
            if self.instance and self.instance.pk:
                existing_records = AttendanceRecord.objects.filter(
                    academic_session=academic_session,
                    class_obj=class_obj,
                    subject=subject,
                    date=attendance_date,
                    student=student
                ).exclude(pk=self.instance.pk)
            else:
                existing_records = AttendanceRecord.objects.filter(
                    academic_session=academic_session,
                    class_obj=class_obj,
                    subject=subject,
                    date=attendance_date,
                    student=student
                )

            if existing_records.exists():
                print(
                    f"ERROR: Duplicate attendance record found during clean for student {student.user.get_full_name()}")
                raise forms.ValidationError(
                    f"Attendance record for {student.user.get_full_name()} on {attendance_date} "
                    f"for {subject.name} in {class_obj.name} already exists."
                )
        return cleaned_data

from django import forms
from .models import Section


class SectionForm(forms.ModelForm):
    class Meta:
        model = Section
        fields = ["name", "class_obj", "division", "description"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "class_obj": forms.Select(attrs={"class": "form-control"}),
            "division": forms.Select(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }

from django import forms
from .models import Division

class DivisionForm(forms.ModelForm):
    class Meta:
        model = Division
        fields = ["name", "description"]
        widgets = {
            "name": forms.TextInput(attrs={"class": "form-control"}),
            "description": forms.Textarea(attrs={"class": "form-control", "rows": 3}),
        }


# --- Fee Forms ---
class FeeForm(forms.ModelForm):
    class Meta:
        model = Fee
        fields = fields = [
            "name",
            "description",
            "academic_session",
            "class_obj",
            "fee_category",  
            "amount",
            "due_date",
        ]
        widgets = {
            'due_date': forms.DateInput(attrs={'type': 'date'})  # ✅ Calendar picker
        }
        # Removed widgets for 'due_date' as it's no longer in the model

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')


# --- Fee Payment Forms ---
class FeePaymentForm(forms.ModelForm):
    class Meta:
        model = FeePayment
        fields = ['student', 'fee', 'amount_paid', 'payment_date', 'payment_method', 'remarks']
        widgets = {
            'payment_date': forms.DateInput(attrs={'type': 'date'}),
            'remarks': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['student'].queryset = Student.objects.all().select_related('user').order_by('user__first_name')
        self.fields['fee'].queryset = Fee.objects.all().order_by('-academic_session__start_date', 'name')


# --- Syllabus Forms ---
class SyllabusForm(forms.ModelForm):
    class Meta:
        model = Syllabus
        fields = ['academic_session', 'class_obj', 'subject', 'title', 'description', 'file']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['class_obj'].queryset = Class.objects.all().order_by('name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')


# --- Notice Forms ---
class NoticeForm(forms.ModelForm):
    class Meta:
        model = Notice
        fields = ['title', 'content', 'published_date', 'target_roles', 'target_classes']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 5}),
            'published_date': forms.DateInput(attrs={'type': 'date'}),
            'target_roles': forms.CheckboxSelectMultiple(),
            'target_classes': forms.CheckboxSelectMultiple(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['target_classes'].queryset = Class.objects.all().order_by('name')


# --- Assignment Forms ---
class AssignmentForm(forms.ModelForm):
    class Meta:
        model = Assignment
        fields = ['academic_session', 'class_obj', 'subject', 'title', 'description', 'due_date', 'max_marks',
                  'file', 'assigned_by']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
            'due_date': forms.DateInput(attrs={'type': 'date'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        self.fields['academic_session'].queryset = AcademicSession.objects.all().order_by('-start_date')
        self.fields['class_obj'].queryset = Class.objects.all().order_by('name')
        self.fields['subject'].queryset = Subject.objects.all().order_by('name')
        self.fields['assigned_by'].queryset = TeacherProfile.objects.all().select_related('user').order_by(
            'user__first_name')
        self.fields['assigned_by'].empty_label = "Select Assigning Teacher (Optional)"


# --- Assignment Submission Forms ---
class AssignmentSubmissionForm(forms.ModelForm):
    class Meta:
        model = AssignmentSubmission
        fields = ['submission_text', 'submission_file']
        widgets = {
            'submission_text': forms.Textarea(attrs={'rows': 5}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)


class AssignmentGradeForm(forms.ModelForm):
    class Meta:
        model = AssignmentSubmission
        fields = ['marks_obtained', 'feedback']
        widgets = {
            'feedback': forms.Textarea(attrs={'rows': 5}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            add_tailwind_classes(field, field_name)
        # Add a custom validator for marks_obtained to ensure it doesn't exceed assignment's max_marks
        if self.instance and self.instance.assignment:
            max_marks = self.instance.assignment.max_marks
            self.fields['marks_obtained'].validators.append(MaxValueValidator(max_marks))
            self.fields['marks_obtained'].help_text = f"Max marks for this assignment: {max_marks}"
