from django.contrib import admin
from .models import (
    AcademicSession,
    Class,
    Subject,
    ClassSubjectAssignment,
    AttendanceRecord,
    Fee,
    FeePayment,
    Syllabus,
    Notice,
    ClassRoutine,
    Assignment,
    AssignmentSubmission,
    StudentFeeCategory,
    FeeStructure,
    Division,
    Section# ✅ added missing import
)


# AcademicSession
@admin.register(AcademicSession)
class AcademicSessionAdmin(admin.ModelAdmin):
    list_display = ("name", "start_date", "end_date", "is_current")
    list_filter = ("is_current", "start_date")
    search_fields = ("name",)
    ordering = ("-start_date",)


# Class
@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ("name", "academic_session", "class_teacher")
    list_filter = ("academic_session", "class_teacher")
    search_fields = ("name",)
    raw_id_fields = ("academic_session", "class_teacher")
    ordering = ("name",)


# Subject
@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")
    ordering = ("name",)


# ClassSubjectAssignment
@admin.register(ClassSubjectAssignment)
class ClassSubjectAssignmentAdmin(admin.ModelAdmin):
    list_display = (
        "academic_session",
        "class_obj",
        "subject",
        "teacher",
        "is_homeroom_teacher",
    )
    list_filter = (
        "academic_session",
        "class_obj",
        "subject",
        "teacher",
        "is_homeroom_teacher",
    )
    search_fields = (
        "academic_session__name",
        "class_obj__name",
        "subject__name",
        "teacher__user__first_name",
        "teacher__user__last_name",
    )
    raw_id_fields = ("academic_session", "class_obj", "subject", "teacher")
    ordering = ("academic_session__name", "class_obj__name", "subject__name")


# ClassRoutine
@admin.register(ClassRoutine)
class ClassRoutineAdmin(admin.ModelAdmin):
    list_display = (
        "academic_session",
        "class_obj",
        "subject",
        "teacher",
        "day_of_week",
        "start_time",
        "end_time",
        "room_number",
    )
    list_filter = ("academic_session", "class_obj", "subject", "teacher", "day_of_week")
    search_fields = (
        "class_obj__name",
        "subject__name",
        "teacher__user__first_name",
        "teacher__user__last_name",
        "room_number",
    )
    raw_id_fields = ("academic_session", "class_obj", "subject", "teacher")
    ordering = ("class_obj__name", "day_of_week", "start_time")


# AttendanceRecord
@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = (
        "academic_session",
        "class_obj",
        "subject",
        "student",
        "date",
        "is_present",
        "teacher",
    )
    list_filter = (
        "academic_session",
        "class_obj",
        "subject",
        "is_present",
        "date",
        "teacher",
    )
    search_fields = (
        "student__user__first_name",
        "student__user__last_name",
        "class_obj__name",
        "subject__name",
        "remarks",
    )
    raw_id_fields = ("academic_session", "class_obj", "subject", "student", "teacher")
    date_hierarchy = "date"
    ordering = (
        "-date",
        "class_obj__name",
        "subject__name",
        "student__user__first_name",
    )


# StudentFeeCategory
@admin.register(StudentFeeCategory)
class StudentFeeCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "description")
    search_fields = ("name",)


# Fee
@admin.register(Fee)
class FeeAdmin(admin.ModelAdmin):
    list_display = ("academic_session", "name")
    list_filter = ("academic_session",)
    search_fields = ("name",)
    raw_id_fields = ("academic_session",)
    ordering = ("academic_session__name", "name")


# FeeStructure
@admin.register(FeeStructure)
class FeeStructureAdmin(admin.ModelAdmin):
    list_display = ("fee", "category", "amount")
    list_filter = ("fee", "category")
    search_fields = ("fee__name", "category__name")


# FeePayment
@admin.register(FeePayment)
class FeePaymentAdmin(admin.ModelAdmin):
    list_display = ("student", "fee", "amount_paid", "payment_date", "payment_method")
    list_filter = ("fee__academic_session", "fee", "payment_date", "payment_method")
    search_fields = (
        "student__user__first_name",
        "student__user__last_name",
        "fee__name",
        "transaction_id",
    )
    raw_id_fields = ("student", "fee")
    date_hierarchy = "payment_date"
    ordering = ("-payment_date", "student__user__last_name")


# Syllabus
@admin.register(Syllabus)
class SyllabusAdmin(admin.ModelAdmin):
    list_display = ("academic_session", "class_obj", "subject", "title", "uploaded_at")
    list_filter = ("academic_session", "class_obj", "subject")
    search_fields = ("title", "description", "subject__name")
    raw_id_fields = (
        "academic_session",
        "class_obj",
        "subject",
        "uploaded_by",
        "updated_by",
    )
    date_hierarchy = "uploaded_at"
    ordering = (
        "-uploaded_at",
        "academic_session__name",
        "class_obj__name",
        "subject__name",
    )


# Notice
@admin.register(Notice)
class NoticeAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "published_date",
        "expiry_date",
        "is_active",
        "target_roles",
        "created_by",
    )
    list_filter = ("is_active", "target_roles", "published_date", "expiry_date")
    search_fields = ("title", "content")
    raw_id_fields = ("created_by", "updated_by")
    date_hierarchy = "published_date"
    ordering = ("-published_date",)
    filter_horizontal = ("target_classes",)


# Assignment
@admin.register(Assignment)
class AssignmentAdmin(admin.ModelAdmin):
    list_display = (
        "title",
        "class_obj",
        "subject",
        "due_date",
        "max_marks",
        "assigned_by",
        "created_at",
    )
    list_filter = (
        "academic_session",
        "class_obj",
        "subject",
        "due_date",
        "assigned_by",
    )
    search_fields = ("title", "description", "class_obj__name", "subject__name")
    raw_id_fields = ("academic_session", "class_obj", "subject", "assigned_by")
    date_hierarchy = "due_date"
    ordering = ("-due_date", "class_obj__name", "subject__name")


# AssignmentSubmission
@admin.register(AssignmentSubmission)
class AssignmentSubmissionAdmin(admin.ModelAdmin):
    list_display = (
        "assignment",
        "student",
        "submission_date",
        "marks_obtained",
        "graded_by",
    )
    list_filter = (
        "assignment__class_obj__academic_session",
        "assignment__class_obj",
        "assignment__subject",
        "submission_date",
        "graded_by",
    )
    search_fields = (
        "assignment__title",
        "student__user__first_name",
        "student__user__last_name",
        "feedback",
    )
    raw_id_fields = ("assignment", "student", "graded_by")
    date_hierarchy = "submission_date"
    ordering = ("-submission_date", "assignment__title", "student__user__first_name")


@admin.register(Division)
class DivisionAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)
    ordering = ("name",)


@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ("name", "class_obj", "division")
    list_filter = ("class_obj", "division")
    search_fields = ("name", "class_obj__name", "division__name")
    ordering = ("class_obj__name", "name")
