# SchoolManagementSystem/academic/views.py
from datetime import date  # Added date import
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db import transaction  # Added import for transaction
from django.db.models import Q, Count  # Added F for annotations
from django.forms import modelformset_factory  # Added import for modelformset_factory
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST  # For AJAX view and POST-only views

# Import models from other apps (for foreign keys or related logic)
from users.models import Student, TeacherProfile
# Import forms from current app
from .forms import (
    AcademicSessionForm,
    ClassForm,
    SubjectForm,
    ClassSubjectAssignmentForm,
    AttendanceRecordForm,
    FeeForm,
    FeePaymentForm,
    SyllabusForm,
    NoticeForm,
    ClassRoutineForm,
    AssignmentForm,
    AssignmentSubmissionForm,
    AssignmentGradeForm,
    AttendanceSelectionForm,
    DivisionForm,  # Ensure AttendanceSelectionForm is imported
)

# Import models from current app
from .models import (
    AcademicSession,
    Class,
    Subject,
    ClassSubjectAssignment,
    AttendanceRecord,
    Fee,
    FeePayment,
    Syllabus,
    Notice,
    ClassRoutine,
    Assignment,
    AssignmentSubmission,
    Division,
)


# --- Helper functions for role-based access ---
def is_admin(user):
    return user.is_authenticated and user.role == 'admin'


def is_teacher(user):
    return user.is_authenticated and user.role == 'teacher'


def is_student(user):
    return user.is_authenticated and user.role == 'student'


def is_parent(user):
    return user.is_authenticated and user.role == 'parent'


def is_admin_or_teacher(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher')


def is_admin_or_student(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'student')


def is_admin_or_parent(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'parent')


def is_admin_or_teacher_or_student(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher' or user.role == 'student')


def is_admin_or_teacher_or_parent(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'teacher' or user.role == 'parent')


# Define is_admin_or_parent_or_student locally to resolve the unresolved reference
def is_admin_or_parent_or_student(user):
    return user.is_authenticated and (user.role == 'admin' or user.role == 'parent' or user.role == 'student')


# --- Academic Session Views ---
@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def academic_session_list(request):
    sessions = AcademicSession.objects.all().order_by('-start_date')

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(sessions, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Academic Sessions',
        'page_obj': page_obj,
    }
    return render(request, 'academic/academic_session_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def academic_session_create(request):
    if request.method == 'POST':
        form = AcademicSessionForm(request.POST)
        if form.is_valid():
            # Ensure only one academic session is marked as current
            if form.cleaned_data['is_current']:
                AcademicSession.objects.update(is_current=False)
            session = form.save(commit=False)
            session.created_by = request.user
            session.save()
            messages.success(request, 'Academic session created successfully!')
            return redirect('academic:academic_session_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AcademicSessionForm()
    context = {
        'page_title': 'Create Academic Session',
        'form': form,
    }
    return render(request, 'academic/academic_session_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def academic_session_update(request, pk):
    session = get_object_or_404(AcademicSession, pk=pk)
    if request.method == 'POST':
        form = AcademicSessionForm(request.POST, instance=session)
        if form.is_valid():
            # Ensure only one academic session is marked as current
            if form.cleaned_data['is_current']:
                AcademicSession.objects.exclude(pk=pk).update(is_current=False)
            session = form.save(commit=False)
            session.updated_by = request.user
            session.save()
            messages.success(request, 'Academic session updated successfully!')
            return redirect('academic:academic_session_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AcademicSessionForm(instance=session)
    context = {
        'page_title': 'Update Academic Session',
        'form': form,
    }
    return render(request, 'academic/academic_session_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def academic_session_delete(request, pk):
    session = get_object_or_404(AcademicSession, pk=pk)
    try:
        session.delete()
        messages.success(request, 'Academic session deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting academic session: {e}')
    return redirect('academic:academic_session_list')


# --- Class Views ---
@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def class_list(request):
    classes = Class.objects.all().select_related('academic_session', 'class_teacher__user').order_by(
        'academic_session__name', 'name')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter classes where the teacher is assigned to teach any subject in the current session
        assigned_class_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile,
            academic_session__is_current=True
        ).values_list('class_obj__id', flat=True).distinct()
        classes = classes.filter(id__in=assigned_class_ids)

    query = request.GET.get('q')
    if query:
        classes = classes.filter(Q(name__icontains=query) | Q(description__icontains=query))

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(classes, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Classes',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/class_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_create(request):
    if request.method == 'POST':
        form = ClassForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class created successfully!')
            return redirect('academic:class_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassForm()
    context = {
        'page_title': 'Create Class',
        'form': form,
    }
    return render(request, 'academic/class_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_update(request, pk):
    class_obj = get_object_or_404(Class, pk=pk)
    if request.method == 'POST':
        form = ClassForm(request.POST, instance=class_obj)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class updated successfully!')
            return redirect('academic:class_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassForm(instance=class_obj)
    context = {
        'page_title': 'Update Class',
        'form': form,
    }
    return render(request, 'academic/class_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_delete(request, pk):
    """
    Handles displaying the class deletion confirmation page (GET)
    and processing the class deletion (POST).
    """
    class_obj = get_object_or_404(Class, pk=pk)
    if request.method == 'POST':
        try:
            class_obj.delete()
            messages.success(request, 'Class deleted successfully!')
        except Exception as e:
            messages.error(request, f'Error deleting class: {e}')
        return redirect('academic:class_list')
    else:  # GET request: display confirmation page
        context = {
            'page_title': 'Confirm Delete Class',
            'class_obj': class_obj,
            'confirm_message': f"Are you sure you want to delete the class: {class_obj.name}? This action cannot be undone and will also affect related records (e.g., students, assignments, routines)."
        }
        return render(request, 'academic/class_confirm_delete.html', context)


# --- Subject Views ---
@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def subject_list(request):
    subjects = Subject.objects.all().order_by('name')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter subjects where the teacher is assigned to teach in the current session
        assigned_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile,
            academic_session__is_current=True
        ).values_list('subject__id', flat=True).distinct()
        subjects = subjects.filter(id__in=assigned_subject_ids)

    query = request.GET.get('q')
    if query:
        subjects = subjects.filter(
            Q(name__icontains=query) | Q(code__icontains=query) | Q(description__icontains=query))

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(subjects, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Subjects',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/subject_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def subject_create(request):
    if request.method == 'POST':
        form = SubjectForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Subject created successfully!')
            return redirect('academic:subject_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = SubjectForm()
    context = {
        'page_title': 'Create Subject',
        'form': form,
    }
    return render(request, 'academic/subject_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def subject_update(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    if request.method == 'POST':
        form = SubjectForm(request.POST, instance=subject)
        if form.is_valid():
            form.save()
            messages.success(request, 'Subject updated successfully!')
            return redirect('academic:subject_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = SubjectForm(instance=subject)
    context = {
        'page_title': 'Update Subject',
        'form': form,
    }
    return render(request, 'academic/subject_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def subject_delete(request, pk):
    subject = get_object_or_404(Subject, pk=pk)
    try:
        subject.delete()
        messages.success(request, 'Subject deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting subject: {e}')
    return redirect('academic:subject_list')


# --- Class Subject Assignment Views ---
@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def class_subject_assignment_list(request):
    assignments = ClassSubjectAssignment.objects.all().select_related('academic_session', 'class_obj', 'subject',
                                                                      'teacher__user').order_by(
        '-academic_session__start_date', 'class_obj__name', 'subject__name')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        assignments = assignments.filter(teacher=teacher_profile)

    # Get filter parameters from GET request
    query = request.GET.get('q')
    academic_session_id = request.GET.get('academic_session')
    class_obj_id = request.GET.get('class_obj')
    subject_id = request.GET.get('subject')
    teacher_id = request.GET.get('teacher')

    # Apply search filter
    if query:
        assignments = assignments.filter(
            Q(academic_session__name__icontains=query) |
            Q(class_obj__name__icontains=query) |
            Q(subject__name__icontains=query) |
            Q(teacher__user__first_name__icontains=query) |
            Q(teacher__user__last_name__icontains=query)
        )

    # Apply specific filters
    if academic_session_id:
        assignments = assignments.filter(academic_session__pk=academic_session_id)
    if class_obj_id:
        assignments = assignments.filter(class_obj__pk=class_obj_id)
    if subject_id:
        assignments = assignments.filter(subject__pk=subject_id)
    if teacher_id:
        assignments = assignments.filter(teacher__pk=teacher_id)

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(assignments, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    # Pass filter options to the template
    academic_sessions = AcademicSession.objects.all().order_by('name')
    classes = Class.objects.all().order_by('name')
    subjects = Subject.objects.all().order_by('name')
    teachers = TeacherProfile.objects.all().select_related('user').order_by('user__first_name')

    context = {
        'page_title': 'Class Subject Assignments',
        'page_obj': page_obj,
        'query': query,
        'academic_sessions': academic_sessions,
        'classes': classes,
        'subjects': subjects,
        'teachers': teachers,
    }
    return render(request, 'academic/class_subject_assignment_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_subject_assignment_create(request):
    if request.method == 'POST':
        form = ClassSubjectAssignmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class-Subject Assignment created successfully!')
            return redirect('academic:class_subject_assignment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassSubjectAssignmentForm()
    context = {
        'page_title': 'Create Class-Subject Assignment',
        'form': form,
    }
    return render(request, 'academic/class_subject_assignment_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_subject_assignment_update(request, pk):
    assignment = get_object_or_404(ClassSubjectAssignment, pk=pk)
    if request.method == 'POST':
        form = ClassSubjectAssignmentForm(request.POST, instance=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class-Subject Assignment updated successfully!')
            return redirect('academic:class_subject_assignment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassSubjectAssignmentForm(instance=assignment)
    context = {
        'page_title': 'Update Class-Subject Assignment',
        'form': form,
    }
    return render(request, 'academic/class_subject_assignment_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def class_subject_assignment_delete(request, pk):
    assignment = get_object_or_404(ClassSubjectAssignment, pk=pk)
    try:
        assignment.delete()
        messages.success(request, 'Class-Subject Assignment deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting assignment: {e}')
    return redirect('academic:class_subject_assignment_list')


# --- Class Routine Views ---
@login_required
@user_passes_test(is_admin_or_teacher_or_student, login_url='users:dashboard')
def class_routine_list(request):
    routines = ClassRoutine.objects.all().select_related('academic_session', 'class_obj', 'subject',
                                                         'teacher__user').order_by('-academic_session__name',
                                                                                   'class_obj__name', 'day_of_week',
                                                                                   'start_time')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        routines = routines.filter(teacher=teacher_profile)
    elif is_student(request.user):
        student_profile = request.user.student_profile
        if student_profile and student_profile.current_class:
            routines = routines.filter(class_obj=student_profile.current_class)
        else:
            routines = routines.none()  # No routines if student has no class

    query = request.GET.get('q')
    if query:
        routines = routines.filter(
            Q(academic_session__name__icontains=query) |
            Q(class_obj__name__icontains=query) |
            Q(subject__name__icontains=query) |
            Q(teacher__user__first_name__icontains=query) |
            Q(teacher__user__last_name__icontains=query) |
            Q(room_number__icontains=query)
        )

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(routines, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Class Routines',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/class_routine_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_routine_create(request):
    if request.method == 'POST':
        form = ClassRoutineForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class Routine created successfully!')
            return redirect('academic:class_routine_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassRoutineForm()
    context = {
        'page_title': 'Create Class Routine',
        'form': form,
    }
    return render(request, 'academic/class_routine_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def class_routine_update(request, pk):
    routine = get_object_or_404(ClassRoutine, pk=pk)
    if request.method == 'POST':
        form = ClassRoutineForm(request.POST, instance=routine)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class Routine updated successfully!')
            return redirect('academic:class_routine_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = ClassRoutineForm(instance=routine)
    context = {
        'page_title': 'Update Class Routine',
        'form': form,
    }
    return render(request, 'academic/class_routine_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def class_routine_delete(request, pk):
    routine = get_object_or_404(ClassRoutine, pk=pk)
    try:
        routine.delete()
        messages.success(request, 'Class Routine deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting routine: {e}')
    return redirect('academic:class_routine_list')


# --- Attendance Views ---
@login_required
@user_passes_test(lambda u: is_admin(u) or is_teacher(u) or is_student(u) or is_parent(u), login_url='users:dashboard')
def attendance_list(request):
    # Base queryset for attendance records
    attendance_records = AttendanceRecord.objects.all().select_related(
        'academic_session', 'class_obj', 'subject', 'student__user', 'teacher__user'
    )

    # Apply role-based filtering
    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter records for subjects/classes assigned to this teacher
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        # Create a Q object to filter by (class_obj, subject) pairs
        q_objects = Q()
        for class_id, subject_id in assigned_class_subject_ids:
            q_objects |= (Q(class_obj__id=class_id) & Q(subject__id=subject_id))

        attendance_records = attendance_records.filter(q_objects)

    elif is_student(request.user):
        student_profile = request.user.student_profile
        attendance_records = attendance_records.filter(student=student_profile)
    elif is_parent(request.user):
        parent_profile = request.user.parent_profile
        children_students = Student.objects.filter(parent=parent_profile)
        attendance_records = attendance_records.filter(student__in=children_students)

    # Initialize filter form with GET data for persistence
    filter_form = AttendanceSelectionForm(request.GET)

    # Apply filters from the form if valid
    if filter_form.is_valid():
        academic_session_filter = filter_form.cleaned_data.get('academic_session')
        class_obj_filter = filter_form.cleaned_data.get('class_obj')
        subject_filter = filter_form.cleaned_data.get('subject')
        date_filter = filter_form.cleaned_data.get('date')

        if academic_session_filter:
            attendance_records = attendance_records.filter(academic_session=academic_session_filter)
        if class_obj_filter:
            attendance_records = attendance_records.filter(class_obj=class_obj_filter)
        if subject_filter:
            attendance_records = attendance_records.filter(subject=subject_filter)
        if date_filter:
            attendance_records = attendance_records.filter(date=date_filter)

    # Handle search query for student name or remarks
    query = request.GET.get('q')
    if query:
        attendance_records = attendance_records.filter(
            Q(student__user__first_name__icontains=query) |
            Q(student__user__last_name__icontains=query) |
            Q(remarks__icontains=query)
        )

    # Group by academic session, class, subject, and date, and annotate counts
    # This aggregation is for the 'grouped' view in the table
    grouped_attendance = attendance_records.values(
        'academic_session', 'academic_session__name',
        'class_obj', 'class_obj__name',
        'subject', 'subject__name',
        'date'
    ).annotate(
        present_count=Count('student', filter=Q(is_present=True)),
        absent_count=Count('student', filter=Q(is_present=False)),
        total_recorded_students=Count('student', distinct=True)  # Count students who have a record
    ).order_by('-date', 'academic_session__name', 'class_obj__name', 'subject__name')

    # Calculate percentages and total enrolled students for display
    for record in grouped_attendance:
        # Get the actual count of students enrolled in this class and academic session
        # This is more accurate than just total_recorded_students for percentage calculation
        total_enrolled_students = Student.objects.filter(
            current_class=record['class_obj'],
            academic_session=record['academic_session']
        ).count()
        record['total_enrolled_students'] = total_enrolled_students if total_enrolled_students > 0 else record[
            'total_recorded_students']

        # Use total_recorded_students for percentage calculation to reflect actual attendance taken
        total_for_percentage = record['present_count'] + record['absent_count']
        record['present_percentage'] = (
                    record['present_count'] / total_for_percentage * 100) if total_for_percentage > 0 else 0
        record['absent_percentage'] = (
                    record['absent_count'] / total_for_percentage * 100) if total_for_percentage > 0 else 0
        record['academic_session__pk'] = record['academic_session']  # Pass PK for URL reversal
        record['class_obj__pk'] = record['class_obj']  # Pass PK for URL reversal
        record['subject__pk'] = record['subject']  # Pass PK for URL reversal

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(grouped_attendance, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Attendance Records',
        'page_obj': page_obj,
        'filter_form': filter_form,  # Pass the filter form to the template
        'query': query,
    }
    return render(request, 'academic/attendance_record_list.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def attendance_selection_view(request):
    if request.method == 'POST':
        form = AttendanceSelectionForm(request.POST, user=request.user)  # Pass the user to the form
        if form.is_valid():
            academic_session = form.cleaned_data['academic_session']
            class_obj = form.cleaned_data['class_obj']
            subject = form.cleaned_data['subject']
            date = form.cleaned_data['date']

            # Check if attendance records already exist for this combination
            existing_records_count = AttendanceRecord.objects.filter(
                academic_session=academic_session,
                class_obj=class_obj,
                subject=subject,
                date=date
            ).count()

            if existing_records_count > 0:
                messages.warning(request,
                                 "Attendance for this session, class, subject, and date is already recorded. You are now in update mode.")
            else:
                messages.info(request, "Recording new attendance for this session, class, subject, and date.")

            # Redirect to the attendance entry/update form with selected criteria
            return redirect('academic:attendance_entry_form',
                            academic_session_pk=academic_session.pk,
                            class_pk=class_obj.pk,
                            subject_pk=subject.pk,
                            year=date.year,
                            month=date.month,
                            day=date.day)
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AttendanceSelectionForm(user=request.user)  # Pass the user to the form

    context = {
        'page_title': 'Select Attendance Criteria',
        'form': form,
    }
    return render(request, 'academic/attendance_selection_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def attendance_entry_form_view(request, academic_session_pk, class_pk, subject_pk, year, month, day):
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    attendance_date = date(year, month, day)

    # Get all students in the selected class for the academic session
    students_in_class = Student.objects.filter(
        current_class=class_obj,
        academic_session=academic_session
    ).order_by('roll_number', 'user__first_name')

    # Fetch existing attendance records for this class, subject, date, and session
    existing_attendance = AttendanceRecord.objects.filter(
        academic_session=academic_session,
        class_obj=class_obj,
        subject=subject,
        date=attendance_date
    ).select_related('student__user')

    initial_data = []
    # Use a set for quick lookup of students who already have an attendance record
    students_with_existing_attendance = set(record.student.pk for record in existing_attendance)

    # Populate initial_data with existing records
    for record in existing_attendance:
        initial_data.append({
            'id': record.pk,  # Pass the ID for existing records
            'student': record.student.pk,
            'is_present': record.is_present,
            'remarks': record.remarks,
            'academic_session': academic_session.pk,
            'class_obj': class_obj.pk,
            'subject': subject.pk,
            'date': attendance_date,
        })

    # Add forms for students who don't have an attendance record yet for this date
    # These will be new forms created by the formset.
    for student in students_in_class:
        if student.pk not in students_with_existing_attendance:
            initial_data.append({
                'student': student.pk,
                'is_present': True,  # Default to present for new entries
                'remarks': '',
                'academic_session': academic_session.pk,
                'class_obj': class_obj.pk,
                'subject': subject.pk,
                'date': attendance_date,
            })

    # Sort initial_data by student roll number for consistent display
    initial_data.sort(key=lambda x: Student.objects.get(pk=x['student']).roll_number if Student.objects.get(
        pk=x['student']).roll_number else float('inf'))

    # Determine the number of extra forms needed.
    # If there are no existing records, we need `students_in_class.count()` extra forms.
    # If there are existing records, `extra` can be 0, as existing forms are handled by `queryset`.
    # The `initial` data will then populate these new forms.
    num_extra_forms = students_in_class.count() - existing_attendance.count()
    if num_extra_forms < 0:  # Should not happen if logic is correct, but safeguard
        num_extra_forms = 0

    AttendanceFormSet = modelformset_factory(
        AttendanceRecord,
        form=AttendanceRecordForm,
        extra=num_extra_forms,  # Set extra to create forms for new students
        fields=['student', 'academic_session', 'class_obj', 'subject', 'date', 'is_present', 'remarks'],
        # Use can_delete=True if you want to allow deleting attendance records from the formset
        # widgets={'student': forms.HiddenInput()} # This is already in AttendanceRecordForm.Meta.widgets
    )

    if request.method == 'POST':
        formset = AttendanceFormSet(
            request.POST,
            queryset=existing_attendance,  # Pass queryset for existing instances
            form_kwargs={
                'academic_session': academic_session,  # Pass instances to form_kwargs
                'class_obj': class_obj,
                'subject': subject,
                'date': attendance_date,
            }
        )
        if formset.is_valid():
            with transaction.atomic():
                for form in formset:
                    # Only save if the form has changed or is a new entry
                    # The formset handles deletion, so we don't need to explicitly check for DELETE
                    if form.has_changed() or not form.instance.pk:
                        attendance_record = form.save(commit=False)
                        attendance_record.teacher = request.user.teacher_profile if is_teacher(
                            request.user) else None  # Assign teacher if applicable
                        attendance_record.save()
            messages.success(request, 'Attendance saved successfully!')
            return redirect('academic:attendance_list')  # Redirect to the list view after saving
        else:
            for form in formset:
                for field, errors in form.errors.items():
                    for error in errors:
                        # Check if form.instance.student exists before accessing its attributes
                        student_name = form.instance.student.user.get_full_name() if form.instance and form.instance.student else "Unknown Student"
                        messages.error(request, f"Student {student_name} - {field.replace('_', ' ').title()}: {error}")
                if form.non_field_errors():
                    student_name = form.instance.student.user.get_full_name() if form.instance and form.instance.student else "Unknown Student"
                    for error in form.non_field_errors():
                        messages.error(request, f"Student {student_name} - Error: {error}")
            messages.error(request, "Please correct the errors below.")
    else:
        formset = AttendanceFormSet(
            queryset=existing_attendance,  # Pass queryset for existing instances
            initial=initial_data,  # Pass initial data for new and existing students
            form_kwargs={
                'academic_session': academic_session,  # Pass instances to form_kwargs
                'class_obj': class_obj,
                'subject': subject,
                'date': attendance_date,
            }
        )

    context = {
        'page_title': 'Record/Update Attendance',
        'academic_session': academic_session,
        'class_obj': class_obj,
        'subject': subject,
        'attendance_date': attendance_date,
        'formset': formset,
    }
    return render(request, 'academic/attendance_entry_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def attendance_record_update_view(request, pk):
    attendance_record = get_object_or_404(AttendanceRecord, pk=pk)

    if request.method == 'POST':
        form = AttendanceRecordForm(request.POST, instance=attendance_record,
                                    academic_session=attendance_record.academic_session,
                                    class_obj=attendance_record.class_obj,
                                    subject=attendance_record.subject)  # Pass context for queryset filtering
        if form.is_valid():
            form.save()
            messages.success(request, 'Attendance record updated successfully!')
            return redirect('academic:attendance_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AttendanceRecordForm(instance=attendance_record,
                                    academic_session=attendance_record.academic_session,
                                    class_obj=attendance_record.class_obj,
                                    subject=attendance_record.subject)  # Pass context for queryset filtering

    context = {
        'page_title': 'Update Attendance Record',
        'form': form,
        'attendance_record': attendance_record,
    }
    return render(request, 'academic/attendance_record_update.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
@require_POST
def attendance_record_delete_view(request, pk):
    attendance_record = get_object_or_404(AttendanceRecord, pk=pk)
    try:
        attendance_record.delete()
        messages.success(request, 'Attendance record deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting attendance record: {e}')
    return redirect('academic:attendance_list')


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
@require_POST
def attendance_group_delete_view(request, academic_session_pk, class_pk, subject_pk, year, month, day):
    """
    Deletes all attendance records for a specific academic session, class, subject, and date.
    """
    academic_session = get_object_or_404(AcademicSession, pk=academic_session_pk)
    class_obj = get_object_or_404(Class, pk=class_pk)
    subject = get_object_or_404(Subject, pk=subject_pk)
    attendance_date = date(year, month, day)

    try:
        with transaction.atomic():
            records_to_delete = AttendanceRecord.objects.filter(
                academic_session=academic_session,
                class_obj=class_obj,
                subject=subject,
                date=attendance_date
            )
            count = records_to_delete.count()
            records_to_delete.delete()
            messages.success(request,
                             f'{count} attendance records for {class_obj.name} ({subject.name}) on {attendance_date.strftime("%B %d, %Y")} deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting attendance group: {e}')

    return redirect('academic:attendance_list')


# --- Syllabus Views ---
@login_required
@user_passes_test(lambda u: is_admin(u) or is_teacher(u) or is_student(u), login_url='users:dashboard')
def syllabus_list_view(request):
    syllabuses = Syllabus.objects.all().select_related('academic_session', 'class_obj', 'subject').order_by(
        '-academic_session__start_date', 'class_obj__name', 'subject__name')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter syllabuses for subjects/classes assigned to this teacher
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        q_objects = Q()
        for class_id, subject_id in assigned_class_subject_ids:
            q_objects |= (Q(class_obj__id=class_id) & Q(subject__id=subject_id))
        syllabuses = syllabuses.filter(q_objects).distinct()
    elif is_student(request.user):
        student_profile = request.user.student_profile
        if student_profile and student_profile.current_class and student_profile.academic_session:
            syllabuses = syllabuses.filter(
                class_obj=student_profile.current_class,
                academic_session=student_profile.academic_session
            )
        else:
            syllabuses = syllabuses.none()  # No syllabuses if student has no class/session

    query = request.GET.get('q')
    if query:
        syllabuses = syllabuses.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query) |
            Q(academic_session__name__icontains=query) |
            Q(class_obj__name__icontains=query) |
            Q(subject__name__icontains=query)
        )

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(syllabuses, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Syllabuses',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/syllabus_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def syllabus_create_view(request):
    if request.method == 'POST':
        form = SyllabusForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Syllabus created successfully!')
            return redirect('academic:syllabus_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = SyllabusForm()
    context = {
        'page_title': 'Create Syllabus',
        'form': form,
    }
    return render(request, 'academic/syllabus_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def syllabus_update_view(request, pk):
    syllabus = get_object_or_404(Syllabus, pk=pk)
    if request.method == 'POST':
        form = SyllabusForm(request.POST, request.FILES, instance=syllabus)
        if form.is_valid():
            form.save()
            messages.success(request, 'Syllabus updated successfully!')
            return redirect('academic:syllabus_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = SyllabusForm(instance=syllabus)
    context = {
        'page_title': 'Update Syllabus',
        'form': form,
    }
    return render(request, 'academic/syllabus_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def syllabus_delete_view(request, pk):
    syllabus = get_object_or_404(Syllabus, pk=pk)
    try:
        syllabus.delete()
        messages.success(request, 'Syllabus deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting syllabus: {e}')
    return redirect('academic:syllabus_list')


# --- Notice Views ---
@login_required
@user_passes_test(lambda u: is_admin(u) or is_teacher(u) or is_student(u) or is_parent(u), login_url='users:dashboard')
def notice_list_view(request):
    notices = Notice.objects.filter(is_active=True).order_by('-published_date')

    # Filter notices based on user role and assigned classes (if applicable)
    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        assigned_class_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile,
            academic_session__is_current=True
        ).values_list('class_obj__id', flat=True).distinct()
        notices = notices.filter(
            Q(target_roles='all') |
            Q(target_roles='teacher') |
            Q(target_classes__id__in=assigned_class_ids)
        ).distinct()
    elif is_student(request.user):
        student_profile = request.user.student_profile
        if student_profile and student_profile.current_class:
            notices = notices.filter(
                Q(target_roles='all') |
                Q(target_roles='student') |
                Q(target_classes=student_profile.current_class)
            ).distinct()
        else:
            notices = notices.none()  # No notices if student has no class
    elif is_parent(request.user):
        parent_profile = request.user.parent_profile
        children_classes_ids = Student.objects.filter(parent=parent_profile).values_list('current_class__id',
                                                                                         flat=True).distinct()
        notices = notices.filter(
            Q(target_roles='all') |
            Q(target_roles='parent') |
            Q(target_classes__id__in=children_classes_ids)
        ).distinct()
    elif not is_admin(request.user):  # If not admin, and not any other specific role, show nothing
        notices = notices.none()

    query = request.GET.get('q')
    if query:
        notices = notices.filter(Q(title__icontains=query) | Q(content__icontains=query))

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(notices, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Notices',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/notice_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def notice_create_view(request):
    if request.method == 'POST':
        form = NoticeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Notice created successfully!')
            return redirect('academic:notice_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = NoticeForm()
    context = {
        'page_title': 'Create Notice',
        'form': form,
    }
    return render(request, 'academic/notice_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def notice_update_view(request, pk):
    notice = get_object_or_404(Notice, pk=pk)
    if request.method == 'POST':
        form = NoticeForm(request.POST, instance=notice)
        if form.is_valid():
            form.save()
            messages.success(request, 'Notice updated successfully!')
            return redirect('academic:notice_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = NoticeForm(instance=notice)
    context = {
        'page_title': 'Update Notice',
        'form': form,
    }
    return render(request, 'academic/notice_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def notice_delete_view(request, pk):
    notice = get_object_or_404(Notice, pk=pk)
    try:
        notice.delete()
        messages.success(request, 'Notice deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting notice: {e}')
    return redirect('academic:notice_list')


# --- Fee Views ---
@login_required
@user_passes_test(is_admin_or_parent, login_url='users:dashboard')
def fee_list_view(request):
    fees = Fee.objects.all().select_related('academic_session').order_by('-academic_session__start_date', 'name')

    if is_parent(request.user):
        parent_profile = request.user.parent_profile
        # Filter fees applicable to their children's academic sessions
        children_academic_session_ids = Student.objects.filter(
            parent=parent_profile
        ).values_list('academic_session__id', flat=True).distinct()
        fees = fees.filter(academic_session__id__in=children_academic_session_ids)

    query = request.GET.get('q')
    if query:
        fees = fees.filter(
            Q(name__icontains=query) |
            Q(description__icontains=query) |
            Q(academic_session__name__icontains=query)
        )

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(fees, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Fees',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/fee_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def fee_create_view(request):
    if request.method == 'POST':
        form = FeeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fee created successfully!')
            return redirect('academic:fee_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = FeeForm()
    context = {
        'page_title': 'Create Fee',
        'form': form,
    }
    return render(request, 'academic/fee_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def fee_update_view(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    if request.method == 'POST':
        form = FeeForm(request.POST, instance=fee)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fee updated successfully!')
            return redirect('academic:fee_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = FeeForm(instance=fee)
    context = {
        'page_title': 'Update Fee',
        'form': form,
    }
    return render(request, 'academic/fee_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def fee_delete_view(request, pk):
    fee = get_object_or_404(Fee, pk=pk)
    try:
        fee.delete()
        messages.success(request, 'Fee deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting fee: {e}')
    return redirect('academic:fee_list')


# --- Fee Payment Views ---
@login_required
@user_passes_test(is_admin_or_parent_or_student, login_url='users:dashboard')
def fee_payment_list_view(request):
    payments = FeePayment.objects.all().select_related('student__user', 'fee__academic_session').order_by(
        '-payment_date', 'student__user__last_name')

    if is_student(request.user):
        student_profile = request.user.student_profile
        payments = payments.filter(student=student_profile)
    elif is_parent(request.user):
        parent_profile = request.user.parent_profile
        children_students = Student.objects.filter(parent=parent_profile)
        payments = payments.filter(student__in=children_students)

    query = request.GET.get('q')
    if query:
        payments = payments.filter(
            Q(student__user__first_name__icontains=query) |
            Q(student__user__last_name__icontains=query) |
            Q(fee__name__icontains=query) |
            Q(transaction_id__icontains=query) |
            Q(remarks__icontains=query)
        )

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(payments, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Fee Payments',
        'page_obj': page_obj,
        'query': query,
    }
    return render(request, 'academic/fee_payment_list.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def fee_payment_create_view(request):
    if request.method == 'POST':
        form = FeePaymentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fee payment recorded successfully!')
            return redirect('academic:fee_payment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = FeePaymentForm()
    context = {
        'page_title': 'Record Fee Payment',
        'form': form,
    }
    return render(request, 'academic/fee_payment_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
def fee_payment_update_view(request, pk):
    payment = get_object_or_404(FeePayment, pk=pk)
    if request.method == 'POST':
        form = FeePaymentForm(request.POST, instance=payment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Fee payment updated successfully!')
            return redirect('academic:fee_payment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = FeePaymentForm(instance=payment)
    context = {
        'page_title': 'Update Fee Payment',
        'form': form,
    }
    return render(request, 'academic/fee_payment_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def fee_payment_delete_view(request, pk):
    payment = get_object_or_404(FeePayment, pk=pk)
    try:
        payment.delete()
        messages.success(request, 'Fee payment deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting payment: {e}')
    return redirect('academic:fee_payment_list')


# --- Assignment Views ---
@login_required
@user_passes_test(lambda u: is_admin(u) or is_teacher(u) or is_student(u), login_url='users:dashboard')
def assignment_list_view(request):
    assignments = Assignment.objects.all().select_related('academic_session', 'class_obj', 'subject',
                                                          'assigned_by__user').order_by('-due_date', 'class_obj__name',
                                                                                        'subject__name')

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter assignments created by the teacher or assigned to their classes/subjects
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        q_assignments = Q()
        for class_id, subject_id in assigned_class_subject_ids:
            q_assignments |= (Q(class_obj__id=class_id) & Q(subject__id=subject_id))
        assignments = assignments.filter(q_assignments).distinct()

    elif is_student(request.user):
        student_profile = request.user.student_profile
        if student_profile and student_profile.current_class and student_profile.academic_session:
            assignments = assignments.filter(
                class_obj=student_profile.current_class,
                academic_session=student_profile.academic_session
            )
        else:
            assignments = assignments.none()  # No assignments if student has no class/session

    # Get filter parameters from GET request
    query = request.GET.get('q')
    class_obj_id = request.GET.get('class_obj')
    subject_id = request.GET.get('subject')

    # Apply search filter
    if query:
        assignments = assignments.filter(
            Q(title__icontains=query) |
            Q(description__icontains=query) |
            Q(class_obj__name__icontains=query) |
            Q(subject__name__icontains=query) |
            Q(assigned_by__user__first_name__icontains=query) |
            Q(assigned_by__user__last_name__icontains=query)
        )

    # Apply specific filters
    if class_obj_id:
        assignments = assignments.filter(class_obj__pk=class_obj_id)
    if subject_id:
        assignments = assignments.filter(subject__pk=subject_id)

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(assignments, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    # Pass filter options to the template
    classes = Class.objects.all().order_by('name')
    subjects = Subject.objects.all().order_by('name')

    context = {
        'page_title': 'Assignments',
        'page_obj': page_obj,
        'query': query,
        'classes': classes,
        'subjects': subjects,
    }
    return render(request, 'academic/assignment_list.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def assignment_create_view(request):
    if request.method == 'POST':
        form = AssignmentForm(request.POST, request.FILES)
        if form.is_valid():
            assignment = form.save(commit=False)
            if is_teacher(request.user) and not assignment.assigned_by:
                assignment.assigned_by = request.user.teacher_profile
            assignment.save()
            messages.success(request, 'Assignment created successfully!')
            return redirect('academic:assignment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AssignmentForm()
        # Pre-fill assigned_by for teachers
        if is_teacher(request.user):
            form.fields['assigned_by'].initial = request.user.teacher_profile

    context = {
        'page_title': 'Create Assignment',
        'form': form,
    }
    return render(request, 'academic/assignment_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def assignment_update_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    # Teachers can only update assignments they created or are assigned to their classes/subjects
    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        if not (assignment.assigned_by == teacher_profile or
                (assignment.class_obj.pk, assignment.subject.pk) in assigned_class_subject_ids):
            messages.error(request, "You are not authorized to update this assignment.")
            return redirect('academic:assignment_list')

    if request.method == 'POST':
        form = AssignmentForm(request.POST, request.FILES, instance=assignment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Assignment updated successfully!')
            return redirect('academic:assignment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AssignmentForm(instance=assignment)
    context = {
        'page_title': 'Update Assignment',
        'form': form,
    }
    return render(request, 'academic/assignment_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
@require_POST
def assignment_delete_view(request, pk):
    assignment = get_object_or_404(Assignment, pk=pk)
    # Teachers can only delete assignments they created or are assigned to their classes/subjects
    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        if not (assignment.assigned_by == teacher_profile or
                (assignment.class_obj.pk, assignment.subject.pk) in assigned_class_subject_ids):
            messages.error(request, "You are not authorized to delete this assignment.")
            return redirect('academic:assignment_list')
    try:
        assignment.delete()
        messages.success(request, 'Assignment deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting assignment: {e}')
    return redirect('academic:assignment_list')


# --- Assignment Submission Views ---
@login_required
@user_passes_test(lambda u: is_admin(u) or is_teacher(u) or is_student(u), login_url='users:dashboard')
def assignment_submission_list_view(request, assignment_pk=None):  # Added assignment_pk for filtering
    submissions = AssignmentSubmission.objects.all().select_related('assignment__title', 'student__user',
                                                                    'graded_by__user').order_by('-submission_date')

    # If assignment_pk is provided, filter submissions for that specific assignment
    assignment = None
    if assignment_pk:
        assignment = get_object_or_404(Assignment, pk=assignment_pk)
        submissions = submissions.filter(assignment=assignment)

    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        # Filter submissions for assignments in classes/subjects assigned to this teacher
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        q_objects = Q()
        for class_id, subject_id in assigned_class_subject_ids:
            q_objects |= (Q(assignment__class_obj__id=class_id) & Q(assignment__subject__id=subject_id))
        submissions = submissions.filter(q_objects).distinct()

    elif is_student(request.user):
        student_profile = request.user.student_profile
        submissions = submissions.filter(student=student_profile)

    # Get filter parameters from GET request
    query = request.GET.get('q')

    # Apply search filter
    if query:
        submissions = submissions.filter(
            Q(assignment__title__icontains=query) |
            Q(student__user__first_name__icontains=query) |
            Q(student__user__last_name__icontains=query) |
            Q(student__roll_number__icontains=query) |  # Added roll number search
            Q(submission_text__icontains=query) |
            Q(feedback__icontains=query)
        )

    # Pagination logic
    page_size = request.GET.get('page_size', 10)  # Get page_size from request, default to 10
    paginator = Paginator(submissions, page_size)
    page_number = request.GET.get('page')
    try:
        page_obj = paginator.page(page_number)
    except PageNotAnInteger:
        page_obj = paginator.page(1)
    except EmptyPage:
        page_obj = paginator.page(paginator.num_pages)

    context = {
        'page_title': 'Assignment Submissions',
        'page_obj': page_obj,
        'query': query,
        'assignment': assignment,  # Pass the assignment object if filtered by it
    }
    return render(request, 'academic/assignment_submission_list.html', context)


@login_required
@user_passes_test(is_student, login_url='users:dashboard')
def assignment_submit_view(request, assignment_pk):
    assignment = get_object_or_404(Assignment, pk=assignment_pk)
    student_profile = request.user.student_profile

    # Check if a submission already exists for this student and assignment
    existing_submission = AssignmentSubmission.objects.filter(
        assignment=assignment,
        student=student_profile
    ).first()

    if request.method == 'POST':
        form = AssignmentSubmissionForm(request.POST, request.FILES, instance=existing_submission)
        if form.is_valid():
            submission = form.save(commit=False)
            submission.assignment = assignment
            submission.student = student_profile
            submission.save()
            messages.success(request,
                             'Assignment submitted successfully!' if not existing_submission else 'Assignment submission updated successfully!')
            return redirect('academic:assignment_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AssignmentSubmissionForm(instance=existing_submission)

    context = {
        'page_title': 'Submit Assignment' if not existing_submission else 'Update Assignment Submission',
        'form': form,
        'assignment': assignment,
        'existing_submission': existing_submission,
    }
    return render(request, 'academic/assignment_submission_form.html', context)


@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
def assignment_grade_view(request, pk):
    submission = get_object_or_404(AssignmentSubmission, pk=pk)

    # Teachers can only grade submissions for assignments in their assigned classes/subjects
    if is_teacher(request.user):
        teacher_profile = request.user.teacher_profile
        assigned_class_subject_ids = ClassSubjectAssignment.objects.filter(
            teacher=teacher_profile
        ).values_list('class_obj__id', 'subject__id')

        if not ((submission.assignment.class_obj.pk, submission.assignment.subject.pk) in assigned_class_subject_ids):
            messages.error(request, "You are not authorized to grade this submission.")
            return redirect('academic:assignment_submission_list')

    if request.method == 'POST':
        form = AssignmentGradeForm(request.POST, instance=submission)
        if form.is_valid():
            grade = form.save(commit=False)
            grade.graded_by = request.user.teacher_profile if is_teacher(request.user) else None  # Assign grader
            grade.graded_at = timezone.now()
            grade.save()
            messages.success(request, 'Assignment graded successfully!')
            return redirect('academic:assignment_submission_list')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field.replace('_', ' ').title()}: {error}")
            if form.non_field_errors():
                for error in form.non_field_errors():
                    messages.error(request, error)
    else:
        form = AssignmentGradeForm(instance=submission)

    context = {
        'page_title': f'Grade Submission for {submission.assignment.title} by {submission.student.user.get_full_name()}',
        'form': form,
        'submission': submission,
    }
    return render(request, 'academic/assignment_grade_form.html', context)


@login_required
@user_passes_test(is_admin, login_url='users:dashboard')
@require_POST
def assignment_submission_delete_view(request, pk):
    submission = get_object_or_404(AssignmentSubmission, pk=pk)
    try:
        submission.delete()
        messages.success(request, 'Assignment submission deleted successfully!')
    except Exception as e:
        messages.error(request, f'Error deleting submission: {e}')
    return redirect('academic:assignment_submission_list')


# --- AJAX Endpoints for dynamic form filtering ---
@login_required
@user_passes_test(is_admin_or_teacher, login_url='users:dashboard')
@require_GET
def ajax_get_classes_subjects(request):
    academic_session_id = request.GET.get('academic_session_id')
    class_id = request.GET.get('class_id')  # This might be present if class is already selected

    classes_data = []
    subjects_data = []

    if academic_session_id:
        try:
            academic_session = AcademicSession.objects.get(pk=academic_session_id)

            # Fetch classes for the selected academic session
            classes_queryset = Class.objects.filter(academic_session=academic_session).order_by('name')
            if is_teacher(request.user):
                teacher_profile = request.user.teacher_profile
                teacher_assigned_classes_ids = ClassSubjectAssignment.objects.filter(
                    academic_session=academic_session,
                    teacher=teacher_profile
                ).values_list('class_obj__id', flat=True).distinct()
                classes_queryset = classes_queryset.filter(id__in=teacher_assigned_classes_ids)

            for cls in classes_queryset:
                classes_data.append({'id': cls.id, 'name': cls.name})

            # Fetch subjects for the selected academic session and potentially selected class
            if class_id:
                class_obj = Class.objects.get(pk=class_id)
                assigned_subjects_ids = ClassSubjectAssignment.objects.filter(
                    academic_session=academic_session,
                    class_obj=class_obj
                ).values_list('subject__id', flat=True).distinct()
                subjects_queryset = Subject.objects.filter(id__in=assigned_subjects_ids).order_by('name')

                if is_teacher(request.user):
                    teacher_profile = request.user.teacher_profile
                    teacher_assigned_subjects_in_context_ids = ClassSubjectAssignment.objects.filter(
                        academic_session=academic_session,
                        class_obj=class_obj,
                        teacher=teacher_profile
                    ).values_list('subject__id', flat=True).distinct()
                    subjects_queryset = subjects_queryset.filter(id__in=teacher_assigned_subjects_in_context_ids)

                for sub in subjects_queryset:
                    subjects_data.append({'id': sub.id, 'name': sub.name})

        except (AcademicSession.DoesNotExist, Class.DoesNotExist):
            pass  # Return empty lists if session or class not found

    return JsonResponse({'classes': classes_data, 'subjects': subjects_data})


# academic/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from .models import Section, Class, Division
from .forms import SectionForm

# academic/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import StudentFeeCategory
from django.contrib.auth.decorators import login_required, user_passes_test


def is_admin(user):
    return user.is_authenticated and user.role == "admin"


@login_required
@user_passes_test(is_admin)
def fee_category_list(request):
    categories = StudentFeeCategory.objects.all()
    return render(
        request, "academic/fee_category_list.html", {"categories": categories}
    )


@login_required
@user_passes_test(is_admin)
def fee_category_create(request):
    if request.method == "POST":
        name = request.POST.get("name")
        if name:
            StudentFeeCategory.objects.create(name=name)
            messages.success(request, "Fee category added.")
            return redirect("academic:fee_category_list")
    return render(request, "academic/fee_category_form.html")


@login_required
@user_passes_test(is_admin)
def fee_category_update(request, pk):
    category = get_object_or_404(StudentFeeCategory, pk=pk)
    if request.method == "POST":
        name = request.POST.get("name")
        if name:
            category.name = name
            category.save()
            messages.success(request, "Fee category updated.")
            return redirect("academic:fee_category_list")
    return render(request, "academic/fee_category_form.html", {"category": category})


@login_required
@user_passes_test(is_admin)
def fee_category_delete(request, pk):
    category = get_object_or_404(StudentFeeCategory, pk=pk)
    category.delete()
    messages.success(request, "Fee category deleted.")
    return redirect("academic:fee_category_list")


def section_list(request):
    sections = Section.objects.all().select_related("class_obj", "division")
    classes = Class.objects.all()
    divisions = Division.objects.all()

    class_id = request.GET.get("class")
    division_id = request.GET.get("division")

    if class_id:
        sections = sections.filter(class_obj_id=class_id)
    if division_id:
        sections = sections.filter(division_id=division_id)

    context = {
        "sections": sections,
        "classes": classes,
        "divisions": divisions,
    }
    return render(request, "academic/section_list.html", context)


def section_create(request):
    if request.method == "POST":
        form = SectionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Section created successfully!")
            return redirect("academic:section_list")
    else:
        form = SectionForm()
    return render(request, "academic/section_form.html", {"form": form})


def section_edit(request, pk):
    section = get_object_or_404(Section, pk=pk)
    if request.method == "POST":
        form = SectionForm(request.POST, instance=section)
        if form.is_valid():
            form.save()
            messages.success(request, "Section updated successfully!")
            return redirect("academic:section_list")
    else:
        form = SectionForm(instance=section)
    return render(request, "academic/section_form.html", {"form": form})


def section_delete(request, pk):
    section = get_object_or_404(Section, pk=pk)
    section.delete()
    messages.success(request, "Section deleted successfully!")
    return redirect("academic:section_list")


def division_list(request):
    divisions = Division.objects.all()
    return render(request, "academic/division_list.html", {"divisions": divisions})


def division_create(request):
    if request.method == "POST":
        form = DivisionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Division created successfully.")
            return redirect("academic:division_list")
    else:
        form = DivisionForm()
    return render(
        request, "academic/division_form.html", {"form": form, "title": "Add Division"}
    )


def division_edit(request, pk):
    division = get_object_or_404(Division, pk=pk)
    if request.method == "POST":
        form = DivisionForm(request.POST, instance=division)
        if form.is_valid():
            form.save()
            messages.success(request, "Division updated successfully.")
            return redirect("academic:division_list")
    else:
        form = DivisionForm(instance=division)
    return render(
        request, "academic/division_form.html", {"form": form, "title": "Edit Division"}
    )


def division_delete(request, pk):
    division = get_object_or_404(Division, pk=pk)
    if request.method == "POST":
        division.delete()
        messages.success(request, "Division deleted successfully.")
        return redirect("academic:division_list")
    return render(
        request, "academic/division_confirm_delete.html", {"division": division}
    )
