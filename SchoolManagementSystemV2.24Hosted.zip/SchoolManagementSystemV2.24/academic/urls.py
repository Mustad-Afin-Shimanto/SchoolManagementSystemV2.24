# SchoolManagementSystem/academic/urls.py
from django.urls import path

from . import views

app_name = 'academic'

urlpatterns = [
    # Academic Session URLs
    path(
        "academic-sessions/", views.academic_session_list, name="academic_session_list"
    ),
    path(
        "academic-sessions/create/",
        views.academic_session_create,
        name="academic_session_create",
    ),
    path(
        "academic-sessions/<int:pk>/update/",
        views.academic_session_update,
        name="academic_session_update",
    ),
    path(
        "academic-sessions/<int:pk>/delete/",
        views.academic_session_delete,
        name="academic_session_delete",
    ),
    # Class URLs
    path("classes/", views.class_list, name="class_list"),
    path("classes/create/", views.class_create, name="class_create"),
    path("classes/<int:pk>/update/", views.class_update, name="class_update"),
    path("classes/<int:pk>/delete/", views.class_delete, name="class_delete"),
    # This URL now handles both GET (confirm) and POST (delete)
    # Subject URLs
    path("subjects/", views.subject_list, name="subject_list"),
    path("subjects/create/", views.subject_create, name="subject_create"),
    path("subjects/<int:pk>/update/", views.subject_update, name="subject_update"),
    path("subjects/<int:pk>/delete/", views.subject_delete, name="subject_delete"),
    # Class Subject Assignment URLs
    path(
        "class-subject-assignments/",
        views.class_subject_assignment_list,
        name="class_subject_assignment_list",
    ),
    path(
        "class-subject-assignments/create/",
        views.class_subject_assignment_create,
        name="class_subject_assignment_create",
    ),
    path(
        "class-subject-assignments/<int:pk>/update/",
        views.class_subject_assignment_update,
        name="class_subject_assignment_update",
    ),
    path(
        "class-subject-assignments/<int:pk>/delete/",
        views.class_subject_assignment_delete,
        name="class_subject_assignment_delete",
    ),
    # Class Routine URLs
    path("class-routines/", views.class_routine_list, name="class_routine_list"),
    path(
        "class-routines/create/",
        views.class_routine_create,
        name="class_routine_create",
    ),
    path(
        "class-routines/<int:pk>/update/",
        views.class_routine_update,
        name="class_routine_update",
    ),
    path(
        "class-routines/<int:pk>/delete/",
        views.class_routine_delete,
        name="class_routine_delete",
    ),
    # Attendance URLs
    path("attendance/", views.attendance_list, name="attendance_list"),
    path(
        "attendance/select/",
        views.attendance_selection_view,
        name="attendance_selection_view",
    ),
    path(
        "attendance/entry/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:year>/<int:month>/<int:day>/",
        views.attendance_entry_form_view,
        name="attendance_entry_form",
    ),
    path(
        "attendance/<int:pk>/update/",
        views.attendance_record_update_view,
        name="attendance_record_update",
    ),
    path(
        "attendance/<int:pk>/delete/",
        views.attendance_record_delete_view,
        name="attendance_record_delete",
    ),
    # NEW: URL for deleting a group of attendance records
    path(
        "attendance/delete-group/<int:academic_session_pk>/<int:class_pk>/<int:subject_pk>/<int:year>/<int:month>/<int:day>/",
        views.attendance_group_delete_view,
        name="attendance_group_delete",
    ),
    # Syllabus URLs
    path("syllabuses/", views.syllabus_list_view, name="syllabus_list"),
    path("syllabuses/create/", views.syllabus_create_view, name="syllabus_create"),
    path(
        "syllabuses/<int:pk>/update/",
        views.syllabus_update_view,
        name="syllabus_update",
    ),
    path(
        "syllabuses/<int:pk>/delete/",
        views.syllabus_delete_view,
        name="syllabus_delete",
    ),
    # Notice URLs
    path("notices/", views.notice_list_view, name="notice_list"),
    path("notices/create/", views.notice_create_view, name="notice_create"),
    path("notices/<int:pk>/update/", views.notice_update_view, name="notice_update"),
    path("notices/<int:pk>/delete/", views.notice_delete_view, name="notice_delete"),
    path("fee-categories/", views.fee_category_list, name="fee_category_list"),
    path(
        "fee-categories/create/", views.fee_category_create, name="fee_category_create"
    ),
    path(
        "fee-categories/<int:pk>/update/",
        views.fee_category_update,
        name="fee_category_update",
    ),
    path(
        "fee-categories/<int:pk>/delete/",
        views.fee_category_delete,
        name="fee_category_delete",
    ),
    # Fee URLs
    path("fees/", views.fee_list_view, name="fee_list"),
    path("fees/create/", views.fee_create_view, name="fee_create"),
    path("fees/<int:pk>/update/", views.fee_update_view, name="fee_update"),
    path("fees/<int:pk>/delete/", views.fee_delete_view, name="fee_delete"),
    # Fee Payment URLs
    path("fee-payments/", views.fee_payment_list_view, name="fee_payment_list"),
    path(
        "fee-payments/create/", views.fee_payment_create_view, name="fee_payment_create"
    ),
    path(
        "fee-payments/<int:pk>/update/",
        views.fee_payment_update_view,
        name="fee_payment_update",
    ),
    path(
        "fee-payments/<int:pk>/delete/",
        views.fee_payment_delete_view,
        name="fee_payment_delete",
    ),
    # Assignment URLs
    path("assignments/", views.assignment_list_view, name="assignment_list"),
    path("assignments/create/", views.assignment_create_view, name="assignment_create"),
    path(
        "assignments/<int:pk>/update/",
        views.assignment_update_view,
        name="assignment_update",
    ),
    path(
        "assignments/<int:pk>/delete/",
        views.assignment_delete_view,
        name="assignment_delete",
    ),
    # Assignment Submission URLs
    path(
        "assignment-submissions/",
        views.assignment_submission_list_view,
        name="assignment_submission_list",
    ),
    # RE-ADDED: Specific URL for submissions for a particular assignment
    path(
        "assignment-submissions/assignment/<int:assignment_pk>/",
        views.assignment_submission_list_view,
        name="assignment_submissions_by_assignment",
    ),
    path(
        "assignment-submissions/submit/<int:assignment_pk>/",
        views.assignment_submit_view,
        name="assignment_submission_create",
    ),
    path(
        "assignment-submissions/<int:pk>/grade/",
        views.assignment_grade_view,
        name="assignment_submission_grade",
    ),
    path(
        "assignment-submissions/<int:pk>/update/",
        views.assignment_submit_view,
        name="assignment_submission_update",
    ),
    path(
        "assignment-submissions/<int:pk>/delete/",
        views.assignment_submission_delete_view,
        name="assignment_submission_delete",
    ),
    path("sections/", views.section_list, name="section_list"),
    path("sections/add/", views.section_create, name="section_create"),
    path("sections/<int:pk>/edit/", views.section_edit, name="section_edit"),
    path("sections/<int:pk>/delete/", views.section_delete, name="section_delete"),
    # AJAX endpoint for dynamic form filtering (UPDATED)
    # Consolidated the two previous AJAX paths into one, pointing to ajax_get_classes_subjects
    path(
        "ajax/get-classes-subjects/",
        views.ajax_get_classes_subjects,
        name="ajax_get_classes_subjects",
    ),
    # other urls...
    # Division URLs
    path("divisions/", views.division_list, name="division_list"),
    path("divisions/add/", views.division_create, name="division_create"),
    path("divisions/<int:pk>/edit/", views.division_edit, name="division_edit"),
    path("divisions/<int:pk>/delete/", views.division_delete, name="division_delete"),
]
