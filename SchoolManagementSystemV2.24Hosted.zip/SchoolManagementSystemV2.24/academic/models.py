# SchoolManagementSystem/academic/models.py
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

# Import models from other apps for foreign keys
# Use string references for models that might cause circular imports
from users.models import CustomUser, Student, TeacherProfile, ParentProfile


class AcademicSession(models.Model):
    """Represents an academic session (e.g., 2023-2024)."""

    name = models.CharField(max_length=100, unique=True)
    start_date = models.DateField()
    end_date = models.DateField()
    is_current = models.BooleanField(
        default=False,
        help_text="Designates if this is the current active academic session.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="academic_sessions_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="academic_sessions_updated",
    )

    class Meta:
        verbose_name = "Academic Session"
        verbose_name_plural = "Academic Sessions"
        ordering = ["-start_date"]

    def __str__(self):
        return self.name

    def clean(self):
        from django.core.exceptions import ValidationError

        if self.start_date and self.end_date and self.start_date >= self.end_date:
            raise ValidationError("End date must be after start date.")
        if self.is_current:
            if (
                AcademicSession.objects.filter(is_current=True)
                .exclude(pk=self.pk)
                .exists()
            ):
                raise ValidationError(
                    "Only one academic session can be marked as current at a time."
                )

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)


class Division(models.Model):
    """Represents a division like Science, Commerce, Arts."""

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    class Meta:
        verbose_name = "Division"
        verbose_name_plural = "Divisions"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Class(models.Model):
    """Represents a class (e.g., Grade 1, Grade 10) under a division."""

    name = models.CharField(max_length=100)
    academic_session = models.ForeignKey(
        AcademicSession, on_delete=models.CASCADE, related_name="classes"
    )
    division = models.ForeignKey(
        Division,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="classes",
    )
    class_teacher = models.ForeignKey(
        TeacherProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="classes_taught",
    )
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="classes_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="classes_updated",
    )

    class Meta:
        verbose_name = "Class"
        verbose_name_plural = "Classes"
        unique_together = ("name", "academic_session", "division")
        ordering = ["name"]

    def __str__(self):
        if self.division:
            return f"{self.name} - {self.division.name} ({self.academic_session.name})"
        return f"{self.name} ({self.academic_session.name})"


class Section(models.Model):
    """Represents a section inside a class (e.g., Section A)."""

    name = models.CharField(max_length=50)
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="sections"
    )
    division = models.ForeignKey(
        Division,
        on_delete=models.CASCADE,
        related_name="sections",
        null=True,  # allow NULL
        blank=True,
    )
    description = models.TextField(blank=True, null=True)
    class Meta:
        unique_together = ("name", "class_obj")
        ordering = ["class_obj__name", "name"]

    def __str__(self):
        if self.class_obj.division:
            return (
                f"{self.class_obj.name} - {self.class_obj.division.name} - {self.name}"
            )
        return f"{self.class_obj.name} - {self.name}"


class Subject(models.Model):
    """Represents a subject (e.g., Mathematics, Science)."""

    name = models.CharField(max_length=100, unique=True)
    code = models.CharField(max_length=20, unique=True, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="subjects_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="subjects_updated",
    )

    class Meta:
        verbose_name = "Subject"
        verbose_name_plural = "Subjects"
        ordering = ["name"]

    def __str__(self):
        return self.name


class ClassSubjectAssignment(models.Model):
    """Assigns a subject to a class and optionally a teacher for a specific academic session."""

    academic_session = models.ForeignKey(
        AcademicSession,
        on_delete=models.CASCADE,
        related_name="class_subject_assignments",
    )
    class_obj = models.ForeignKey(
        Class, on_delete=models.CASCADE, related_name="subject_assignments"
    )
    subject = models.ForeignKey(
        Subject, on_delete=models.CASCADE, related_name="class_assignments"
    )
    teacher = models.ForeignKey(
        TeacherProfile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_subjects",
    )
    is_homeroom_teacher = models.BooleanField(
        default=False,
        help_text="Designates if this teacher is the homeroom teacher for this class.",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="class_subject_assignments_created",
    )
    updated_by = models.ForeignKey(
        CustomUser,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="class_subject_assignments_updated",
    )

    class Meta:
        verbose_name = "Class Subject Assignment"
        verbose_name_plural = "Class Subject Assignments"
        unique_together = ("academic_session", "class_obj", "subject")
        ordering = ["academic_session__name", "class_obj__name", "subject__name"]

    def __str__(self):
        teacher_name = (
            self.teacher.user.get_full_name() if self.teacher else "Unassigned"
        )
        return f"{self.subject.name} for {self.class_obj.name} ({self.academic_session.name}) by {teacher_name}"

    def clean(self):
        from django.core.exceptions import ValidationError

        if self.is_homeroom_teacher and not self.teacher:
            raise ValidationError(
                {
                    "teacher": "A teacher must be assigned if 'Is Homeroom Teacher' is checked."
                }
            )
        if self.is_homeroom_teacher:
            existing_homeroom = ClassSubjectAssignment.objects.filter(
                academic_session=self.academic_session,
                class_obj=self.class_obj,
                is_homeroom_teacher=True,
            ).exclude(pk=self.pk)
            if existing_homeroom.exists():
                raise ValidationError(
                    {
                        "is_homeroom_teacher": f"'{existing_homeroom.first().teacher.user.get_full_name()}' "
                        f"is already assigned as homeroom teacher for {self.class_obj.name} "
                        f"in {self.academic_session.name}."
                    }
                )


class ClassRoutine(models.Model):
    """Defines the daily schedule for classes."""
    academic_session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='class_routines')
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='class_routines')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='class_routines')
    teacher = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True,
                                related_name='class_routines')
    day_of_week = models.IntegerField(choices=[
        (0, 'Monday'), (1, 'Tuesday'), (2, 'Wednesday'), (3, 'Thursday'),
        (4, 'Friday'), (5, 'Saturday'), (6, 'Sunday')
    ])
    start_time = models.TimeField()
    end_time = models.TimeField()
    room_number = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='routines_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='routines_updated')

    class Meta:
        verbose_name = "Class Routine"
        verbose_name_plural = "Class Routines"
        unique_together = ('academic_session', 'class_obj', 'day_of_week', 'start_time')  # Prevent overlapping slots
        ordering = ['academic_session__name', 'class_obj__name', 'day_of_week', 'start_time']

    def __str__(self):
        return f"{self.class_obj.name} - {self.subject.name} on {self.get_day_of_week_display()} ({self.start_time}-{self.end_time})"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.start_time and self.end_time and self.start_time >= self.end_time:
            raise ValidationError('End time must be after start time.')
        # Check for overlapping routines for the same class and day
        overlapping_routines = ClassRoutine.objects.filter(
            academic_session=self.academic_session,
            class_obj=self.class_obj,
            day_of_week=self.day_of_week,
            start_time__lt=self.end_time,
            end_time__gt=self.start_time
        ).exclude(pk=self.pk)
        if overlapping_routines.exists():
            raise ValidationError('This routine overlaps with an existing routine for this class on this day.')


class AttendanceRecord(models.Model):
    """Records daily attendance for a student in a specific class and subject."""
    academic_session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='attendance_records')
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='attendance_records')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='attendance_records')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='attendance_records')
    teacher = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True,
                                related_name='taken_attendances')
    date = models.DateField(default=timezone.now)
    is_present = models.BooleanField(default=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='attendance_records_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='attendance_records_updated')

    class Meta:
        verbose_name = "Attendance Record"
        verbose_name_plural = "Attendance Records"
        unique_together = ('academic_session', 'class_obj', 'subject', 'student',
                           'date')  # One record per student per subject per day
        ordering = ['-date', 'class_obj__name', 'subject__name', 'student__user__first_name']

    def __str__(self):
        status = "Present" if self.is_present else "Absent"
        return f"{self.student.user.get_full_name()} - {self.subject.name} on {self.date} ({status})"

    def clean(self):
        from django.core.exceptions import ValidationError
        # Ensure the student belongs to the class for the given academic session
        if self.student.current_class != self.class_obj or self.student.academic_session != self.academic_session:
            raise ValidationError(
                "The selected student is not enrolled in this class for the specified academic session.")


class StudentFeeCategory(models.Model):
    """Represents a category for student fee purposes."""

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)

    class Meta:
        verbose_name = "Student Fee Category"
        verbose_name_plural = "Student Fee Categories"
        ordering = ["name"]

    def __str__(self):
        return self.name


class Fee(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    academic_session = models.ForeignKey("AcademicSession", on_delete=models.CASCADE)
    class_obj = models.ForeignKey(
        "Class", on_delete=models.SET_NULL, blank=True, null=True
    )
    fee_category = models.ForeignKey(
        "StudentFeeCategory", on_delete=models.SET_NULL, blank=True, null=True
    )  # 👈
    amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    due_date = models.DateField(blank=True, null=True)

    class Meta:
        verbose_name = "Fee Type"
        verbose_name_plural = "Fee Types"
        unique_together = ("academic_session", "name")
        ordering = ["academic_session__name", "name"]

    def __str__(self):
        return f"{self.name} ({self.academic_session.name})"


class FeeStructure(models.Model):
    """Stores the fee amount for a specific category."""

    fee = models.ForeignKey(Fee, on_delete=models.CASCADE, related_name="structures")
    category = models.ForeignKey(
        StudentFeeCategory, on_delete=models.CASCADE, related_name="fee_structures"
    )
    amount = models.DecimalField(
        max_digits=10, decimal_places=2, default=0.00, validators=[MinValueValidator(0)]
    )

    class Meta:
        verbose_name = "Fee Structure"
        verbose_name_plural = "Fee Structures"
        unique_together = ("fee", "category")

    def __str__(self):
        return f"{self.fee.name} - {self.category.name} : {self.amount}"


class FeePayment(models.Model):
    """Records payments made by students for specific fees."""
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='fee_payments')
    fee = models.ForeignKey(Fee, on_delete=models.CASCADE, related_name='payments')
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    payment_date = models.DateField(default=timezone.now)
    payment_method = models.CharField(max_length=50, blank=True, null=True)
    transaction_id = models.CharField(max_length=100, unique=True, blank=True, null=True)
    remarks = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='fee_payments_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='fee_payments_updated')

    class Meta:
        verbose_name = "Fee Payment"
        verbose_name_plural = "Fee Payments"
        ordering = ['-payment_date', 'student__user__first_name']

    def __str__(self):
        return f"{self.student.user.get_full_name()} - Paid {self.amount_paid} for {self.fee.name}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.amount_paid > self.fee.amount:
            raise ValidationError({'amount_paid': "Amount paid cannot exceed the total fee amount."})


class Syllabus(models.Model):
    """Stores syllabus documents for subjects."""
    academic_session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='syllabuses')
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='syllabuses')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='syllabuses')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    file = models.FileField(upload_to='syllabuses/', blank=True, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    uploaded_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='syllabuses_uploaded')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='syllabuses_updated')

    class Meta:
        verbose_name = "Syllabus"
        verbose_name_plural = "Syllabuses"
        unique_together = ('academic_session', 'class_obj', 'subject',
                           'title')  # Unique syllabus per class/subject/session
        ordering = ['academic_session__name', 'class_obj__name', 'subject__name', 'title']

    def __str__(self):
        return f"Syllabus for {self.subject.name} - {self.class_obj.name} ({self.academic_session.name})"


class Notice(models.Model):
    """Manages school notices and announcements."""
    title = models.CharField(max_length=255)
    content = models.TextField()
    published_date = models.DateTimeField(default=timezone.now)
    expiry_date = models.DateTimeField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    target_roles = models.CharField(
        max_length=20,
        choices=[('all', 'All Users'), ('admin', 'Admin'), ('teacher', 'Teachers'), ('student', 'Students'),
                 ('parent', 'Parents')],
        default='all',
        help_text="Who should see this notice?"
    )
    target_classes = models.ManyToManyField(Class, blank=True, related_name='notices',
                                            help_text="Select specific classes to target (optional).")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='notices_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='notices_updated')

    class Meta:
        verbose_name = "Notice"
        verbose_name_plural = "Notices"
        ordering = ['-published_date']

    def __str__(self):
        return self.title

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.expiry_date and self.expiry_date < self.published_date:
            raise ValidationError({'expiry_date': "Expiry date cannot be before the published date."})

    def is_expired(self):
        return self.expiry_date and self.expiry_date < timezone.now()


class Assignment(models.Model):
    """Manages assignments given to students."""
    academic_session = models.ForeignKey(AcademicSession, on_delete=models.CASCADE, related_name='assignments')
    class_obj = models.ForeignKey(Class, on_delete=models.CASCADE, related_name='assignments')
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, related_name='assignments')
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    due_date = models.DateField()
    max_marks = models.DecimalField(max_digits=5, decimal_places=2, validators=[MinValueValidator(0.01)])
    file = models.FileField(upload_to='assignments/', blank=True, null=True)
    assigned_by = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True,
                                    related_name='assigned_assignments')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    created_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='assignments_created')
    updated_by = models.ForeignKey(CustomUser, on_delete=models.SET_NULL, null=True, blank=True,
                                   related_name='assignments_updated')

    class Meta:
        verbose_name = "Assignment"
        verbose_name_plural = "Assignments"
        ordering = ['-due_date', 'class_obj__name', 'subject__name']

    def __str__(self):
        return f"{self.title} - {self.class_obj.name} ({self.subject.name})"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.due_date < timezone.now().date():
            # Allow past due dates for creation/update, but warn
            pass
        if self.max_marks <= 0:
            raise ValidationError({'max_marks': "Maximum marks for an assignment must be greater than 0."})


class AssignmentSubmission(models.Model):
    """Records student submissions for assignments."""
    assignment = models.ForeignKey(Assignment, on_delete=models.CASCADE, related_name='submissions')
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name='assignment_submissions')
    submission_text = models.TextField(blank=True, null=True)
    submission_file = models.FileField(upload_to='assignment_submissions/', blank=True, null=True)
    submission_date = models.DateTimeField(auto_now_add=True)
    marks_obtained = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True,
                                         validators=[MinValueValidator(0)])
    feedback = models.TextField(blank=True, null=True)
    graded_at = models.DateTimeField(null=True, blank=True)
    graded_by = models.ForeignKey(TeacherProfile, on_delete=models.SET_NULL, null=True, blank=True,
                                  related_name='graded_submissions')

    class Meta:
        verbose_name = "Assignment Submission"
        verbose_name_plural = "Assignment Submissions"
        unique_together = ('assignment', 'student')
        ordering = ['-submission_date', 'assignment__title', 'student__user__first_name']

    def __str__(self):
        return f"Submission for {self.assignment.title} by {self.student.user.get_full_name()}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.marks_obtained is not None and self.marks_obtained > self.assignment.max_marks:
            raise ValidationError(
                {
                    'marks_obtained': f"Marks obtained cannot exceed the maximum marks of {self.assignment.max_marks} for this assignment."}
            )
        if not self.submission_text and not self.submission_file:
            raise ValidationError('Either submission text or a submission file is required.')
