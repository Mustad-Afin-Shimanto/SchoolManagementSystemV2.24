# SchoolManagementSystem/SchoolManagementSystem/context_processors.py
from users.models import Student, TeacherProfile, ParentProfile


def user_profile_processor(request):
    """
    Context processor to add the specific user profile (Student, TeacherProfile, ParentProfile)
    to the request.user object and the context for easy access in templates.
    """
    profile_data = {}
    if request.user.is_authenticated:
        try:
            if request.user.role == 'student':
                student_profile = Student.objects.get(user=request.user)
                # Corrected: Attach to request.user with the correct related name
                request.user.student_profile = student_profile
                profile_data['student_profile'] = student_profile
            elif request.user.role == 'teacher':
                teacher_profile = TeacherProfile.objects.get(user=request.user)
                request.user.teacher_profile = teacher_profile
                profile_data['teacher_profile'] = teacher_profile
            elif request.user.role == 'parent':
                parent_profile = ParentProfile.objects.get(user=request.user)
                request.user.parent_profile = parent_profile
                profile_data['parent_profile'] = parent_profile
        except (Student.DoesNotExist, TeacherProfile.DoesNotExist, ParentProfile.DoesNotExist):
            # Handle cases where a user might not have an associated profile yet
            # This could happen if a user is created but their specific profile isn't.
            # Set to None to avoid AttributeError in templates.
            if request.user.role == 'student':
                # Corrected: Set to the correct related name
                request.user.student_profile = None
                profile_data['student_profile'] = None
            elif request.user.role == 'teacher':
                request.user.teacher_profile = None
                profile_data['teacher_profile'] = None
            elif request.user.role == 'parent':
                request.user.parent_profile = None
                profile_data['parent_profile'] = None
    return profile_data  # Return the dictionary to be merged into the context
