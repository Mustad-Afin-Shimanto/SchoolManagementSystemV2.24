# SchoolManagementSystem/SchoolManagementSystem/urls.py
from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path, include

from users import views as user_views  # Import users views to use for home/dashboard

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", user_views.dashboard, name="home"),  # Added this line for the 'home' URL
    path("users/", include("users.urls")),
    path("academic/", include("academic.urls", namespace="academic")),
    path(
        "marks/", include("marks.urls", namespace="marks")
    ),  # Ensure this line is present and correct
    path("exams/", include("exams.urls", namespace="exams")),
    path("questionbank/", include("questionbank.urls")),
]

# Serve media files in development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
